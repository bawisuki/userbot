import os
from dotenv import load_dotenv

load_dotenv(".env", override=True)

MAX_BOT = int(os.getenv("MAX_BOT", "200"))

DEVS = list(map(int, os.getenv("DEVS", "6349437505").split()))

API_ID = int(os.getenv("API_ID", "30942251"))

API_HASH = os.getenv("API_HASH", "02646db842263f3b34e1f10bf16e10c5")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8998909828:AAGhW0RyyBLUlWqy2xeyXCYg7WxLKoHbc-0")

OWNER_ID = int(os.getenv("OWNER_ID", "6349437505"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

PAKASIR_PROJECT = os.getenv("PAKASIR_PROJECT", "sukicai")
PAKASIR_API_KEY = os.getenv("PAKASIR_API_KEY", "vG5V7DAH76QhH9A32pjUZInyiPwIYtVz")
ATLANTIC_API_KEY = os.getenv("ATLANTIC_API_KEY", "")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1004304097071"))
