from PyroUbot import *

__MODULE__ = "🔗 Random"
__HELP__ = """<blockquote><b>⎆ <code>{0}genslug2</code></b></blockquote>"""


@PY.UBOT("genslug2")
@PY.TOP_CMD
async def genslug2(client, message):
    """🔗 Random"""
    try:
        import random, string, uuid, hashlib, os, secrets, base64
        r = '-'.join(__import__('random').choices(['alpha','beta','gamma','delta','omega','nova','pixel','cyber','cloud','data','flux','nexus','pulse','quantum','swift','turbo','ultra','vortex','wave','zen'], k=3))
        await message.edit(f"<b>🔗 Random Slug</b>\n\n<code>{str(r)}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
