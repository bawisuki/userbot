from PyroUbot import *

__MODULE__ = "ᴅᴇᴄ ᴛᴏ ᴏᴄᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}dec2oct</code></b></blockquote>"""


@PY.UBOT("dec2oct")
@PY.TOP_CMD
async def dec2oct(client, message):
    """ᴅᴇᴄ ᴛᴏ ᴏᴄᴛ"""
    try:
        val = int(message.text.split(None, 1)[1])
        await message.edit(f"<b>🔢 Decimal {val} = Octal {oct(val)[2:]}</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.dec2oct 511</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
