from PyroUbot import *
import aiohttp

__MODULE__ = "ᴅᴏɢᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}doge</code></b></blockquote>"""


@PY.UBOT("doge")
@PY.TOP_CMD
async def doge(client, message):
    """ᴅᴏɢᴇ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api.coingecko.com/api/v3/simple/price?ids=dogecoin&vs_currencies=usd&include_24hr_change=true") as r:
                d = await r.json()
        price = d["dogecoin"]["usd"]
        change = d["dogecoin"].get("usd_24h_change", 0)
        emoji = "📈" if change >= 0 else "📉"
        await message.edit(f"<b>🐕 Dogecoin</b>\n\n<b>💰 Price:</b> ${price:.6f}\n<b>{emoji} 24h:</b> {change:.2f}%", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
