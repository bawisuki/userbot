from PyroUbot import *
import random

__MODULE__ = "🙈 Excuse"
__HELP__ = """<blockquote><b>⎆ <code>{0}excuse2</code></b></blockquote>"""


@PY.UBOT("excuse2")
@PY.TOP_CMD
async def excuse2(client, message):
    """🙈 Excuse"""
    try:
        items = ['My dog ate my homework', 'I was stuck in traffic', "My alarm didn't go off", 'I had a family emergency', 'My internet was down', 'I was feeling under the weather', 'I got lost', 'My car broke down', 'I had a dentist appointment', 'There was a power outage']
        await message.edit(f"<b>🙈 Excuse</b>\n\n<i>{random.choice(items)}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
