from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄᴀᴍᴇʟ"
__HELP__ = """<blockquote><b>⎆ <code>{0}camel</code></b></blockquote>"""


@PY.UBOT("camel")
@PY.TOP_CMD
async def camelcase(client, message):
    """ᴄᴀᴍᴇʟ"""
    try:
        text = message.text.split(None, 1)[1]
        words = text.split()
        result = words[0].lower() + "".join(w.title() for w in words[1:])
        await message.edit(f"<b>🐫 camelCase</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.camel hello world</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
