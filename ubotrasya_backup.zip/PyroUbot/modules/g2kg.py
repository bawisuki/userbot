from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ g2kg"
__HELP__ = """<blockquote><b>⎆ <code>{0}g2kg</code></b></blockquote>"""


@PY.UBOT("g2kg")
@PY.TOP_CMD
async def g2kg(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val/1000
        await message.edit(f"<b>📐 {val} grams = {result:.6g} kg</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.g2kg value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
