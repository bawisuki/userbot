from PyroUbot import *
import json as jsonlib

__MODULE__ = "ᴊꜱᴏɴ ᴠᴀʟɪᴅ"
__HELP__ = """<blockquote><b>⎆ <code>{0}jsonvalid</code></b></blockquote>"""


@PY.UBOT("jsonvalid")
@PY.TOP_CMD
async def jsonvalid(client, message):
    """ᴊꜱᴏɴ ᴠᴀʟɪᴅ"""
    try:
        text = message.text.split(None, 1)[1] if len(message.text.split()) > 1 else (message.reply_to_message.text if message.reply_to_message else "")
        if not text:
            return await message.edit("<b>⚠️ Provide JSON or reply to a message.</b>", parse_mode=ParseMode.HTML)
        jsonlib.loads(text)
        await message.edit("<b>✅ Valid JSON!</b>", parse_mode=ParseMode.HTML)
    except jsonlib.JSONDecodeError as je:
        await message.edit(f"<b>❌ Invalid JSON</b>\n\n<code>{str(je)[:200]}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
