from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄᴏʟᴏʀ ɪɴꜰᴏ"
__HELP__ = """<blockquote><b>⎆ <code>{0}color2hex</code></b></blockquote>"""


@PY.UBOT("color2hex")
@PY.TOP_CMD
async def color2hex(client, message):
    """ᴄᴏʟᴏʀ ɪɴꜰᴏ"""
    try:
        hex_code = message.text.split(None, 1)[1].strip("#")
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://www.thecolorapi.com/id?hex={hex_code}") as r:
                d = await r.json()
        txt = (
            f"<b>🎨 Color Info</b>\n\n"
            f"<b>📛 Name:</b> {d['name']['value']}\n"
            f"<b>HEX:</b> <code>{d['hex']['value']}</code>\n"
            f"<b>RGB:</b> <code>{d['rgb']['value']}</code>\n"
            f"<b>HSL:</b> <code>{d['hsl']['value']}</code>\n"
            f"<b>CMYK:</b> <code>{d['cmyk']['value']}</code>"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.color2hex #ff5733</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
