from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄᴜᴀᴄᴀ ɪᴅ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴄᴇᴋ ᴄᴜᴀᴄᴀ

⎆ <code>{0}cuaca</code> [kota]
   ᴄᴇᴋ ᴄᴜᴀᴄᴀ ᴅɪ ᴋᴏᴛᴀ ɪɴᴅᴏɴᴇꜱɪᴀ</b></blockquote>
"""


@PY.UBOT("cuaca")
@PY.TOP_CMD
async def cuaca_cmd(client, message):
    args = message.text.split(None, 1)
    if len(args) < 2:
        return await message.edit("<b><emoji id=5210952531676504517>❌</emoji> ɢᴜɴᴀᴋᴀɴ: <code>.cuaca [kota]</code></b>")
    kota = args[1].strip()
    await message.edit("<b><emoji id=5789858554890425372>🔄</emoji> ᴍᴇɴɢᴇᴄᴇᴋ ᴄᴜᴀᴄᴀ...</b>")
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"https://wttr.in/{kota}?format=j1") as resp:
                data = await resp.json(content_type=None)
        current = data["current_condition"][0]
        temp = current.get("temp_C", "?")
        feels = current.get("FeelsLikeC", "?")
        humidity = current.get("humidity", "?")
        wind = current.get("windspeedKmph", "?")
        desc = current.get("weatherDesc", [{}])[0].get("value", "?")
        text = f"<b><emoji id=5206607081334906820>✅</emoji> ᴄᴜᴀᴄᴀ ᴅɪ {kota.title()}</b>\n\n"
        text += f"<b>🌡 ꜱᴜʜᴜ:</b> <code>{temp}\u00b0C</code> (ᴛᴇʀᴀꜱᴀ {feels}\u00b0C)\n"
        text += f"<b>☁️ ᴋᴏɴᴅɪꜱɪ:</b> <code>{desc}</code>\n"
        text += f"<b>💧 ᴋᴇʟᴇᴍʙᴀʙᴀɴ:</b> <code>{humidity}%</code>\n"
        text += f"<b>💨 ᴀɴɢɪɴ:</b> <code>{wind} km/h</code>\n"
        await message.edit(text)
    except Exception as e:
        await message.edit(f"<b><emoji id=5210952531676504517>❌</emoji> ᴇʀʀᴏʀ:</b> <code>{e}</code>")
