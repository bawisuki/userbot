from PyroUbot import *
from PyroUbot.core.memek_konek import get_credits

__MODULE__ = "ᴄʀᴇᴅɪᴛꜱ"
__HELP__ = """
<blockquote><b>⎆ <code>{0}credits</code> ɪɴꜰᴏ ᴅᴇᴠᴇʟᴏᴘᴇʀ
⎆ <code>{0}dev</code> ᴄᴏɴᴛᴀᴄᴛ ᴅᴇᴠ</b></blockquote>
"""

@PY.UBOT("credits")
@PY.TOP_CMD
async def credits_cmd(client, message):
    """ᴄʀᴇᴅɪᴛꜱ"""
    try:
        c = get_credits()
        txt = (
            f"<b>⚡ SherifD'Code Userbot</b>\n\n"
            f"<b>👨‍💻 Developer:</b> {c['developer']}\n"
            f"<b>📢 Telegram:</b> {c['telegram']}\n"
            f"<b>📡 Channel:</b> {c['channel']}\n"
            f"<b>📅 Year:</b> {c['year']}\n"
            f"<b>✅ Verified:</b> {c['verified']}"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)

@PY.UBOT("dev")
@PY.TOP_CMD
async def dev_cmd(client, message):
    """ᴅᴇᴠ"""
    try:
        c = get_credits()
        await message.edit(
            f"<b>⚡ {c['developer']} Userbot</b>\n\n"
            f"<b>👨‍💻 Developer:</b> {c['developer']}\n"
            f"<b>📢 Contact:</b> {c['telegram']}\n"
            f"<b>📡 Channel:</b> {c['channel']}\n\n"
            f"<i>© {c['year']} All Rights Reserved</i>",
            parse_mode=ParseMode.HTML
        )
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
