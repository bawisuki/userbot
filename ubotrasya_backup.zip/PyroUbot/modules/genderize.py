from PyroUbot import *
import aiohttp

__MODULE__ = "ɢᴇɴᴅᴇʀ"
__HELP__ = """<blockquote><b>⎆ <code>{0}gender</code></b></blockquote>"""


@PY.UBOT("gender")
@PY.TOP_CMD
async def genderize(client, message):
    """ɢᴇɴᴅᴇʀ"""
    try:
        name = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.genderize.io?name={name}") as r:
                d = await r.json()
        g = "👨 Male" if d['gender'] == "male" else "👩 Female" if d['gender'] == "female" else "❓ Unknown"
        await message.edit(f"<b>🔮 Gender Prediction</b>\n\n<b>Name:</b> {d['name']}\n<b>Gender:</b> {g}\n<b>Probability:</b> {d['probability']*100:.1f}%", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.gender name</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
