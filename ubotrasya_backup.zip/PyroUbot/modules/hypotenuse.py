from PyroUbot import *
import math

__MODULE__ = "ʜʏᴘᴏᴛᴇɴᴜꜱᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}hyp</code></b></blockquote>"""


@PY.UBOT("hyp")
@PY.TOP_CMD
async def hypotenuse(client, message):
    """ʜʏᴘᴏᴛᴇɴᴜꜱᴇ"""
    try:
        args = message.text.split()
        a, b = float(args[1]), float(args[2])
        c = math.hypot(a, b)
        await message.edit(f"<b>📐 Hypotenuse</b>\n\na={a}, b={b}\n<b>c = {c:.4f}</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.hyp 3 4</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
