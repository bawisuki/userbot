from PyroUbot import *
import aiohttp

__MODULE__ = "ʙɴʙ"
__HELP__ = """<blockquote><b>⎆ <code>{0}bnb</code></b></blockquote>"""


@PY.UBOT("bnb")
@PY.TOP_CMD
async def bnb(client, message):
    """ʙɴʙ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api.coingecko.com/api/v3/simple/price?ids=binancecoin&vs_currencies=usd&include_24hr_change=true") as r:
                d = await r.json()
        price = d["binancecoin"]["usd"]
        change = d["binancecoin"].get("usd_24h_change", 0)
        emoji = "📈" if change >= 0 else "📉"
        await message.edit(f"<b>🟡 BNB</b>\n\n<b>💰 Price:</b> ${price:,.2f}\n<b>{emoji} 24h:</b> {change:.2f}%", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
