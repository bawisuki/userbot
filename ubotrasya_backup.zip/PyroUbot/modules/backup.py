from PyroUbot import *
from PyroUbot.config import OWNER_ID
import os
import zipfile
import asyncio
from datetime import datetime

__MODULE__ = "ʙᴀᴄᴋᴜᴘ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ʙᴀᴄᴋᴜᴘ

⎆ <code>{0}backup</code> ʙᴀᴄᴋᴜᴘ ꜱᴇᴍᴜᴀ ꜰɪʟᴇ ᴅᴀɴ ᴋɪʀɪᴍ ᴋᴇ ᴏᴡɴᴇʀ
⎆ <code>{0}autobackup</code> ᴏɴ/ᴏꜰꜰ ᴀᴜᴛᴏ ʙᴀᴄᴋᴜᴘ 24 ᴊᴀᴍ</b></blockquote>
"""

BACKUP_DIR = "/root/ubotrasya-main"
BACKUP_PATH = "/tmp/ubotrasya_backup.zip"
EXCLUDE = {".git", "__pycache__", ".env", "venv", "node_modules"}
_auto_backup_task = None


DB_DUMP_PATH = "/tmp/ubotrasya_db.sql"


def dump_mysql():
    os.system(f"mysqldump -u root sherifdubot > {DB_DUMP_PATH} 2>/dev/null")


def create_backup():
    if os.path.exists(BACKUP_PATH):
        os.remove(BACKUP_PATH)
    dump_mysql()
    with zipfile.ZipFile(BACKUP_PATH, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(BACKUP_DIR):
            dirs[:] = [d for d in dirs if d not in EXCLUDE]
            for file in files:
                if file == ".env":
                    continue
                filepath = os.path.join(root, file)
                arcname = os.path.relpath(filepath, BACKUP_DIR)
                zf.write(filepath, arcname)
        if os.path.exists(DB_DUMP_PATH):
            zf.write(DB_DUMP_PATH, "database_backup.sql")
            os.remove(DB_DUMP_PATH)
    return BACKUP_PATH


async def send_backup(client, caption=""):
    path = create_backup()
    size = os.path.getsize(path)
    size_str = f"{size / (1024*1024):.2f} MB"
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cap = (
        f"<emoji id=5206607081334906820>✅</emoji> <b>ʙᴀᴄᴋᴜᴘ ʙᴇʀʜᴀꜱɪʟ!</b>\n\n"
        f"<b>⎆ ᴡᴀᴋᴛᴜ:</b> <code>{now}</code>\n"
        f"<b>⎆ ꜱɪᴢᴇ:</b> <code>{size_str}</code>\n"
        f"<b>⎆ ꜰᴏʟᴅᴇʀ:</b> <code>{BACKUP_DIR}</code>"
    )
    if caption:
        cap += f"\n<b>⎆ ɴᴏᴛᴇ:</b> <code>{caption}</code>"
    await client.send_document(OWNER_ID, path, caption=cap, parse_mode=ParseMode.HTML)
    os.remove(path)


async def auto_backup_loop(client):
    while True:
        await asyncio.sleep(86400)
        try:
            await send_backup(client, "ᴀᴜᴛᴏ ʙᴀᴄᴋᴜᴘ 24 ᴊᴀᴍ")
        except Exception:
            pass


@PY.UBOT("backup")
@PY.TOP_CMD
async def backup_cmd(client, message):
    try:
        await message.edit("<emoji id=5789858554890425372>🔄</emoji> <b>ᴍᴇᴍʙᴜᴀᴛ ʙᴀᴄᴋᴜᴘ...</b>", parse_mode=ParseMode.HTML)
        await send_backup(client, "ᴍᴀɴᴜᴀʟ ʙᴀᴄᴋᴜᴘ")
        await message.edit("<emoji id=5206607081334906820>✅</emoji> <b>ʙᴀᴄᴋᴜᴘ ᴛᴇʀᴋɪʀɪᴍ ᴋᴇ ᴏᴡɴᴇʀ!</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("autobackup")
@PY.TOP_CMD
async def autobackup_cmd(client, message):
    global _auto_backup_task
    args = message.text.split(None, 1)
    if len(args) < 2 or args[1].lower() not in ("on", "off"):
        return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.autobackup on/off</code>", parse_mode=ParseMode.HTML)
    try:
        if args[1].lower() == "on":
            if _auto_backup_task and not _auto_backup_task.done():
                return await message.edit("<emoji id=5206607081334906820>✅</emoji> <b>ᴀᴜᴛᴏ ʙᴀᴄᴋᴜᴘ ꜱᴜᴅᴀʜ ᴀᴋᴛɪꜰ!</b>", parse_mode=ParseMode.HTML)
            _auto_backup_task = asyncio.create_task(auto_backup_loop(client))
            await message.edit("<emoji id=5206607081334906820>✅</emoji> <b>ᴀᴜᴛᴏ ʙᴀᴄᴋᴜᴘ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ! (ꜱᴇᴛɪᴀᴘ 24 ᴊᴀᴍ)</b>", parse_mode=ParseMode.HTML)
        else:
            if _auto_backup_task and not _auto_backup_task.done():
                _auto_backup_task.cancel()
                _auto_backup_task = None
            await message.edit("<emoji id=5206607081334906820>✅</emoji> <b>ᴀᴜᴛᴏ ʙᴀᴄᴋᴜᴘ ᴅɪɴᴏɴᴀᴋᴛɪꜰᴋᴀɴ!</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


async def _start_auto():
    global _auto_backup_task
    from PyroUbot import ubot as _ubot
    _auto_backup_task = asyncio.create_task(auto_backup_loop(_ubot))

try:
    asyncio.get_event_loop().call_soon(lambda: asyncio.ensure_future(_start_auto()))
except Exception:
    pass
