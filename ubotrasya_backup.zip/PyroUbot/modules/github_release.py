from PyroUbot import *
import aiohttp

__MODULE__ = "ɢʜ ʀᴇʟᴇᴀꜱᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}ghrelease</code></b></blockquote>"""


@PY.UBOT("ghrelease")
@PY.TOP_CMD
async def github_release(client, message):
    """ɢʜ ʀᴇʟᴇᴀꜱᴇ"""
    try:
        repo = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.github.com/repos/{repo}/releases/latest") as r:
                d = await r.json()
        if "message" in d:
            return await message.edit("<b>❌ No releases found.</b>", parse_mode=ParseMode.HTML)
        txt = f"<b>📦 {repo} Latest Release</b>\n\n<b>Tag:</b> {d['tag_name']}\n<b>Name:</b> {d.get('name','')}\n<b>Date:</b> {d['published_at'][:10]}\n<b>URL:</b> {d['html_url']}"
        await message.edit(txt, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.ghrelease user/repo</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
