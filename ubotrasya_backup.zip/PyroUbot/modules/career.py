from PyroUbot import *
import random

__MODULE__ = "💼"
__HELP__ = """<blockquote><b>⎆ <code>{0}career</code></b></blockquote>"""


@PY.UBOT("career")
@PY.TOP_CMD
async def career(client, message):
    """💼"""
    try:
        result = random.choice(['Software Engineer','Doctor','Artist','Chef','Astronaut','Teacher','Musician','Scientist','Writer','Pilot','Detective','Architect'])
        await message.edit(f"<b>💼 Random Career</b>\n\n<b>Result:</b> {result}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
