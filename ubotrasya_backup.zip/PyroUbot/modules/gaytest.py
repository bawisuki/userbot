from PyroUbot import *
import random

__MODULE__ = "ɢᴀʏ ᴛᴇꜱᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}gaytest</code></b></blockquote>"""


@PY.UBOT("gaytest")
@PY.TOP_CMD
async def gaytest(client, message):
    """ɢᴀʏ ᴛᴇꜱᴛ"""
    try:
        pct = random.randint(0, 100)
        bar = "🏳️‍🌈" * (pct // 10)
        await message.edit(f"<b>🏳️‍🌈 Gay Test</b>\n\n{bar}\n<b>{pct}%</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
