from PyroUbot import *
import json

__MODULE__ = "ᴊꜱᴏɴ ꜰᴏʀᴍᴀᴛ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴊꜱᴏɴ

⎆ <code>{0}jsonf</code> [reply/text] ꜰᴏʀᴍᴀᴛ/ᴘʀᴇᴛᴛɪꜰʏ ᴊꜱᴏɴ</b></blockquote>
"""


@PY.UBOT("jsonf")
@PY.TOP_CMD
async def jsonf_cmd(client, message):
    args = message.text.split(None, 1)
    text = args[1] if len(args) > 1 else None
    if not text and message.reply_to_message:
        text = message.reply_to_message.text or message.reply_to_message.caption
    if not text:
        return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.jsonf [reply/text]</code>", parse_mode=ParseMode.HTML)
    try:
        parsed = json.loads(text)
        result = json.dumps(parsed, indent=2, ensure_ascii=False)
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ꜰᴏʀᴍᴀᴛᴛᴇᴅ ᴊꜱᴏɴ:</b>\n<pre>{result}</pre>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
