from PyroUbot import *
import aiohttp

__MODULE__ = "📁 FIL"
__HELP__ = """<blockquote><b>⎆ <code>{0}fil</code></b></blockquote>"""


@PY.UBOT("fil")
@PY.TOP_CMD
async def fil(client, message):
    """📁 FIL"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api.coingecko.com/api/v3/simple/price?ids=filecoin&vs_currencies=usd&include_24hr_change=true") as r:
                d = await r.json()
        price = d["filecoin"]["usd"]
        change = d["filecoin"].get("usd_24h_change", 0)
        emoji_c = "📈" if change >= 0 else "📉"
        await message.edit(f"<b>📁 FIL</b>\n\n<b>💰 Price:</b> ${price}\n<b>{emoji_c} 24h:</b> {change:.2f}%", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
