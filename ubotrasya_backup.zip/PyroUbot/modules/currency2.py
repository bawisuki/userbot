from PyroUbot import *
import aiohttp
from urllib.parse import quote

__MODULE__ = "ᴄᴜʀʀᴇɴᴄʏ"
__HELP__ = """<blockquote><b>⎆ <code>{0}currency</code></b></blockquote>"""


@PY.UBOT("currency")
@PY.TOP_CMD
async def currency2(client, message):
    """ᴄᴜʀʀᴇɴᴄʏ"""
    try:
        name = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://restcountries.com/v3.1/name/{quote(name)}?fields=name,currencies") as r:
                d = await r.json()
        c = d[0]
        currencies = c.get("currencies", {})
        txt = f"<b>💰 Currency: {c['name']['common']}</b>\n\n"
        for code, info in currencies.items():
            txt += f"<b>{code}:</b> {info['name']} ({info.get('symbol','')})"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.currency country</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
