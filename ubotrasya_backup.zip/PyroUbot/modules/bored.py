from PyroUbot import *
import aiohttp

__MODULE__ = "ʙᴏʀᴇᴅ"
__HELP__ = """<blockquote><b>⎆ <code>{0}bored</code></b></blockquote>"""


@PY.UBOT("bored")
@PY.TOP_CMD
async def bored(client, message):
    """ʙᴏʀᴇᴅ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://bored-api.appbrewery.com/random") as r:
                d = await r.json()
        txt = (
            f"<b>🎯 Activity Suggestion</b>\n\n"
            f"<b>📝 Activity:</b> {d['activity']}\n"
            f"<b>🏷 Type:</b> {d['type']}\n"
            f"<b>👥 Participants:</b> {d['participants']}"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
