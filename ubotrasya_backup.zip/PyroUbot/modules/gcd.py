from PyroUbot import *
import math

__MODULE__ = "ɢᴄᴅ"
__HELP__ = """<blockquote><b>⎆ <code>{0}gcd</code></b></blockquote>"""


@PY.UBOT("gcd")
@PY.TOP_CMD
async def gcd(client, message):
    """ɢᴄᴅ"""
    try:
        args = message.text.split()
        a, b = int(args[1]), int(args[2])
        await message.edit(f"<b>🔢 GCD({a}, {b}) = {math.gcd(a, b)}</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.gcd 12 8</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
