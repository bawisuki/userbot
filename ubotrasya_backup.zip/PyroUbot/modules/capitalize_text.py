from PyroUbot import *

__MODULE__ = "ᴛᴏᴏʟ capitalize"
__HELP__ = """<blockquote><b>⎆ <code>{0}capitalize</code></b></blockquote>"""


@PY.UBOT("capitalize")
@PY.TOP_CMD
async def capitalize_text(client, message):
    """ᴛᴏᴏʟ"""
    try:
        text = message.text.split(None, 1)[1]
        await message.edit(f"<code>{text.capitalize()}</code>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, TypeError):
        await message.edit("<b>⚠️ Provide text or reply to a message.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
