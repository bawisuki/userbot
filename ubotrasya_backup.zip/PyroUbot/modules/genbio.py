from PyroUbot import *
import random

__MODULE__ = "📝 Bio"
__HELP__ = """<blockquote><b>⎆ <code>{0}genbio</code></b></blockquote>"""


@PY.UBOT("genbio")
@PY.TOP_CMD
async def genbio(client, message):
    """📝 Bio"""
    try:
        result = f"{random.choice(['🚀','💻','🎯','⚡','🌟'])} {random.choice(['Developer','Creator','Builder','Maker','Dreamer'])} | {random.choice(['Coffee addict','Code lover','Bug hunter','Stack overflow survivor','Git push enthusiast'])} | {random.choice(['Building the future','One commit at a time','Breaking things since','Learning everyday'])}"
        await message.edit(f"<b>📝 Bio</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
