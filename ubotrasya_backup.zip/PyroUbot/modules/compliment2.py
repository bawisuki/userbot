from PyroUbot import *
import random

__MODULE__ = "compliment"
__HELP__ = """<blockquote><b>⎆ <code>{0}compliment2</code></b></blockquote>"""


@PY.UBOT("compliment2")
@PY.TOP_CMD
async def compliment2(client, message):
    """compliment"""
    try:
        items = ["You're more fun than bubble wrap.", "You're like a ray of sunshine on a rainy day.", 'You have the best laugh.', "You're someone's reason to smile.", "You're even more beautiful on the inside than you are on the outside.", "If you were a vegetable, you'd be a cute-cumber.", "You're one of a kind!"]
        await message.edit(f"<b>🎲 Compliment</b>\n\n<i>{random.choice(items)}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
