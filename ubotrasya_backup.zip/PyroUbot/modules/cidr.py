from PyroUbot import *
import ipaddress

__MODULE__ = "ᴄɪᴅʀ"
__HELP__ = """<blockquote><b>⎆ <code>{0}cidr</code></b></blockquote>"""


@PY.UBOT("cidr")
@PY.TOP_CMD
async def cidr(client, message):
    """ᴄɪᴅʀ"""
    try:
        network = message.text.split(None, 1)[1]
        net = ipaddress.ip_network(network, strict=False)
        txt = f"<b>🌐 CIDR: {network}</b>\n\n<b>Network:</b> {net.network_address}\n<b>Broadcast:</b> {net.broadcast_address}\n<b>Netmask:</b> {net.netmask}\n<b>Hosts:</b> {net.num_addresses - 2}\n<b>First:</b> {list(net.hosts())[0] if net.num_addresses > 2 else 'N/A'}\n<b>Last:</b> {list(net.hosts())[-1] if net.num_addresses > 2 else 'N/A'}"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.cidr 192.168.1.0/24</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
