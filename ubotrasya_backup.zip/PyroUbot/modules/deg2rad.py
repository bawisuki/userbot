from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ deg2rad"
__HELP__ = """<blockquote><b>⎆ <code>{0}deg2rad</code></b></blockquote>"""


@PY.UBOT("deg2rad")
@PY.TOP_CMD
async def deg2rad(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val*0.0174533
        await message.edit(f"<b>📐 {val} degrees = {result:.6g} radians</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.deg2rad value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
