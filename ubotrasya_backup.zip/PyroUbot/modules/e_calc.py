from PyroUbot import *

__MODULE__ = "euler number"
__HELP__ = """<blockquote><b>⎆ <code>{0}euler</code></b></blockquote>"""


@PY.UBOT("euler")
@PY.TOP_CMD
async def e_calc(client, message):
    """euler number"""
    try:
        import math
        await message.edit(f"<b>e = {math.e}</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Provide valid numbers.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
