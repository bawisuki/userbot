from PyroUbot import *

__MODULE__ = "🔐 Random"
__HELP__ = """<blockquote><b>⎆ <code>{0}genhash</code></b></blockquote>"""


@PY.UBOT("genhash")
@PY.TOP_CMD
async def genhash(client, message):
    """🔐 Random"""
    try:
        import random, string, uuid, hashlib, os, secrets, base64
        r = __import__('hashlib').sha256(__import__('os').urandom(32)).hexdigest()
        await message.edit(f"<b>🔐 Random Hash</b>\n\n<code>{str(r)}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
