from PyroUbot import *

__MODULE__ = "ᴅᴇᴄ ᴛᴏ ʙɪɴ"
__HELP__ = """<blockquote><b>⎆ <code>{0}dec2bin</code></b></blockquote>"""


@PY.UBOT("dec2bin")
@PY.TOP_CMD
async def dec2bin(client, message):
    """ᴅᴇᴄ ᴛᴏ ʙɪɴ"""
    try:
        val = int(message.text.split(None, 1)[1])
        await message.edit(f"<b>🔢 Decimal {val} = Binary {bin(val)[2:]}</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.dec2bin 255</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
