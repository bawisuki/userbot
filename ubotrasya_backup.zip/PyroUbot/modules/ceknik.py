from PyroUbot import *

__MODULE__ = "ᴄᴇᴋ ɴɪᴋ"
__HELP__ = """<blockquote><b>⎆ <code>{0}ceknik</code></b></blockquote>"""


@PY.UBOT("ceknik")
@PY.TOP_CMD
async def ceknik(client, message):
    """ᴄᴇᴋ ɴɪᴋ"""
    try:
        nik = message.text.split(None, 1)[1].strip()
        if len(nik) != 16 or not nik.isdigit():
            return await message.edit("<b>❌ NIK harus 16 digit angka.</b>", parse_mode=ParseMode.HTML)
        prov = nik[:2]
        kab = nik[2:4]
        kec = nik[4:6]
        tgl = int(nik[6:8])
        bln = nik[8:10]
        thn = nik[10:12]
        gender = "Perempuan" if tgl > 40 else "Laki-laki"
        if tgl > 40: tgl -= 40
        txt = f"<b>🪪 Analisis NIK</b>\n\n<b>NIK:</b> <code>{nik}</code>\n<b>Prov:</b> {prov}\n<b>Kab/Kota:</b> {kab}\n<b>Kecamatan:</b> {kec}\n<b>TTL:</b> {tgl:02d}-{bln}-19{thn}/20{thn}\n<b>Gender:</b> {gender}\n<b>Urutan:</b> {nik[12:]}"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.ceknik 3201234567890001</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
