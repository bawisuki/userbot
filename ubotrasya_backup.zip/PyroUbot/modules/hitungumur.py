from PyroUbot import *
from datetime import datetime

__MODULE__ = "ᴜᴍᴜʀ"
__HELP__ = """<blockquote><b>⎆ <code>{0}umur</code></b></blockquote>"""


@PY.UBOT("umur")
@PY.TOP_CMD
async def hitungumur(client, message):
    """ᴜᴍᴜʀ"""
    try:
        tgl = message.text.split(None, 1)[1]
        birth = datetime.strptime(tgl, "%d-%m-%Y")
        now = datetime.now()
        age = now.year - birth.year - ((now.month, now.day) < (birth.month, birth.day))
        days = (now - birth).days
        hours = days * 24
        await message.edit(f"<b>🎂 Hitung Umur</b>\n\n<b>Lahir:</b> {tgl}\n<b>Umur:</b> {age} tahun\n<b>Hari:</b> {days:,} hari\n<b>Jam:</b> {hours:,} jam", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.umur DD-MM-YYYY</code>\n<b>Contoh:</b> <code>.umur 17-08-1945</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
