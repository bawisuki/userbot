from PyroUbot import *
import aiohttp

__MODULE__ = "ᴀᴅᴀ"
__HELP__ = """<blockquote><b>⎆ <code>{0}ada</code></b></blockquote>"""


@PY.UBOT("ada")
@PY.TOP_CMD
async def ada(client, message):
    """ᴀᴅᴀ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api.coingecko.com/api/v3/simple/price?ids=cardano&vs_currencies=usd&include_24hr_change=true") as r:
                d = await r.json()
        price = d["cardano"]["usd"]
        change = d["cardano"].get("usd_24h_change", 0)
        emoji = "📈" if change >= 0 else "📉"
        await message.edit(f"<b>🔵 Cardano (ADA)</b>\n\n<b>💰 Price:</b> ${price:.4f}\n<b>{emoji} 24h:</b> {change:.2f}%", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
