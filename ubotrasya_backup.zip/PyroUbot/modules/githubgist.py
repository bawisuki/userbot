from PyroUbot import *
import aiohttp

__MODULE__ = "ɢɪꜱᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}github_gist</code></b></blockquote>"""


@PY.UBOT("github_gist")
@PY.TOP_CMD
async def github_gist(client, message):
    """ɢɪꜱᴛ"""
    try:
        user = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.github.com/users/{user}/gists") as r:
                d = await r.json()
        if not d:
            return await message.edit("<b>❌ No gists found.</b>", parse_mode=ParseMode.HTML)
        txt = f"<b>📋 Gists by {user}</b>\n\n"
        for g in d[:5]:
            files = list(g["files"].keys())
            txt += f"• <a href='{g['html_url']}'>{files[0]}</a> ({g['created_at'][:10]})\n"
        await message.edit(txt, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.github_gist username</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
