from PyroUbot import *
import aiohttp

__MODULE__ = "ᴋᴀɴʏᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}kanye</code></b></blockquote>"""


@PY.UBOT("kanye")
@PY.TOP_CMD
async def kanye(client, message):
    """ᴋᴀɴʏᴇ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api.kanye.rest/") as r:
                d = await r.json()
        await message.edit(f"<b>🎤 Kanye Quote</b>\n\n<i>\"{d['quote']}\"</i>\n\n— Kanye West", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
