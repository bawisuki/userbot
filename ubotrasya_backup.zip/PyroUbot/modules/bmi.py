from PyroUbot import *
import aiohttp

__MODULE__ = "ʙᴍɪ"
__HELP__ = """<blockquote><b>⎆ <code>{0}bmi</code></b></blockquote>"""


@PY.UBOT("bmi")
@PY.TOP_CMD
async def bmi(client, message):
    """ʙᴍɪ"""
    try:
        args = message.text.split()
        weight = float(args[1])
        height = float(args[2]) / 100
        bmi_val = weight / (height ** 2)
        if bmi_val < 18.5:
            cat = "Underweight"
        elif bmi_val < 25:
            cat = "Normal"
        elif bmi_val < 30:
            cat = "Overweight"
        else:
            cat = "Obese"
        await message.edit(f"<b>⚖️ BMI Calculator</b>\n\n<b>BMI:</b> {bmi_val:.1f}\n<b>Category:</b> {cat}", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.bmi weight_kg height_cm</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
