from PyroUbot import *
import aiohttp

__MODULE__ = "ɪᴘ ɢᴇᴏ"
__HELP__ = """<blockquote><b>⎆ <code>{0}ipgeo</code></b></blockquote>"""


@PY.UBOT("ipgeo")
@PY.TOP_CMD
async def ipgeo(client, message):
    """ɪᴘ ɢᴇᴏ"""
    try:
        ip = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"http://ip-api.com/json/{ip}") as r:
                d = await r.json()
        if d["status"] == "fail":
            return await message.edit(f"<b>❌ {d['message']}</b>", parse_mode=ParseMode.HTML)
        txt = (
            f"<b>🌐 IP Geolocation</b>\n\n"
            f"<b>📍 IP:</b> {d['query']}\n"
            f"<b>🏳️ Country:</b> {d['country']}\n"
            f"<b>🏙 City:</b> {d['city']}\n"
            f"<b>📮 ZIP:</b> {d['zip']}\n"
            f"<b>🌐 ISP:</b> {d['isp']}\n"
            f"<b>📡 Lat/Lon:</b> {d['lat']}, {d['lon']}"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.ipgeo ip_address</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
