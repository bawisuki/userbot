from PyroUbot import *
import random

__MODULE__ = "💚 How Je"
__HELP__ = """<blockquote><b>⎆ <code>{0}howjealous</code></b></blockquote>"""


@PY.UBOT("howjealous")
@PY.TOP_CMD
async def howjealous(client, message):
    """💚 How Je"""
    try:
        target = message.reply_to_message.from_user.first_name if message.reply_to_message else "You"
        pct = random.randint(0, 100)
        await message.edit(f"<b>💚 How Jealous?</b>\n\n{target} is <b>{pct}%</b> jealous!", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
