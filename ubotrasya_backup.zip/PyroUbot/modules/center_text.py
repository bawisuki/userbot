from PyroUbot import *

__MODULE__ = "center text"
__HELP__ = """<blockquote><b>⎆ <code>{0}center</code></b></blockquote>"""


@PY.UBOT("center")
@PY.TOP_CMD
async def center_text(client, message):
    """center text"""
    try:
        args = message.text.split(None, 2)
        width = int(args[1])
        text = args[2]
        await message.edit(f"<code>{text.center(width)}</code>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Provide text.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
