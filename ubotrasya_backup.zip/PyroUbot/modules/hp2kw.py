from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ hp2kw"
__HELP__ = """<blockquote><b>⎆ <code>{0}hp2kw</code></b></blockquote>"""


@PY.UBOT("hp2kw")
@PY.TOP_CMD
async def hp2kw(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val * 0.7457
        await message.edit(f"<b>📐 {val} horsepower = {result:.4f} kilowatts</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.hp2kw value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
