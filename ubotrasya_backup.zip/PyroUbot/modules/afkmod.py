from PyroUbot import *
import time

__MODULE__ = "ᴀꜰᴋ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴀꜰᴋ

⎆ <code>{0}goafk</code> [alasan] ꜱᴇᴛ ᴍᴏᴅᴇ ᴀꜰᴋ
⎆ <code>{0}backafk</code> ᴍᴀᴛɪᴋᴀɴ ᴍᴏᴅᴇ ᴀꜰᴋ</b></blockquote>
"""


@PY.UBOT("goafk")
@PY.TOP_CMD
async def afk_on(client, message):
    try:
        args = message.text.split(None, 1)
        reason = args[1] if len(args) > 1 else "ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴀʟᴀꜱᴀɴ"
        afk_data = f"{int(time.time())}|{reason}"
        await set_vars(client.me.id, "AFK_MODE", afk_data)
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ᴍᴏᴅᴇ ᴀꜰᴋ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ!</b>\n<b>ᴀʟᴀꜱᴀɴ:</b> <code>{reason}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("backafk")
@PY.TOP_CMD
async def afk_off(client, message):
    try:
        afk_data = await get_vars(client.me.id, "AFK_MODE")
        if not afk_data:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ᴀɴᴅᴀ ᴛɪᴅᴀᴋ ꜱᴇᴅᴀɴɢ ᴀꜰᴋ!</b>", parse_mode=ParseMode.HTML)
        afk_time = int(afk_data.split("|")[0])
        duration = int(time.time()) - afk_time
        mins, secs = divmod(duration, 60)
        hours, mins = divmod(mins, 60)
        await remove_vars(client.me.id, "AFK_MODE")
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ᴍᴏᴅᴇ ᴀꜰᴋ ᴅɪᴍᴀᴛɪᴋᴀɴ!</b>\n<b>ᴅᴜʀᴀꜱɪ:</b> <code>{hours}j {mins}m {secs}s</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
