from PyroUbot import *
import random

__MODULE__ = "🎬 Movie Ti"
__HELP__ = """<blockquote><b>⎆ <code>{0}genmovie</code></b></blockquote>"""


@PY.UBOT("genmovie")
@PY.TOP_CMD
async def genmovie(client, message):
    """🎬 Movie Ti"""
    try:
        result = f"{random.choice(['The Last','Return of the','Rise of the','Fall of the','Legend of the','Secret of the'])} {random.choice(['Dragon','Kingdom','Shadow','Phoenix','Empire','Warrior','Storm','Night'])}"
        await message.edit(f"<b>🎬 Movie Title</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
