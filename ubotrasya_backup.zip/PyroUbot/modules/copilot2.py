from PyroUbot import *
import aiohttp
from urllib.parse import quote

__MODULE__ = "ᴄᴏᴘɪʟᴏᴛ 2"
__HELP__ = """<blockquote><b>⎆ <code>{0}copilot2</code></b></blockquote>"""


@PY.UBOT("copilot2")
@PY.TOP_CMD
async def copilot2(client, message):
    """ᴄᴏᴘɪʟᴏᴛ 2"""
    try:
        args = message.text.split(None, 1)
        text = args[1] if len(args) > 1 else (message.reply_to_message.text if message.reply_to_message else None)
        if not text:
            return await message.edit("<b>⚠️ Usage:</b> <code>.copilot2 [text/reply]</code>", parse_mode=ParseMode.HTML)
        await message.edit("<b>⏳ Copilot thinking...</b>", parse_mode=ParseMode.HTML)
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api-nanzz.my.id/docs/api/ai/copilot.php?q={quote(text)}") as r:
                d = await r.json()
        if d.get("status"):
            answer = d["result"]["text"]
            await message.edit(f"<b>🤖 Copilot</b>\n\n{answer[:4000]}", parse_mode=ParseMode.HTML)
        else:
            await message.edit("<b>❌ Gagal mendapat respons.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
