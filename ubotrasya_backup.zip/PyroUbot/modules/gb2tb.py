from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ gb2tb"
__HELP__ = """<blockquote><b>⎆ <code>{0}gb2tb</code></b></blockquote>"""


@PY.UBOT("gb2tb")
@PY.TOP_CMD
async def gb2tb(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val * 0.001
        await message.edit(f"<b>📐 {val} GB = {result:.4f} TB</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.gb2tb value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
