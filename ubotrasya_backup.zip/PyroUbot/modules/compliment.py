from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄᴏᴍᴘʟɪᴍᴇɴᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}compliment</code></b></blockquote>"""


@PY.UBOT("compliment")
@PY.TOP_CMD
async def compliment(client, message):
    """ᴄᴏᴍᴘʟɪᴍᴇɴᴛ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://complimentr.com/api") as r:
                d = await r.json()
        await message.edit(f"<b>💐 Compliment</b>\n\n<i>{d['compliment']}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
