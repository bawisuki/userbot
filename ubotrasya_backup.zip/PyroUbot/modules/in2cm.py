from PyroUbot import *

__MODULE__ = "ɪɴ ᴛᴏ ᴄᴍ"
__HELP__ = """<blockquote><b>⎆ <code>{0}in2cm</code></b></blockquote>"""


@PY.UBOT("in2cm")
@PY.TOP_CMD
async def in2cm(client, message):
    """ɪɴ ᴛᴏ ᴄᴍ"""
    try:
        val = float(message.text.split(None, 1)[1])
        await message.edit(f"<b>📏 {val} inches = {val * 2.54:.2f} cm</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.in2cm 10</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
