from PyroUbot import *

__MODULE__ = "all temps fahrenheit"
__HELP__ = """<blockquote><b>⎆ <code>{0}fahrenheit</code></b></blockquote>"""


@PY.UBOT("fahrenheit")
@PY.TOP_CMD
async def fahrenheit(client, message):
    """all temps"""
    try:
        val = float(message.text.split(None, 1)[1])
        c = (val-32)*5/9
        await message.edit(f"<b>🌡 {val}°F</b>\n= {c:.1f}°C\n= {c+273.15:.2f}K", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Provide valid numbers.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
