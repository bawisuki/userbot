from PyroUbot import *

__MODULE__ = "🎨 5 Colo"
__HELP__ = """<blockquote><b>⎆ <code>{0}gencolor5</code></b></blockquote>"""


@PY.UBOT("gencolor5")
@PY.TOP_CMD
async def gencolor5(client, message):
    """🎨 5 Colo"""
    try:
        import random, string, uuid, hashlib, os, secrets, base64
        r = [f'#{__import__("random").randint(0,0xFFFFFF):06x}' for _ in range(5)]
        await message.edit(f"<b>🎨 5 Colors</b>\n\n<code>{', '.join(r)}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
