from PyroUbot import *

__MODULE__ = "ᴛᴏᴏʟ joinlines"
__HELP__ = """<blockquote><b>⎆ <code>{0}joinlines</code></b></blockquote>"""


@PY.UBOT("joinlines")
@PY.TOP_CMD
async def join_text(client, message):
    """ᴛᴏᴏʟ"""
    try:
        args = message.text.split(None, 2)
        sep = args[1]
        text = args[2] if len(args) > 2 else (message.reply_to_message.text if message.reply_to_message else "")
        result = sep.join(text.split("\n"))
        await message.edit(f"<code>{result[:3000]}</code>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, TypeError):
        await message.edit("<b>⚠️ Provide text or reply to a message.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
