from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ kb2byte"
__HELP__ = """<blockquote><b>⎆ <code>{0}kb2byte</code></b></blockquote>"""


@PY.UBOT("kb2byte")
@PY.TOP_CMD
async def kb2byte(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val * 1000
        await message.edit(f"<b>📐 {val} KB = {result:.4f} bytes</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.kb2byte value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
