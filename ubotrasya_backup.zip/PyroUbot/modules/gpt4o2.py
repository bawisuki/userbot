from PyroUbot import *
import aiohttp
from urllib.parse import quote

__MODULE__ = "ɢᴘᴛ 4ᴏ"
__HELP__ = """<blockquote><b>⎆ <code>{0}gpt4o2</code></b></blockquote>"""


@PY.UBOT("gpt4o2")
@PY.TOP_CMD
async def gpt4o2(client, message):
    """ɢᴘᴛ 4ᴏ"""
    try:
        args = message.text.split(None, 1)
        text = args[1] if len(args) > 1 else (message.reply_to_message.text if message.reply_to_message else None)
        if not text:
            return await message.edit("<b>⚠️ Usage:</b> <code>.gpt4o2 [text/reply]</code>", parse_mode=ParseMode.HTML)
        await message.edit("<b>⏳ GPT-4o Mini...</b>", parse_mode=ParseMode.HTML)
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api-nanzz.my.id/docs/api/ai/gpt-4o-mini.php?prompt={quote(text)}") as r:
                d = await r.json()
        answer = d.get("result", "No response")
        await message.edit(f"<b>🤖 GPT-4o Mini</b>\n\n{str(answer)[:4000]}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
