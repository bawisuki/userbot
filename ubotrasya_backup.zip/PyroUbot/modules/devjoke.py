from PyroUbot import *
import aiohttp

__MODULE__ = "ᴊᴏᴋᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}joke</code></b></blockquote>"""


@PY.UBOT("joke")
@PY.TOP_CMD
async def devjoke(client, message):
    """ᴊᴏᴋᴇ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://v2.jokeapi.dev/joke/Programming?type=single") as r:
                d = await r.json()
        if d.get("error"):
            return await message.edit("<b>❌ Failed to get joke.</b>", parse_mode=ParseMode.HTML)
        await message.edit(f"<b>😂 Dev Joke</b>\n\n{d['joke']}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
