from PyroUbot import *

__MODULE__ = "absolute value"
__HELP__ = """<blockquote><b>⎆ <code>{0}abs</code></b></blockquote>"""


@PY.UBOT("abs")
@PY.TOP_CMD
async def abs_calc(client, message):
    """absolute value"""
    try:
        val = float(message.text.split(None, 1)[1])
        await message.edit(f"<b>|{val}| = {abs(val)}</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Provide valid numbers.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
