from PyroUbot import *

__MODULE__ = "ᴄᴀʟᴄᴜʟᴀᴛᴏʀ fib"
__HELP__ = """
<blockquote><b>⎆ <code>{0}fib</code> [n] ꜰɪʙᴏɴᴀᴄᴄɪ
⎆ <code>{0}prime</code> [n] ᴄᴇᴋ ᴘʀɪᴍᴀ
⎆ <code>{0}sqrt</code> [n] ᴀᴋᴀʀ
⎆ <code>{0}quadratic</code> [a b c] ᴋᴜᴀᴅʀᴀᴛɪᴋ
⎆ <code>{0}compound</code> [p r t] ʙᴜɴɢᴀ
⎆ <code>{0}bmi</code> [kg cm] ʙᴍɪ
⎆ <code>{0}tip</code> [bill %] ᴛɪᴘ
⎆ <code>{0}discount</code> [price %] ᴅɪꜱᴋᴏɴ
⎆ <code>{0}loan</code> [p r months] ᴋʀᴇᴅɪᴛ
⎆ <code>{0}zakat</code> [harta] ᴢᴀᴋᴀᴛ
⎆ <code>{0}pajak</code> [income] ᴘᴀᴊᴀᴋ</b></blockquote>
"""



@PY.UBOT("fib")
@PY.TOP_CMD
async def fibonacci(client, message):
    """ꜰɪʙᴏɴᴀᴄᴄɪ"""
    try:
        n = int(message.text.split(None, 1)[1])
        n = min(n, 30)
        fib = [0, 1]
        for i in range(2, n):
            fib.append(fib[-1] + fib[-2])
        await message.edit(f"<b>🔢 Fibonacci ({n})</b>\n\n<code>{', '.join(map(str, fib[:n]))}</code>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.fib 10</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
