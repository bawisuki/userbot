from PyroUbot import *
import random

__MODULE__ = "📱 App Name"
__HELP__ = """<blockquote><b>⎆ <code>{0}genapp</code></b></blockquote>"""


@PY.UBOT("genapp")
@PY.TOP_CMD
async def genapp(client, message):
    """📱 App Name"""
    try:
        result = f"{random.choice(['Snap','Quick','Easy','Smart','Fast','Super','Ultra','Mega'])}{random.choice(['Chat','Pay','Ride','Food','Shop','Learn','Play','Work'])}"
        await message.edit(f"<b>📱 App Name</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
