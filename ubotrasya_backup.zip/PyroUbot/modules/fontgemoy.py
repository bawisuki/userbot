from PyroUbot import *

__MODULE__ = "ꜰᴏɴᴛ"
__HELP__ = """
<blockquote><b>꒰ 🎀 ꒱ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ꜰᴏɴᴛ

⎆ <code>{0}font</code> [text/reply]
   ᴍᴇɴᴀᴍᴘɪʟᴋᴀɴ ꜱᴇᴍᴜᴀ ꜱᴛʏʟᴇ ꜰᴏɴᴛ

⎆ <code>{0}gemoy</code> [text/reply]
   ᴛᴇxᴛ ɢᴇᴍᴏʏ ᴅᴇɴɢᴀɴ ᴋᴀᴏᴍᴏᴊɪ

⎆ <code>{0}aesthetic</code> [text/reply]
   ᴛᴇxᴛ ᴀᴇꜱᴛʜᴇᴛɪᴄ ᴠᴀᴘᴏʀᴡᴀᴠᴇ

⎆ <code>{0}bubble</code> [text/reply]
   ᴛᴇxᴛ ʙᴜʙʙʟᴇ

⎆ <code>{0}cute</code> [text/reply]
   ᴛᴇxᴛ ᴄᴜᴛᴇ ᴅᴇɴɢᴀɴ ᴅᴇᴋᴏʀᴀꜱɪ

⎆ <code>{0}fancy</code> [text/reply]
   ᴛᴇxᴛ ꜰᴀɴᴄʏ ᴄᴜʀꜱɪᴠᴇ

⎆ <code>{0}gothic</code> [text/reply]
   ᴛᴇxᴛ ɢᴏᴛʜɪᴄ

⎆ <code>{0}kawaii</code> [text/reply]
   ᴛᴇxᴛ ᴋᴀᴡᴀɪɪ ᴅᴇɴɢᴀɴ ᴇᴍᴏᴊɪ ʟᴜᴄᴜ</b></blockquote>
"""

import random

KAOMOJI = [
    "꒰ᐢ. ̫ .ᐢ꒱", "(◕ᴗ◕✿)", "( ˶ˆᗜˆ˵ )", "꒰˶• ༝ •˶꒱", "(ᵔᴗᵔ)",
    "♡(ᐢ ᵕᐢ)", "( ˃̣̣̥ω˂̣̣̥ )", "(≧◡≦)", "✿◕ ‿ ◕✿", "( ˘ᴗ˘ )",
    "ʚɞ", "♡ᵎ", "˚ ༘♡", "⸝⸝", "꒰ ꒱", "ᶻ 𝗓 𐰁", "✧˖°",
    "₊˚⊹♡", "⋆˚✿˖°", "˗ˏˋ ˎˊ˗", "꒷꒦꒷", "⊹₊ ⋆", "♡̷̷",
]

CUTE_DECO = ["♡", "✿", "⋆", "˚", "꒰", "꒱", "₊", "⊹", "✧", "°", "ᵎ", "ꕤ", "ꔛ", "ꗃ"]


def _get_text(message):
    if message.reply_to_message and message.reply_to_message.text:
        return message.reply_to_message.text
    elif len(message.command) > 1:
        return " ".join(message.command[1:])
    return None


def to_aesthetic(text):
    return "".join(chr(0xFF01 + ord(c) - 0x21) if 0x21 <= ord(c) <= 0x7E else c for c in text)


def to_bubble(text):
    result = ""
    for c in text:
        if "a" <= c <= "z":
            result += chr(0x24D0 + ord(c) - ord("a"))
        elif "A" <= c <= "Z":
            result += chr(0x24B6 + ord(c) - ord("A"))
        elif "0" <= c <= "9":
            result += chr(0x2460 + ord(c) - ord("0")) if c != "0" else "⓪"
        else:
            result += c
    return result


def to_fancy(text):
    style = "abcdefghijklmnopqrstuvwxyz"
    fancy = "𝒶𝒷𝒸𝒹ℯ𝒻ℊ𝒽𝒾𝒿𝓀𝓁𝓂𝓃ℴ𝓅𝓆𝓇𝓈𝓉𝓊𝓋𝓌𝓍𝓎𝓏"
    fancy_up = "𝒜ℬ𝒞𝒟ℰℱ𝒢ℋℐ𝒥𝒦ℒℳ𝒩𝒪𝒫𝒬ℛ𝒮𝒯𝒰𝒱𝒲𝒳𝒴𝒵"
    result = ""
    for c in text:
        if c in style:
            result += fancy[style.index(c)]
        elif c.lower() in style:
            result += fancy_up[style.index(c.lower())]
        else:
            result += c
    return result


def to_gothic(text):
    style = "abcdefghijklmnopqrstuvwxyz"
    goth = "𝔞𝔟𝔠𝔡𝔢𝔣𝔤𝔥𝔦𝔧𝔨𝔩𝔪𝔫𝔬𝔭𝔮𝔯𝔰𝔱𝔲𝔳𝔴𝔵𝔶𝔷"
    goth_up = "𝔄𝔅ℭ𝔇𝔈𝔉𝔊ℌℑ𝔍𝔎𝔏𝔐𝔑𝔒𝔓𝔔ℜ𝔖𝔗𝔘𝔙𝔚𝔛𝔜ℨ"
    result = ""
    for c in text:
        if c in style:
            result += goth[style.index(c)]
        elif c.lower() in style:
            result += goth_up[style.index(c.lower())]
        else:
            result += c
    return result


def to_gemoy(text):
    kao = random.choice(KAOMOJI)
    deco = random.choices(CUTE_DECO, k=3)
    return f"{deco[0]}₊˚ {text} ˚₊{deco[1]} {kao} {deco[2]}"


def to_kawaii(text):
    emojis = ["🎀", "🌸", "💕", "✨", "🍡", "🧸", "🌷", "💗", "🦋", "🍰"]
    kao = random.choice(KAOMOJI)
    e1, e2 = random.sample(emojis, 2)
    words = text.split()
    result = f"{e1} "
    for i, w in enumerate(words):
        result += w
        if i < len(words) - 1:
            result += random.choice([" ♡ ", " ⋆ ", " ✿ ", " "])
    result += f" {e2}\n{kao}"
    return result


def to_cute(text):
    deco = ["꒰🎀꒱", "꒰✿꒱", "꒰💕꒱", "꒰⭐꒱", "꒰🌸꒱"]
    d = random.choice(deco)
    return f"┊ ⊹ {d} {text} ⊹ ┊"


@PY.UBOT("font")
@PY.TOP_CMD
async def font_cmd(client, message):
    text = _get_text(message)
    if not text:
        return await message.reply("꒰ 🎀 ꒱ reply/ketik text yang mau diubah~", quote=True)
    
    result = f"""<blockquote><b>꒰ 🎀 ꒱ ꜰᴏɴᴛ ꜱᴛʏʟᴇꜱ</b></blockquote>

<b>✿ Aesthetic:</b>
<code>{to_aesthetic(text)}</code>

<b>◎ Bubble:</b>
<code>{to_bubble(text)}</code>

<b>♡ Fancy:</b>
<code>{to_fancy(text)}</code>

<b>⚔ Gothic:</b>
<code>{to_gothic(text)}</code>

<b>🎀 Gemoy:</b>
<code>{to_gemoy(text)}</code>

<b>🌸 Kawaii:</b>
<code>{to_kawaii(text)}</code>

<b>⊹ Cute:</b>
<code>{to_cute(text)}</code>"""
    await message.reply(result, quote=True)


@PY.UBOT("gemoy")
@PY.TOP_CMD
async def gemoy_cmd(client, message):
    text = _get_text(message)
    if not text:
        return await message.reply("ketik text nya dong~ ꒰ᐢ. ̫ .ᐢ꒱", quote=True)
    await message.reply(to_gemoy(text))


@PY.UBOT("aesthetic")
@PY.TOP_CMD
async def aesthetic_cmd(client, message):
    text = _get_text(message)
    if not text:
        return await message.reply("ketik text nya~", quote=True)
    await message.reply(to_aesthetic(text))


@PY.UBOT("bubble")
@PY.TOP_CMD
async def bubble_cmd(client, message):
    text = _get_text(message)
    if not text:
        return await message.reply("ketik text nya~", quote=True)
    await message.reply(to_bubble(text))


@PY.UBOT("cute")
@PY.TOP_CMD
async def cute_cmd(client, message):
    text = _get_text(message)
    if not text:
        return await message.reply("ketik text nya~ ♡", quote=True)
    await message.reply(to_cute(text))


@PY.UBOT("fancy")
@PY.TOP_CMD
async def fancy_cmd(client, message):
    text = _get_text(message)
    if not text:
        return await message.reply("ketik text nya~", quote=True)
    await message.reply(to_fancy(text))


@PY.UBOT("gothic")
@PY.TOP_CMD
async def gothic_cmd(client, message):
    text = _get_text(message)
    if not text:
        return await message.reply("ketik text nya~", quote=True)
    await message.reply(to_gothic(text))


@PY.UBOT("kawaii")
@PY.TOP_CMD
async def kawaii_cmd(client, message):
    text = _get_text(message)
    if not text:
        return await message.reply("ketik text nya~ (◕ᴗ◕✿)", quote=True)
    await message.reply(to_kawaii(text))
