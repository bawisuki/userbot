from PyroUbot import *
import aiohttp

__MODULE__ = "ᴅᴏɢ ꜰᴀᴄᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}dogfact</code></b></blockquote>"""


@PY.UBOT("dogfact")
@PY.TOP_CMD
async def dogfact(client, message):
    """ᴅᴏɢ ꜰᴀᴄᴛ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://dog-api.kinduff.com/api/facts") as r:
                d = await r.json()
        await message.edit(f"<b>🐶 Dog Fact</b>\n\n{d['facts'][0]}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
