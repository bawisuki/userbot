from PyroUbot import *
import aiohttp

__MODULE__ = "ᴀᴅᴠɪᴄᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}advice</code></b></blockquote>"""


@PY.UBOT("advice")
@PY.TOP_CMD
async def advice(client, message):
    """ᴀᴅᴠɪᴄᴇ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api.adviceslip.com/advice") as r:
                d = await r.json(content_type=None)
        await message.edit(f"<b>💡 Advice</b>\n\n<i>{d['slip']['advice']}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
