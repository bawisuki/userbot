from PyroUbot import *
import aiohttp

__MODULE__ = "ɪɴᴅᴏɴᴇꜱɪᴀ"
__HELP__ = """
<blockquote><b>⎆ <code>{0}gempa2</code> ɢᴇᴍᴘᴀ ʙᴍᴋɢ
⎆ <code>{0}libur</code> [tahun] ʜᴀʀɪ ʟɪʙᴜʀ
⎆ <code>{0}kodepos</code> [area] ᴋᴏᴅᴇ ᴘᴏꜱ
⎆ <code>{0}plat</code> [kode] ᴘʟᴀᴛ ᴋᴇɴᴅᴀʀᴀᴀɴ
⎆ <code>{0}ceknik</code> [nik] ᴀɴᴀʟɪꜱɪꜱ ɴɪᴋ
⎆ <code>{0}umur</code> [DD-MM-YYYY] ʜɪᴛᴜɴɢ ᴜᴍᴜʀ
⎆ <code>{0}weton</code> [DD-MM-YYYY] ᴡᴇᴛᴏɴ ᴊᴀᴡᴀ
⎆ <code>{0}shio</code> [tahun] ꜱʜɪᴏ
⎆ <code>{0}pantun</code> ᴘᴀɴᴛᴜɴ
⎆ <code>{0}pepatah</code> ᴘᴇᴘᴀᴛᴀʜ</b></blockquote>
"""



@PY.UBOT("gempa2")
@PY.TOP_CMD
async def bmkg(client, message):
    """ɢᴇᴍᴘᴀ"""
    try:
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
        async with aiohttp.ClientSession() as s:
            async with s.get("https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json", headers=headers) as r:
                d = await r.json()
        g = d["Infogempa"]["gempa"]
        txt = (
            f"<b>🌍 Gempa Terkini (BMKG)</b>\n\n"
            f"<b>📅 Waktu:</b> {g['Tanggal']} {g['Jam']}\n"
            f"<b>📍 Lokasi:</b> {g['Wilayah']}\n"
            f"<b>💥 Magnitudo:</b> {g['Magnitude']}\n"
            f"<b>📏 Kedalaman:</b> {g['Kedalaman']}\n"
            f"<b>📍 Koordinat:</b> {g['Lintang']}, {g['Bujur']}\n"
            f"<b>⚠️ Potensi:</b> {g.get('Potensi','N/A')}"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
