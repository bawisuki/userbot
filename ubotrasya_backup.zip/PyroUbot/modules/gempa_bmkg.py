from PyroUbot import *
import aiohttp

__MODULE__ = "ɢᴇᴍᴘᴀ"
__HELP__ = """
<blockquote><b>꒰ 🌍 ꒱ ʙᴀɴᴛᴜᴀɴ ɪɴꜰᴏ ɢᴇᴍᴘᴀ BMKG
⎆ <code>{0}gempaterkini</code> ɢᴇᴍᴘᴀ ᴛᴇʀᴋɪɴɪ
⎆ <code>{0}gempaterasa</code> ɢᴇᴍᴘᴀ ᴅɪʀᴀꜱᴀᴋᴀɴ</b></blockquote>
"""


@PY.UBOT("gempaterkini")
@PY.TOP_CMD
async def gempaterkini_cmd(client, message):
    await message.edit("<b>꒰ 🌍 ꒱ ꜱᴇᴅᴀɴɢ ᴍᴇᴍᴜᴀᴛ...</b>")
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get("https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json") as resp:
                data = (await resp.json(content_type=None))["Infogempa"]["gempa"]
        text = (
            f"<b>꒰ 🌍 ꒱ ɢᴇᴍᴘᴀ ᴛᴇʀᴋɪɴɪ</b>\n\n"
            f"<b>📅 ᴡᴀᴋᴛᴜ:</b> {data['Tanggal']} {data['Jam']}\n"
            f"<b>📍 ᴡɪʟᴀʏᴀʜ:</b> {data['Wilayah']}\n"
            f"<b>💥 ᴍᴀɢɴɪᴛᴜᴅᴏ:</b> {data['Magnitude']}\n"
            f"<b>📏 ᴋᴇᴅᴀʟᴀᴍᴀɴ:</b> {data['Kedalaman']}\n"
            f"<b>🗺️ ᴋᴏᴏʀᴅɪɴᴀᴛ:</b> {data['Lintang']}, {data['Bujur']}\n"
            f"<b>⚠️ ᴘᴏᴛᴇɴꜱɪ:</b> {data['Potensi']}"
        )
        await message.edit(text)
    except Exception as e:
        await message.edit(f"<b>꒰ ❌ ꒱ ᴇʀʀᴏʀ:</b> <code>{e}</code>")


@PY.UBOT("gempaterasa")
@PY.TOP_CMD
async def gempaterasa_cmd(client, message):
    await message.edit("<b>꒰ 🌍 ꒱ ꜱᴇᴅᴀɴɢ ᴍᴇᴍᴜᴀᴛ...</b>")
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get("https://data.bmkg.go.id/DataMKG/TEWS/gempadirasakan.json") as resp:
                data = (await resp.json(content_type=None))["Infogempa"]["gempa"]
        text = "<b>꒰ 🌍 ꒱ ɢᴇᴍᴘᴀ ᴅɪʀᴀꜱᴀᴋᴀɴ</b>\n\n"
        for item in data[:5]:
            text += (
                f"• <b>{item['Wilayah']}</b>\n"
                f"  📅 {item['Tanggal']} {item['Jam']} | 💥 M{item['Magnitude']} | 📏 {item['Kedalaman']}\n\n"
            )
        await message.edit(text)
    except Exception as e:
        await message.edit(f"<b>꒰ ❌ ꒱ ᴇʀʀᴏʀ:</b> <code>{e}</code>")
