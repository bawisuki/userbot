from PyroUbot import *
import random

__MODULE__ = "ᴊᴀᴅᴡᴀʟ ᴛᴠ"
__HELP__ = """<blockquote><b>⎆ <code>{0}jadwaltv</code></b></blockquote>"""


@PY.UBOT("jadwaltv")
@PY.TOP_CMD
async def jadwaltv(client, message):
    """ᴊᴀᴅᴡᴀʟ ᴛᴠ"""
    try:
        channels = {"RCTI": "🔴","SCTV": "🟡","Trans TV": "🔵","Trans 7": "🟢","Indosiar": "🟣","ANTV": "🟠","TV One": "⚪","Metro TV": "🔵","NET TV": "🟢","GTV": "🔴"}
        txt = "<b>📺 Channel TV Indonesia</b>\n\n"
        for ch, emoji in channels.items():
            txt += f"{emoji} <b>{ch}</b>\n"
        txt += "\n<i>Untuk jadwal lengkap, kunjungi website masing-masing channel.</i>"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
