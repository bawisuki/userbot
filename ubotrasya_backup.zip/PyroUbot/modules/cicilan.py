from PyroUbot import *

__MODULE__ = "cicilan"
__HELP__ = """<blockquote><b>⎆ <code>{0}cicilan</code></b></blockquote>"""


@PY.UBOT("cicilan")
@PY.TOP_CMD
async def cicilan(client, message):
    """cicilan"""
    try:
        args = message.text.split()
        harga = float(args[1])
        dp_pct = float(args[2]) if len(args) > 2 else 20
        tenor = int(args[3]) if len(args) > 3 else 12
        dp = harga * dp_pct / 100
        sisa = harga - dp
        cicilan = sisa / tenor
        await message.edit(f"<b>💳 Cicilan</b>\n\n<b>Harga:</b> Rp{harga:,.0f}\n<b>DP ({dp_pct}%):</b> Rp{dp:,.0f}\n<b>Tenor:</b> {tenor} bulan\n<b>Cicilan/bln:</b> Rp{cicilan:,.0f}", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Provide valid numbers.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
