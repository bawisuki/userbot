from PyroUbot import *
import aiohttp

__MODULE__ = "ᴅᴏɢ ᴘɪᴄ"
__HELP__ = """<blockquote><b>⎆ <code>{0}dogpic</code></b></blockquote>"""


@PY.UBOT("dogpic")
@PY.TOP_CMD
async def dogpic(client, message):
    """ᴅᴏɢ ᴘɪᴄ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://dog.ceo/api/breeds/image/random") as r:
                d = await r.json()
        await message.edit(f"<b>🐕 Random Dog</b>\n\n<a href='{d['message']}'>🖼 View Image</a>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
