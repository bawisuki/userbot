from PyroUbot import *

__MODULE__ = "floor"
__HELP__ = """<blockquote><b>⎆ <code>{0}floor</code></b></blockquote>"""


@PY.UBOT("floor")
@PY.TOP_CMD
async def floor_calc(client, message):
    """floor"""
    try:
        import math
        val = float(message.text.split(None, 1)[1])
        await message.edit(f"<b>⌊{val}⌋ = {math.floor(val)}</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Provide valid numbers.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
