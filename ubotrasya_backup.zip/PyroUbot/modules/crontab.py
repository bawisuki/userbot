from PyroUbot import *

__MODULE__ = "ᴄʀᴏɴ"
__HELP__ = """<blockquote><b>⎆ <code>{0}cron</code></b></blockquote>"""


@PY.UBOT("cron")
@PY.TOP_CMD
async def crontab(client, message):
    """ᴄʀᴏɴ"""
    try:
        expr = message.text.split(None, 1)[1] if len(message.text.split()) > 1 else "* * * * *"
        parts = expr.split()
        if len(parts) != 5:
            return await message.edit("<b>⚠️ Format: minute hour day month weekday</b>", parse_mode=ParseMode.HTML)
        fields = ["Minute", "Hour", "Day of Month", "Month", "Day of Week"]
        txt = f"<b>⏰ Cron Expression: <code>{expr}</code></b>\n\n"
        for i, (f, v) in enumerate(zip(fields, parts)):
            txt += f"<b>{f}:</b> {v}\n"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
