from PyroUbot import *

__MODULE__ = "ᴀᴇꜱᴛʜᴇᴛɪᴄ"
__HELP__ = """<blockquote><b>⎆ <code>{0}aesthetic</code></b></blockquote>"""


@PY.UBOT("aesthetic")
@PY.TOP_CMD
async def aesthetic(client, message):
    """ᴀᴇꜱᴛʜᴇᴛɪᴄ"""
    try:
        text = message.text.split(None, 1)[1]
        result = "".join(chr(0xFEE0 + ord(c)) if 0x21 <= ord(c) <= 0x7E else c for c in text)
        await message.edit(f"<code>{result}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.aesthetic text</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
