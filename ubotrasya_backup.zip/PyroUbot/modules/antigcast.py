import asyncio
import json
import os
import re

from pyrogram import filters
from pyrogram.enums import ChatType
from pyrogram.errors.exceptions.bad_request_400 import MessageTooLong
from PyroUbot import *
from PyroUbot.core.database import db_exec, db_fetchone

__MODULE__ = "ᴀɴᴛɪɢᴄᴀsᴛ"
__HELP__ = """

<b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴀɴᴛɪɢᴄᴀsᴛ ⦫</b>
<blockquote><b>
⎆ ᴘᴇʀɪɴᴛᴀʜ :
ᚗ <code>{0}on</code> [on atau off] 
⊷ ᴜɴᴛᴜᴋ ᴍᴇɴɢʜɪᴅᴜᴘᴋᴀɴ ᴀᴛᴀᴜ ᴍᴇᴍᴀᴛɪᴋᴀɴ ᴀɴᴛɪɢᴄᴀꜱᴛ

ᚗ <code>{0}listduar</code> 
⊷ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴅᴀꜰᴛᴀʀ ᴘᴇɴɢɢᴜɴᴀ ʏᴀɴɢ ᴅɪ ʙᴀʟᴄᴋʟɪꜱᴛ

ᚗ <code>{0}duar</code> 
⊷ ᴜɴᴛᴜᴋ ᴍᴇɴᴀᴍʙᴀʜ ᴘᴇɴɢɢᴜɴᴀ ᴋᴇ ᴅᴀʟᴀᴍ ᴅᴀᴛᴀʙᴀꜱᴇ ᴀɴᴛɪɢᴄᴀꜱᴛ

ᚗ <code>{0}unduar</code> 
⊷ ᴜɴᴛᴜᴋ ᴍᴇɴɢʜᴀᴘᴜꜱ ᴘᴇɴɢɢᴜɴᴀ ᴅɪ ᴅᴀʟᴀᴍ ᴅᴀᴛᴀʙᴀꜱᴇ ᴀɴᴛɪɢᴄᴀꜱᴛ

ᚗ <code>{0}liat</code> 
⊷ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ᴀᴘᴀᴋᴀʜ ᴀɴᴛɪɢᴄᴀꜱᴛ ᴛᴇʟᴀʜ ᴅɪ ᴀᴋᴛɪꜰᴋᴀɴ

ᚗ <code>{0}addgc</code> 
⊷ ᴜɴᴛᴜᴋ ᴍᴇɴᴀᴍʙᴀʜ ɢʀᴜᴘ ꜱᴇʙᴀɢᴀɪ ᴀɴᴛɪɢᴄᴀꜱᴛ

ᚗ <code>{0}rmgc</code> 
⊷ ᴜɴᴛᴜᴋ ᴍᴇɴɢʜᴀᴘᴜꜱ ɢʀᴜᴘ ꜱᴇʙᴀɢᴀɪ ᴀɴᴛɪɢᴄᴀꜱᴛ

ᚗ <code>{0}listgc</code> 
⊷ ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ɢʀᴜᴘ ᴀɴᴛɪɢᴄᴀꜱᴛ</b>

ᚗ <code>{0}b</code> balas ke pesan 
⊷ ᴜɴᴛᴜᴋ ᴍᴇɴᴀᴍʙᴀʜ ᴘᴇꜱᴀɴ ᴀɴᴛɪɢᴄᴀꜱᴛ

ᚗ <code>{0}cekbl</code> 
⊷ ᴜɴᴛᴜᴋ ᴍᴇɴɢᴇᴄᴇᴋ ᴅᴀꜰᴛᴀʀ ᴋᴀᴛᴀ ʏɢ ᴅɪ ʙʟᴀᴄᴋʟɪꜱᴛ

ᚗ <code>{0}rmb</code> 
⊷ ᴜɴᴛᴜᴋ ᴍᴇɴɢʜᴀᴘᴜꜱ ᴋᴀᴛᴀ ʏᴀɴɢ ᴅɪ ʙʟᴀᴄᴋʟɪꜱᴛ
</blockquote>

"""


# --- DB helpers for antigcast module ---

async def _get_user_ids(client_id):
    row = await db_fetchone("SELECT user_dia FROM antigcast WHERE client_id=%s", (client_id,))
    if row and row["user_dia"]:
        return json.loads(row["user_dia"])
    return []


async def _set_user_ids(client_id, user_list):
    data = json.dumps(user_list)
    await db_exec(
        "INSERT INTO antigcast (client_id, user_dia) VALUES (%s, %s) ON DUPLICATE KEY UPDATE user_dia=%s",
        (client_id, data, data),
    )


async def get_blacklist_status(client_id):
    row = await db_fetchone("SELECT status FROM antigcast_settings WHERE client_id=%s", (client_id,))
    return bool(row["status"]) if row else False


async def set_blacklist_status(client_id, status):
    await db_exec(
        "INSERT INTO antigcast_settings (client_id, status) VALUES (%s, %s) ON DUPLICATE KEY UPDATE status=%s",
        (client_id, int(status), int(status)),
    )


async def get_chat_ids(client_id):
    row = await db_fetchone("SELECT grup FROM antigcast_groups WHERE client_id=%s", (client_id,))
    if row and row["grup"]:
        return json.loads(row["grup"])
    return []


async def _set_chat_ids(client_id, chat_list):
    data = json.dumps(chat_list)
    await db_exec(
        "INSERT INTO antigcast_groups (client_id, grup) VALUES (%s, %s) ON DUPLICATE KEY UPDATE grup=%s",
        (client_id, data, data),
    )


async def get_msg_ids(client_id):
    row = await db_fetchone("SELECT msg_text FROM antigcast_messages WHERE client_id=%s", (client_id,))
    if row and row["msg_text"]:
        return json.loads(row["msg_text"])
    return []


async def _set_msg_ids(client_id, msg_list):
    data = json.dumps(msg_list)
    await db_exec(
        "INSERT INTO antigcast_messages (client_id, msg_text) VALUES (%s, %s) ON DUPLICATE KEY UPDATE msg_text=%s",
        (client_id, data, data),
    )


async def purge(message):
    await asyncio.sleep(0.5)
    await message.delete()


def emoji(alias):
    emojis = {
        "bintang": "<emoji id=5931592939514892319>⭐</emoji>",
        "gagal": "<emoji id=6278161560095426411>❌</emoji>",
        "done": "<emoji id=5852871561983299073>✅</emoji>",
        "roses": "<emoji id=5341312820698948923>🙃</emoji>",
        "on": "<emoji id=6275808772715710450>🎚️</emoji>",
        "off": "<emoji id=6276295366740543459>⛔</emoji>",
        "daftar": "<emoji id=5974045315391556490>📝</emoji>",
    }
    return emojis.get(alias, "")


Q = emoji("bintang")
gagal = emoji("gagal")
batal = emoji("gagal")
dn = emoji("done")
on = emoji("on")
off = emoji("off")
dftr = emoji("daftar")


@PY.UBOT("duar")
@PY.TOP_CMD
async def add_user_to_blacklist(c, m):
    if len(m.command) != 2 and not m.reply_to_message:
        await m.reply_text(f"{batal}**gunakan format** : `duar` **user id atau balas ke pesan**", quote=True)
        return

    if m.reply_to_message:
        user_id = m.reply_to_message.from_user.id
    else:
        try:
            user_id = int(m.command[1])
        except ValueError:
            try:
                user = await c.get_users(m.command[1])
                user_id = user.id
            except Exception:
                await m.reply_text(f"{gagal} Tidak dapat menemukan pengguna", quote=True)
                return

    user_ids = await _get_user_ids(c.me.id)
    if user_id not in user_ids:
        user_ids.append(user_id)
        await _set_user_ids(c.me.id, user_ids)
        await m.reply_text(f"{Q}**user** `{user_id}` **ditambahkan ke antigcast** {dn}", quote=True)
    else:
        await m.reply_text(f"{dn}**user sudah ada dalam daftar antigcast**", quote=True)


@PY.UBOT("listduar")
@PY.TOP_CMD
async def display_blacklist(client, message):
    user_ids = await _get_user_ids(client.me.id)
    await message.reply_text(f"{dftr} daftar: `{user_ids}`", quote=True)


@PY.UBOT("unduar")
@PY.TOP_CMD
async def remove_user_from_blacklist(c, m):
    if len(m.command) != 2 and not m.reply_to_message:
        await m.reply_text(f"{batal}**gunakan format** : `unduar` **user id atau balas ke pesan**", quote=True)
        return

    if m.reply_to_message:
        user_id = m.reply_to_message.from_user.id
    else:
        user_id = int(m.command[1])

    user_ids = await _get_user_ids(c.me.id)
    if user_id in user_ids:
        user_ids.remove(user_id)
        await _set_user_ids(c.me.id, user_ids)
        await m.reply_text(f"{Q}**user** `{user_id}` **dihapus dari antigcast** {dn}", quote=True)
    else:
        await m.reply_text(f"{Q}**user tidak ada dalam daftar antigcast** {gagal}", quote=True)


@PY.UBOT("liat")
@PY.TOP_CMD
async def checkstatus(client, message):
    cek = await get_blacklist_status(client.me.id)
    if cek:
        await message.reply_text(f"{Q}**antigcast aktif**{dn}", quote=True)
    else:
        await message.reply_text(f"{Q}**antigcast belum aktif**{gagal}", quote=True)


@PY.UBOT("on")
@PY.TOP_CMD
async def enable_blacklist(c, m):
    await set_blacklist_status(c.me.id, True)
    await m.reply_text(f"{Q}**antigcast diaktifkan** {on}", quote=True)


@PY.UBOT("off")
@PY.TOP_CMD
async def disable_blacklist(c, m):
    await set_blacklist_status(c.me.id, False)
    await m.reply_text(f"{Q}**antigcast dimatikan** {off}", quote=True)


@PY.UBOT("addgc")
@PY.TOP_CMD
async def add_group_to_antigcast(c, m):
    if m.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await m.reply_text(f"{gagal}gunakan fitur ini di grup!")
        return

    chat_id = m.chat.id
    chat_ids = await get_chat_ids(c.me.id)
    if chat_id not in chat_ids:
        chat_ids.append(chat_id)
        await _set_chat_ids(c.me.id, chat_ids)
        await m.reply_text(f"{Q}**grup** `{chat_id}` **ditambahkan ke antigcast** {dn}", quote=True)
    else:
        await m.reply_text(f"{dn}**grup sudah ada dalam daftar antigcast**", quote=True)


@PY.UBOT("rmgc")
@PY.TOP_CMD
async def remove_group_from_antigcast(c, m):
    if m.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await m.reply_text(f"{gagal} Gunakan fitur ini di grup", quote=True)
        return

    chat_id = int(m.command[1]) if len(m.command) >= 2 else m.chat.id

    chat_ids = await get_chat_ids(c.me.id)
    if chat_id in chat_ids:
        chat_ids.remove(chat_id)
        await _set_chat_ids(c.me.id, chat_ids)
        await m.reply_text(f"{Q} Grup {chat_id} dihapus dari antigcast {dn}", quote=True)
    else:
        await m.reply_text(f"{Q} Grup {chat_id} tidak ada dalam daftar {gagal}", quote=True)


@PY.UBOT("listgc")
@PY.TOP_CMD
async def display_antigcast(c, m):
    chat_ids = await get_chat_ids(c.me.id)
    await m.reply_text(f"{dftr}**daftar grup antigcast** : `{chat_ids}`", quote=True)


@PY.UBOT("b")
@PY.TOP_CMD
async def add_pesan(c, m):
    _rply = m.reply_to_message
    if not _rply:
        await m.reply(f"mohon balas ke pesan")
        return
    user_text = _rply.text
    msg_ids = await get_msg_ids(c.me.id)
    if user_text not in msg_ids:
        msg_ids.append(user_text)
        await _set_msg_ids(c.me.id, msg_ids)
        sukses = await m.reply_text(f"pesan berhasil ditambahkan{dn}", quote=True)
        await _rply.delete()
        await purge(m)
        await sukses.delete()
    else:
        x = await m.reply_text(f"pesan sudah ada di database{gagal}", quote=True)
        await asyncio.sleep(0.5)
        await x.delete()


@PY.UBOT("cekbl")
@PY.TOP_CMD
async def strdb(client, message):
    pesan = await get_msg_ids(client.me.id)
    try:
        await message.reply_text(str(pesan))
    except MessageTooLong:
        with open("db.txt", "w", encoding="utf-8") as file:
            file.write(str(pesan))
        await message.reply_document("db.txt")
        os.remove("db.txt")


@PY.UBOT("rmb")
@PY.TOP_CMD
async def remove_kata_from_blacklist(c, m):
    if len(m.command) != 2 and not m.reply_to_message:
        await m.reply_text(f"{batal}**gunakan format** : `rmb` **kata atau balas ke pesan**", quote=True)
        return

    if m.reply_to_message:
        user_id = m.reply_to_message.text
    else:
        user_id = " ".join(m.command[1:])

    msg_ids = await get_msg_ids(c.me.id)
    if user_id in msg_ids:
        msg_ids.remove(user_id)
        await _set_msg_ids(c.me.id, msg_ids)
        await m.reply_text(f"{Q}**berhasil menghapus** `{user_id}` **dari blacklist** {dn}", quote=True)
    else:
        await m.reply_text(f"{Q}**kata tidak ada dalam daftar** {gagal}", quote=True)


@ubot.on_message(filters.group & ~filters.me, group=75)
async def delete_messages(client, message):
    try:
        chat_ids = await get_chat_ids(client.me.id)
        if message.chat.id not in chat_ids:
            return

        blacklist_status = await get_blacklist_status(client.me.id)
        if not blacklist_status:
            return

        user_ids = await _get_user_ids(client.me.id)
        user_msg_patterns = await get_msg_ids(client.me.id)

        if message.from_user.id in user_ids:
            return await message.delete()
        else:
            for pattern in user_msg_patterns:
                if message.text and re.search(pattern, message.text):
                    await message.delete()
                    return
    except Exception:
        pass
