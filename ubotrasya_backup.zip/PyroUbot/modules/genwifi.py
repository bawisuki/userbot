from PyroUbot import *

__MODULE__ = "📶 WiFi P"
__HELP__ = """<blockquote><b>⎆ <code>{0}genwifi</code></b></blockquote>"""


@PY.UBOT("genwifi")
@PY.TOP_CMD
async def genwifi(client, message):
    """📶 WiFi P"""
    try:
        import random, string, uuid, hashlib, os, secrets, base64
        r = ''.join(__import__('random').choices(__import__('string').ascii_letters + __import__('string').digits, k=12))
        await message.edit(f"<b>📶 WiFi Pass</b>\n\n<code>{str(r)}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
