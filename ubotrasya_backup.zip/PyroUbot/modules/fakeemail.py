from PyroUbot import *
import random, string

__MODULE__ = "ᴛᴇᴍᴘᴍᴀɪʟ"
__HELP__ = """<blockquote><b>⎆ <code>{0}tempmail2</code></b></blockquote>"""


@PY.UBOT("tempmail2")
@PY.TOP_CMD
async def fakeemail(client, message):
    """ᴛᴇᴍᴘᴍᴀɪʟ"""
    try:
        domains = ["tempmail.com", "guerrillamail.com", "sharklasers.com", "grr.la", "guerrillamailblock.com"]
        emails = []
        for _ in range(3):
            name = "".join(random.choices(string.ascii_lowercase + string.digits, k=10))
            domain = random.choice(domains)
            emails.append(f"{name}@{domain}")
        txt = "<b>📧 Temporary Emails</b>\n\n" + "\n".join([f"• <code>{e}</code>" for e in emails])
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
