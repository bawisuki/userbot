from PyroUbot import *
import aiohttp

__MODULE__ = "ɪᴘ ɪɴꜰᴏ ip2"
__HELP__ = """<blockquote><b>⎆ <code>{0}ip2</code></b></blockquote>"""


@PY.UBOT("ip2")
@PY.TOP_CMD
async def ipinfo2(client, message):
    """ɪᴘ ɪɴꜰᴏ"""
    try:
        ip = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"http://ip-api.com/json/{ip}?fields=status,message,country,regionName,city,zip,lat,lon,timezone,isp,org,as,query") as r:
                d = await r.json()
        if d["status"] == "fail":
            return await message.edit(f"<b>❌ {d.get('message','Failed')}</b>", parse_mode=ParseMode.HTML)
        txt = f"<b>🌐 IP: {d['query']}</b>\n\n<b>🏳️ Country:</b> {d['country']}\n<b>🏙 City:</b> {d['city']}\n<b>📮 ZIP:</b> {d['zip']}\n<b>🌐 ISP:</b> {d['isp']}\n<b>🏢 Org:</b> {d['org']}\n<b>⏰ TZ:</b> {d['timezone']}\n<b>📍 Coords:</b> {d['lat']}, {d['lon']}"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.ip2 address</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
