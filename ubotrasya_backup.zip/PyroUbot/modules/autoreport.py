from pyrogram.errors import UsernameInvalid, PeerIdInvalid
from PyroUbot import PY

__MODULE__ = "ᴀᴜᴛᴏʀᴇᴘᴏʀᴛ"
__HELP__ = """
<blockquote><b>📌 Auto Report Telegram</b>

• Report user / channel / group
• Contoh:
<code>.report username</code>
<code>.report https://t.me/channel</code>
</blockquote>
"""

@PY.UBOT("report")
@PY.TOP_CMD
async def _(client, message):
    msg = await message.reply("🔍 Memproses laporan...")

    try:
        if len(message.command) < 2:
            return await msg.edit(
                "❌ Masukkan username atau link!\n"
                "Contoh:\n"
                "<code>.report username</code>\n"
                "<code>.report https://t.me/channel</code>"
            )

        target = message.command[1].strip()

        # Bersihkan @
        if target.startswith("@"):
            target = target[1:]

        # Format laporan RESMI
        report_text = f"""
<b>Scam Report</b>

• Scammer Username / Target: <code>{target}</code>
• Scam Type: Fake promotion / fake bot services

Description:
The user offers promotion and bot services for Telegram channels and groups.
After receiving payment, the user blocks the client and does not deliver the promised service.

Reported by: {message.from_user.mention}
"""

        # 🔹 Grup privat (pastikan akun sudah join)
        private_group = "https://t.me/+PrivateGroupLink"
        await client.send_message(private_group, report_text)

        # 🔹 Channel report (tanpa @)
        report_channel = "YourReportChannel"
        await client.send_message(report_channel, report_text)

        # 🔹 NoToScam (OPTIONAL, jangan sampai crash)
        try:
            await client.send_message(
                "NoToScam",
                f"User {target} involved in scam activity. Fake promotion / bot services."
            )
        except (UsernameInvalid, PeerIdInvalid):
            pass

        await msg.edit("✅ Laporan berhasil dikirim.")

    except Exception as e:
        await msg.edit(f"❌ Error:\n<code>{e}</code>")