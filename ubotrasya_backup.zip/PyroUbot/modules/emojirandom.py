from PyroUbot import *
import aiohttp

__MODULE__ = "ᴇᴍᴏᴊɪ ʀᴀɴᴅᴏᴍ"
__HELP__ = """<blockquote><b>⎆ <code>{0}emoji_random</code></b></blockquote>"""


@PY.UBOT("emoji_random")
@PY.TOP_CMD
async def emoji_random(client, message):
    """ᴇᴍᴏᴊɪ ʀᴀɴᴅᴏᴍ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://emojihub.yurace.pro/api/random") as r:
                d = await r.json()
        txt = (
            f"<b>😀 Random Emoji</b>\n\n"
            f"<b>Name:</b> {d['name']}\n"
            f"<b>Category:</b> {d['category']}\n"
            f"<b>Group:</b> {d['group']}\n"
            f"<b>Unicode:</b> {' '.join(d['unicode'])}"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
