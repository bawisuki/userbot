from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄᴀᴛ ꜰᴀᴄᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}catfact</code></b></blockquote>"""


@PY.UBOT("catfact")
@PY.TOP_CMD
async def catfact(client, message):
    """ᴄᴀᴛ ꜰᴀᴄᴛ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://catfact.ninja/fact") as r:
                d = await r.json()
        await message.edit(f"<b>🐱 Cat Fact</b>\n\n{d['fact']}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
