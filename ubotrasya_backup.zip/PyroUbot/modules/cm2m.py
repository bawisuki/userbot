from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ cm2m"
__HELP__ = """<blockquote><b>⎆ <code>{0}cm2m</code></b></blockquote>"""


@PY.UBOT("cm2m")
@PY.TOP_CMD
async def cm2m(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val/100
        await message.edit(f"<b>📐 {val} cm = {result:.6g} meters</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.cm2m value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
