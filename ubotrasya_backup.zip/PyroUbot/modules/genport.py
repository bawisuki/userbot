from PyroUbot import *

__MODULE__ = "🔌 Random"
__HELP__ = """<blockquote><b>⎆ <code>{0}genport</code></b></blockquote>"""


@PY.UBOT("genport")
@PY.TOP_CMD
async def genport(client, message):
    """🔌 Random"""
    try:
        import random, string, uuid, hashlib, os, secrets, base64
        r = __import__('random').randint(1024, 65535)
        await message.edit(f"<b>🔌 Random Port</b>\n\n<code>{str(r)}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
