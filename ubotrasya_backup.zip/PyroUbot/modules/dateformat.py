from PyroUbot import *
from datetime import datetime

__MODULE__ = "ᴅᴀᴛᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}dateformat</code></b></blockquote>"""


@PY.UBOT("dateformat")
@PY.TOP_CMD
async def dateformat(client, message):
    """ᴅᴀᴛᴇ"""
    try:
        now = datetime.now()
        formats = [
            ("ISO", now.strftime("%Y-%m-%dT%H:%M:%S")),
            ("US", now.strftime("%m/%d/%Y")),
            ("EU", now.strftime("%d/%m/%Y")),
            ("Long", now.strftime("%B %d, %Y")),
            ("Time", now.strftime("%H:%M:%S")),
        ]
        txt = "<b>📅 Date Formats</b>\n\n"
        for name, fmt in formats:
            txt += f"<b>{name}:</b> <code>{fmt}</code>\n"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
