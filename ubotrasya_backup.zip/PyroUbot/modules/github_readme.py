from PyroUbot import *
import aiohttp
from urllib.parse import quote

__MODULE__ = "ɢʜ ʀᴇᴀᴅᴍᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}ghreadme</code></b></blockquote>"""


@PY.UBOT("ghreadme")
@PY.TOP_CMD
async def github_readme(client, message):
    """ɢʜ ʀᴇᴀᴅᴍᴇ"""
    try:
        repo = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://raw.githubusercontent.com/{repo}/main/README.md") as r:
                if r.status != 200:
                    async with s.get(f"https://raw.githubusercontent.com/{repo}/master/README.md") as r2:
                        text = await r2.text()
                else:
                    text = await r.text()
        await message.edit(f"<b>📄 README: {repo}</b>\n\n<code>{text[:3500]}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.ghreadme user/repo</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
