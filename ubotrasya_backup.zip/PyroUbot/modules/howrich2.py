from PyroUbot import *
import random

__MODULE__ = "💎"
__HELP__ = """<blockquote><b>⎆ <code>{0}howrich2</code></b></blockquote>"""


@PY.UBOT("howrich2")
@PY.TOP_CMD
async def howrich2(client, message):
    """💎"""
    try:
        target = message.reply_to_message.from_user.first_name if message.reply_to_message else "You"
        pct = random.randint(0, 100)
        await message.edit(f"<b>💎 How Rich?</b>\n\n{target} is <b>{pct}%</b> rich!", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
