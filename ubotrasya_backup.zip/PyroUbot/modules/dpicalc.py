from PyroUbot import *

__MODULE__ = "🖥 DPI"
__HELP__ = """<blockquote><b>⎆ <code>{0}dpi</code></b></blockquote>"""


@PY.UBOT("dpi")
@PY.TOP_CMD
async def dpicalc(client, message):
    """🖥 DPI"""
    try:
        args = message.text.split()
        px = float(args[1])
        inch = float(args[2])
        dpi = px / inch
        await message.edit(f"<b>🖥 DPI Calculator</b>\n\n<b>Pixels:</b> {px:.0f}\n<b>Size:</b> {inch} inches\n<b>DPI:</b> {dpi:.0f}", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Usage:</b> <code>.dpi width_px distance_inch</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
