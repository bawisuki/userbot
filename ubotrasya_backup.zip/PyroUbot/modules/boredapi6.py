from PyroUbot import *
import aiohttp

__MODULE__ = "ʙᴏʀᴇᴅ 6"
__HELP__ = """<blockquote><b>⎆ <code>{0}bored6</code></b></blockquote>"""


@PY.UBOT("bored6")
@PY.TOP_CMD
async def bored6(client, message):
    """ʙᴏʀᴇᴅ 6"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://bored-api.appbrewery.com/random?type=music") as r:
                d = await r.json()
        await message.edit(f"<b>🎵 Music Activity</b>\n\n{d['activity']}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
