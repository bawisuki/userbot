from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ ev2j"
__HELP__ = """<blockquote><b>⎆ <code>{0}ev2j</code></b></blockquote>"""


@PY.UBOT("ev2j")
@PY.TOP_CMD
async def ev2j(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val*1.602e-19
        await message.edit(f"<b>📐 {val} eV = {result:.6g} joules</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.ev2j value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
