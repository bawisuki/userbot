from PyroUbot import *
import random

__MODULE__ = "🎮 Gaming"
__HELP__ = """<blockquote><b>⎆ <code>{0}gamefact</code></b></blockquote>"""


@PY.UBOT("gamefact")
@PY.TOP_CMD
async def game2(client, message):
    """🎮 Gaming"""
    try:
        items = ['The first video game was created in 1958.', 'Minecraft has sold over 238 million copies.', 'The Game Boy survived a bombing in the Gulf War and still works.', 'Pac-Man was originally called Puck-Man.', 'The average gamer is 34 years old.']
        await message.edit(f"<b>🎮 Gaming</b>\n\n<i>{random.choice(items)}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
