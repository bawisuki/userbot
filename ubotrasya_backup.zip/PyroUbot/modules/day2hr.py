from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ day2hr"
__HELP__ = """<blockquote><b>⎆ <code>{0}day2hr</code></b></blockquote>"""


@PY.UBOT("day2hr")
@PY.TOP_CMD
async def day2hr(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val*24
        await message.edit(f"<b>📐 {val} days = {result:.6g} hours</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.day2hr value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
