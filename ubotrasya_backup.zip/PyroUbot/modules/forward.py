from PyroUbot import *

__MODULE__ = "ꜰᴏʀᴡᴀʀᴅ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ꜰᴏʀᴡᴀʀᴅ

⎆ <code>{0}fwd</code> [chat_id]
   ꜰᴏʀᴡᴀʀᴅ ᴘᴇꜱᴀɴ ʏᴀɴɢ ᴅɪ-ʀᴇᴘʟʏ ᴋᴇ ᴄʜᴀᴛ ʟᴀɪɴ</b></blockquote>
"""


@PY.UBOT("fwd")
@PY.TOP_CMD
async def fwd(client, message):
    try:
        reply = message.reply_to_message
        if not reply:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ʀᴇᴘʟʏ ᴋᴇ ᴘᴇꜱᴀɴ!</b>", parse_mode=ParseMode.HTML)
        args = message.text.split(None, 1)
        if len(args) < 2:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.fwd [chat_id]</code>", parse_mode=ParseMode.HTML)
        chat_id = int(args[1]) if args[1].lstrip("-").isdigit() else args[1]
        await reply.forward(chat_id)
        await message.edit("<emoji id=5206607081334906820>✅</emoji> <b>ᴘᴇꜱᴀɴ ʙᴇʀʜᴀꜱɪʟ ᴅɪ-ꜰᴏʀᴡᴀʀᴅ!</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)
