from PyroUbot import *

__MODULE__ = "ʙᴜʙʙʟᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}bubble</code></b></blockquote>"""


@PY.UBOT("bubble")
@PY.TOP_CMD
async def bubble(client, message):
    """ʙᴜʙʙʟᴇ"""
    try:
        text = message.text.split(None, 1)[1]
        result = "".join(chr(0x24B6 + ord(c.upper()) - 65) if c.isalpha() else c for c in text)
        await message.edit(f"<code>{result}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.bubble text</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
