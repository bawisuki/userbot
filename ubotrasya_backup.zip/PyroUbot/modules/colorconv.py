from PyroUbot import *

__MODULE__ = "ᴄᴏʟᴏʀ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴄᴏʟᴏʀ

⎆ <code>{0}hex2rgb</code> [hex] ᴋᴏɴᴠᴇʀꜱɪ ʜᴇx ᴋᴇ ʀɢʙ
⎆ <code>{0}rgb2hex</code> [r] [g] [b] ᴋᴏɴᴠᴇʀꜱɪ ʀɢʙ ᴋᴇ ʜᴇx</b></blockquote>
"""


@PY.UBOT("hex2rgb")
@PY.TOP_CMD
async def hex2rgb_cmd(client, message):
    args = message.text.split(None, 1)
    if len(args) < 2:
        return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.hex2rgb [hex]</code>", parse_mode=ParseMode.HTML)
    try:
        h = args[1].lstrip("#")
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>#{h.upper()}</b> = <code>RGB({r}, {g}, {b})</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("rgb2hex")
@PY.TOP_CMD
async def rgb2hex_cmd(client, message):
    args = message.text.split()
    if len(args) < 4:
        return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.rgb2hex [r] [g] [b]</code>", parse_mode=ParseMode.HTML)
    try:
        r, g, b = int(args[1]), int(args[2]), int(args[3])
        hex_color = "#{:02X}{:02X}{:02X}".format(r, g, b)
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>RGB({r}, {g}, {b})</b> = <code>{hex_color}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
