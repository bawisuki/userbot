from PyroUbot import *
import aiohttp
import json

__MODULE__ = "ᴅɪɢɪᴛᴀʟᴏᴄᴇᴀɴ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴅɪɢɪᴛᴀʟᴏᴄᴇᴀɴ

⎆ <code>{0}dotoken</code> [token] ꜱᴇᴛ ᴀᴘɪ ᴛᴏᴋᴇɴ
⎆ <code>{0}dobal</code> ᴄᴇᴋ ꜱᴀʟᴅᴏ
⎆ <code>{0}dolist</code> ʟɪꜱᴛ ᴅʀᴏᴘʟᴇᴛ
⎆ <code>{0}docreate</code> [nama] [region] [size] [image] ʙᴜᴀᴛ
⎆ <code>{0}dodel</code> [id] ʜᴀᴘᴜꜱ ᴅʀᴏᴘʟᴇᴛ
⎆ <code>{0}doreboot</code> [id] ʀᴇꜱᴛᴀʀᴛ
⎆ <code>{0}dooff</code> [id] ᴍᴀᴛɪᴋᴀɴ
⎆ <code>{0}doon</code> [id] ɴʏᴀʟᴀᴋᴀɴ
⎆ <code>{0}doinfo</code> [id] ɪɴꜰᴏ ᴅᴇᴛᴀɪʟ
⎆ <code>{0}doregion</code> ʟɪꜱᴛ ʀᴇɢɪᴏɴ
⎆ <code>{0}dosize</code> ʟɪꜱᴛ ꜱɪᴢᴇ
⎆ <code>{0}doimage</code> ʟɪꜱᴛ ᴏꜱ</b></blockquote>
"""

DO_API = "https://api.digitalocean.com/v2"


async def do_req(token, method, endpoint, data=None):
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    async with aiohttp.ClientSession() as s:
        async with s.request(method, f"{DO_API}/{endpoint}", headers=headers, json=data) as r:
            if r.status == 204:
                return {"status": 204}
            return await r.json()


async def get_token(client):
    return await get_vars(client.me.id, "DO_TOKEN")


@PY.UBOT("dotoken")
@PY.TOP_CMD
async def do_token(client, message):
    try:
        args = message.text.split(None, 1)
        if len(args) < 2:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.dotoken [api_token]</code>", parse_mode=ParseMode.HTML)
        await set_vars(client.me.id, "DO_TOKEN", args[1])
        await message.edit("<emoji id=5206607081334906820>✅</emoji> <b>ᴛᴏᴋᴇɴ ᴅɪɢɪᴛᴀʟᴏᴄᴇᴀɴ ᴅɪꜱɪᴍᴘᴀɴ!</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("dobal")
@PY.TOP_CMD
async def do_balance(client, message):
    try:
        token = await get_token(client)
        if not token:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ꜱᴇᴛ ᴛᴏᴋᴇɴ ᴅᴜʟᴜ:</b> <code>.dotoken [token]</code>", parse_mode=ParseMode.HTML)
        await message.edit("<emoji id=5789858554890425372>🔄</emoji> <b>ᴍᴇᴍᴜᴀᴛ...</b>", parse_mode=ParseMode.HTML)
        res = await do_req(token, "GET", "customers/my/balance")
        if "account_balance" not in res:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴀɢᴀʟ! ᴄᴇᴋ ᴛᴏᴋᴇɴ.</b>", parse_mode=ParseMode.HTML)
        await message.edit(
            f"<emoji id=5206607081334906820>✅</emoji> <b>ꜱᴀʟᴅᴏ ᴅɪɢɪᴛᴀʟᴏᴄᴇᴀɴ</b>\n\n"
            f"<b>⎆ ʙᴀʟᴀɴᴄᴇ:</b> <code>${res['account_balance']}</code>\n"
            f"<b>⎆ ᴘᴇɴᴅɪɴɢ:</b> <code>${res['month_to_date_usage']}</code>",
            parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("dolist")
@PY.TOP_CMD
async def do_list(client, message):
    try:
        token = await get_token(client)
        if not token:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ꜱᴇᴛ ᴛᴏᴋᴇɴ ᴅᴜʟᴜ:</b> <code>.dotoken [token]</code>", parse_mode=ParseMode.HTML)
        await message.edit("<emoji id=5789858554890425372>🔄</emoji> <b>ᴍᴇᴍᴜᴀᴛ...</b>", parse_mode=ParseMode.HTML)
        res = await do_req(token, "GET", "droplets")
        droplets = res.get("droplets", [])
        if not droplets:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴅʀᴏᴘʟᴇᴛ!</b>", parse_mode=ParseMode.HTML)
        text = "<emoji id=5206607081334906820>✅</emoji> <b>ᴅᴀꜰᴛᴀʀ ᴅʀᴏᴘʟᴇᴛ:</b>\n\n"
        for d in droplets[:10]:
            ip = d["networks"]["v4"][0]["ip_address"] if d["networks"]["v4"] else "N/A"
            text += f"<b>⎆ {d['name']}</b> | ID: <code>{d['id']}</code>\n   IP: <code>{ip}</code> | {d['status']}\n\n"
        await message.edit(text[:4096], parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("docreate")
@PY.TOP_CMD
async def do_create(client, message):
    try:
        args = message.text.split(None, 4)
        if len(args) < 5:
            return await message.edit(
                "<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b>\n"
                "<code>.docreate [nama] [region] [size] [image]</code>\n\n"
                "<b>ᴄᴏɴᴛᴏʜ:</b>\n<code>.docreate myserver sgp1 s-1vcpu-1gb ubuntu-22-04-x64</code>",
                parse_mode=ParseMode.HTML)
        token = await get_token(client)
        if not token:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ꜱᴇᴛ ᴛᴏᴋᴇɴ ᴅᴜʟᴜ!</b>", parse_mode=ParseMode.HTML)
        await message.edit("<emoji id=5789858554890425372>🔄</emoji> <b>ᴍᴇᴍʙᴜᴀᴛ ᴅʀᴏᴘʟᴇᴛ...</b>", parse_mode=ParseMode.HTML)
        data = {"name": args[1], "region": args[2], "size": args[3], "image": args[4]}
        res = await do_req(token, "POST", "droplets", data)
        if "droplet" in res:
            d = res["droplet"]
            await message.edit(
                f"<emoji id=5206607081334906820>✅</emoji> <b>ᴅʀᴏᴘʟᴇᴛ ᴅɪʙᴜᴀᴛ!</b>\n\n"
                f"<b>⎆ ɴᴀᴍᴀ:</b> <code>{d['name']}</code>\n"
                f"<b>⎆ ɪᴅ:</b> <code>{d['id']}</code>\n"
                f"<b>⎆ ꜱᴛᴀᴛᴜꜱ:</b> <code>{d['status']}</code>",
                parse_mode=ParseMode.HTML)
        else:
            msg = res.get("message", "Unknown error")
            await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ɢᴀɢᴀʟ:</b> <code>{msg}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("doinfo")
@PY.TOP_CMD
async def do_info(client, message):
    try:
        args = message.text.split(None, 1)
        if len(args) < 2:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.doinfo [droplet_id]</code>", parse_mode=ParseMode.HTML)
        token = await get_token(client)
        if not token:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ꜱᴇᴛ ᴛᴏᴋᴇɴ ᴅᴜʟᴜ!</b>", parse_mode=ParseMode.HTML)
        await message.edit("<emoji id=5789858554890425372>🔄</emoji> <b>ᴍᴇᴍᴜᴀᴛ...</b>", parse_mode=ParseMode.HTML)
        res = await do_req(token, "GET", f"droplets/{args[1]}")
        if "droplet" not in res:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ᴅʀᴏᴘʟᴇᴛ ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ!</b>", parse_mode=ParseMode.HTML)
        d = res["droplet"]
        ip = d["networks"]["v4"][0]["ip_address"] if d["networks"]["v4"] else "N/A"
        await message.edit(
            f"<emoji id=5206607081334906820>✅</emoji> <b>ɪɴꜰᴏ ᴅʀᴏᴘʟᴇᴛ</b>\n\n"
            f"<b>⎆ ɴᴀᴍᴀ:</b> <code>{d['name']}</code>\n"
            f"<b>⎆ ɪᴅ:</b> <code>{d['id']}</code>\n"
            f"<b>⎆ ɪᴘ:</b> <code>{ip}</code>\n"
            f"<b>⎆ ꜱᴛᴀᴛᴜꜱ:</b> <code>{d['status']}</code>\n"
            f"<b>⎆ ʀᴇɢɪᴏɴ:</b> <code>{d['region']['slug']}</code>\n"
            f"<b>⎆ ɪᴍᴀɢᴇ:</b> <code>{d['image']['slug']}</code>\n"
            f"<b>⎆ ꜱɪᴢᴇ:</b> <code>{d['size_slug']}</code>\n"
            f"<b>⎆ ᴠᴄᴘᴜ:</b> <code>{d['vcpus']}</code>\n"
            f"<b>⎆ ʀᴀᴍ:</b> <code>{d['memory']}MB</code>\n"
            f"<b>⎆ ᴅɪꜱᴋ:</b> <code>{d['disk']}GB</code>",
            parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("doreboot")
@PY.TOP_CMD
async def do_reboot(client, message):
    try:
        args = message.text.split(None, 1)
        if len(args) < 2:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.doreboot [id]</code>", parse_mode=ParseMode.HTML)
        token = await get_token(client)
        if not token:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ꜱᴇᴛ ᴛᴏᴋᴇɴ ᴅᴜʟᴜ!</b>", parse_mode=ParseMode.HTML)
        res = await do_req(token, "POST", f"droplets/{args[1]}/actions", {"type": "reboot"})
        if "action" in res:
            await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ᴅʀᴏᴘʟᴇᴛ {args[1]} ᴅɪʀᴇꜱᴛᴀʀᴛ!</b>", parse_mode=ParseMode.HTML)
        else:
            await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ɢᴀɢᴀʟ!</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("dooff")
@PY.TOP_CMD
async def do_off(client, message):
    try:
        args = message.text.split(None, 1)
        if len(args) < 2:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.dooff [id]</code>", parse_mode=ParseMode.HTML)
        token = await get_token(client)
        res = await do_req(token, "POST", f"droplets/{args[1]}/actions", {"type": "power_off"})
        if "action" in res:
            await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ᴅʀᴏᴘʟᴇᴛ {args[1]} ᴅɪᴍᴀᴛɪᴋᴀɴ!</b>", parse_mode=ParseMode.HTML)
        else:
            await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ɢᴀɢᴀʟ!</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("doon")
@PY.TOP_CMD
async def do_on(client, message):
    try:
        args = message.text.split(None, 1)
        if len(args) < 2:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.doon [id]</code>", parse_mode=ParseMode.HTML)
        token = await get_token(client)
        res = await do_req(token, "POST", f"droplets/{args[1]}/actions", {"type": "power_on"})
        if "action" in res:
            await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ᴅʀᴏᴘʟᴇᴛ {args[1]} ᴅɪɴʏᴀʟᴀᴋᴀɴ!</b>", parse_mode=ParseMode.HTML)
        else:
            await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ɢᴀɢᴀʟ!</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("dodel")
@PY.TOP_CMD
async def do_del(client, message):
    try:
        args = message.text.split(None, 1)
        if len(args) < 2:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.dodel [id]</code>", parse_mode=ParseMode.HTML)
        token = await get_token(client)
        res = await do_req(token, "DELETE", f"droplets/{args[1]}")
        if res.get("status") == 204:
            await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ᴅʀᴏᴘʟᴇᴛ {args[1]} ᴅɪʜᴀᴘᴜꜱ!</b>", parse_mode=ParseMode.HTML)
        else:
            await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ɢᴀɢᴀʟ ᴍᴇɴɢʜᴀᴘᴜꜱ!</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("doregion")
@PY.TOP_CMD
async def do_region(client, message):
    try:
        token = await get_token(client)
        if not token:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ꜱᴇᴛ ᴛᴏᴋᴇɴ ᴅᴜʟᴜ!</b>", parse_mode=ParseMode.HTML)
        await message.edit("<emoji id=5789858554890425372>🔄</emoji> <b>ᴍᴇᴍᴜᴀᴛ...</b>", parse_mode=ParseMode.HTML)
        res = await do_req(token, "GET", "regions")
        text = "<emoji id=5206607081334906820>✅</emoji> <b>ᴅᴀꜰᴛᴀʀ ʀᴇɢɪᴏɴ:</b>\n\n"
        for r in res.get("regions", []):
            if r["available"]:
                text += f"  • <code>{r['slug']}</code> - {r['name']}\n"
        await message.edit(text[:4096], parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("dosize")
@PY.TOP_CMD
async def do_size(client, message):
    try:
        token = await get_token(client)
        if not token:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ꜱᴇᴛ ᴛᴏᴋᴇɴ ᴅᴜʟᴜ!</b>", parse_mode=ParseMode.HTML)
        await message.edit("<emoji id=5789858554890425372>🔄</emoji> <b>ᴍᴇᴍᴜᴀᴛ...</b>", parse_mode=ParseMode.HTML)
        res = await do_req(token, "GET", "sizes")
        text = "<emoji id=5206607081334906820>✅</emoji> <b>ᴅᴀꜰᴛᴀʀ ꜱɪᴢᴇ:</b>\n\n"
        for s in res.get("sizes", [])[:15]:
            text += f"  • <code>{s['slug']}</code> - {s['vcpus']}vCPU/{s['memory']}MB/${s['price_monthly']}/mo\n"
        await message.edit(text[:4096], parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("doimage")
@PY.TOP_CMD
async def do_image(client, message):
    try:
        token = await get_token(client)
        if not token:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ꜱᴇᴛ ᴛᴏᴋᴇɴ ᴅᴜʟᴜ!</b>", parse_mode=ParseMode.HTML)
        await message.edit("<emoji id=5789858554890425372>🔄</emoji> <b>ᴍᴇᴍᴜᴀᴛ...</b>", parse_mode=ParseMode.HTML)
        res = await do_req(token, "GET", "images?type=distribution&per_page=20")
        text = "<emoji id=5206607081334906820>✅</emoji> <b>ᴅᴀꜰᴛᴀʀ ᴏꜱ ɪᴍᴀɢᴇ:</b>\n\n"
        for img in res.get("images", []):
            text += f"  • <code>{img['slug']}</code> - {img['distribution']} {img['name']}\n"
        await message.edit(text[:4096], parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
