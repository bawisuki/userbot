from PyroUbot import *

__MODULE__ = "ʙɪɴ ᴛᴏ ᴅᴇᴄ"
__HELP__ = """<blockquote><b>⎆ <code>{0}bin2dec</code></b></blockquote>"""


@PY.UBOT("bin2dec")
@PY.TOP_CMD
async def bin2dec(client, message):
    """ʙɪɴ ᴛᴏ ᴅᴇᴄ"""
    try:
        val = message.text.split(None, 1)[1]
        result = int(val, 2)
        await message.edit(f"<b>🔢 Binary {val} = Decimal {result}</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.bin2dec 11111111</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
