from PyroUbot import *
import random

__MODULE__ = "👥 Team Nam"
__HELP__ = """<blockquote><b>⎆ <code>{0}genteam</code></b></blockquote>"""


@PY.UBOT("genteam")
@PY.TOP_CMD
async def genteam(client, message):
    """👥 Team Nam"""
    try:
        result = f"{random.choice(['Alpha','Beta','Gamma','Delta','Omega','Phoenix','Thunder','Storm','Shadow','Cyber'])} {random.choice(['Squad','Team','Force','Unit','Crew','Pack','Gang','Clan'])}"
        await message.edit(f"<b>👥 Team Name</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
