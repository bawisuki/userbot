from PyroUbot import *
import random

__MODULE__ = "🌟"
__HELP__ = """<blockquote><b>⎆ <code>{0}element</code></b></blockquote>"""


@PY.UBOT("element")
@PY.TOP_CMD
async def element(client, message):
    """🌟"""
    try:
        result = random.choice(['🔥 Fire','💧 Water','🌍 Earth','💨 Air','⚡ Lightning','❄️ Ice','🌿 Nature','🌑 Dark','✨ Light'])
        await message.edit(f"<b>🌟 Your Element</b>\n\n<b>Result:</b> {result}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
