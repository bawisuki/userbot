from PyroUbot import *

__MODULE__ = "ᴄᴀꜱᴇ ᴄᴏɴᴠ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴄᴀꜱᴇ

⎆ <code>{0}upper</code> [text] ᴜᴘᴘᴇʀᴄᴀꜱᴇ
⎆ <code>{0}lower</code> [text] ʟᴏᴡᴇʀᴄᴀꜱᴇ
⎆ <code>{0}title</code> [text] ᴛɪᴛʟᴇ ᴄᴀꜱᴇ
⎆ <code>{0}reverse</code> [text] ʀᴇᴠᴇʀꜱᴇ</b></blockquote>
"""


@PY.UBOT("upper")
@PY.TOP_CMD
async def upper_cmd(client, message):
    args = message.text.split(None, 1)
    if len(args) < 2:
        return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.upper [text]</code>", parse_mode=ParseMode.HTML)
    try:
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <code>{args[1].upper()}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("lower")
@PY.TOP_CMD
async def lower_cmd(client, message):
    args = message.text.split(None, 1)
    if len(args) < 2:
        return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.lower [text]</code>", parse_mode=ParseMode.HTML)
    try:
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <code>{args[1].lower()}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("title")
@PY.TOP_CMD
async def title_cmd(client, message):
    args = message.text.split(None, 1)
    if len(args) < 2:
        return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.title [text]</code>", parse_mode=ParseMode.HTML)
    try:
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <code>{args[1].title()}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("reverse")
@PY.TOP_CMD
async def reverse_cmd(client, message):
    args = message.text.split(None, 1)
    if len(args) < 2:
        return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.reverse [text]</code>", parse_mode=ParseMode.HTML)
    try:
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <code>{args[1][::-1]}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
