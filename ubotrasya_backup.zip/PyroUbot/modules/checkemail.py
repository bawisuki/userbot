from PyroUbot import *
import re

__MODULE__ = "ᴇᴍᴀɪʟ ᴄʜᴇᴄᴋ"
__HELP__ = """<blockquote><b>⎆ <code>{0}emailcheck</code></b></blockquote>"""


@PY.UBOT("emailcheck")
@PY.TOP_CMD
async def checkemail(client, message):
    """ᴇᴍᴀɪʟ ᴄʜᴇᴄᴋ"""
    try:
        email = message.text.split(None, 1)[1]
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        valid = bool(re.match(pattern, email))
        parts = email.split("@")
        txt = f"<b>📧 Email Validator</b>\n\n<b>Email:</b> <code>{email}</code>\n<b>Valid:</b> {'✅ Yes' if valid else '❌ No'}\n<b>User:</b> {parts[0]}\n<b>Domain:</b> {parts[1] if len(parts) > 1 else 'N/A'}"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.emailcheck email@domain.com</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
