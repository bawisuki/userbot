from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄᴏᴜɴᴛʀʏ"
__HELP__ = """<blockquote><b>⎆ <code>{0}country</code></b></blockquote>"""


@PY.UBOT("country")
@PY.TOP_CMD
async def country(client, message):
    """ᴄᴏᴜɴᴛʀʏ"""
    try:
        name = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://restcountries.com/v3.1/name/{name}") as r:
                d = await r.json()
        c = d[0]
        txt = (
            f"<b>🌍 {c['name']['common']}</b>\n\n"
            f"<b>🏛 Capital:</b> {', '.join(c.get('capital', ['N/A']))}\n"
            f"<b>👥 Population:</b> {c['population']:,}\n"
            f"<b>🌐 Region:</b> {c['region']}\n"
            f"<b>📞 Calling Code:</b> {c.get('idd', {}).get('root', '')}{(c.get('idd', {}).get('suffixes', ['']))[0]}\n"
            f"<b>💰 Currency:</b> {list(c.get('currencies', {}).values())[0]['name'] if c.get('currencies') else 'N/A'}\n"
            f"<b>🗣 Language:</b> {', '.join(c.get('languages', {}).values())}"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.country name</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
