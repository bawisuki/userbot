from PyroUbot import *
import aiohttp

__MODULE__ = "ʜᴇx"
__HELP__ = """<blockquote><b>⎆ <code>{0}hex2text</code></b></blockquote>"""


@PY.UBOT("hex2text")
@PY.TOP_CMD
async def hex2text(client, message):
    """ʜᴇx"""
    try:
        text = message.text.split(None, 1)[1]
        result = text.encode().hex()
        await message.edit(f"<b>🔢 Text to Hex</b>\n\n<code>{result[:3000]}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.hex2text text</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
