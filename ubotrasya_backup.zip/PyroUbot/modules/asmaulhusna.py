from PyroUbot import *
import aiohttp
import random

__MODULE__ = "ᴀꜱᴍᴀᴜʟ"
__HELP__ = """<blockquote><b>⎆ <code>{0}asmaul</code></b></blockquote>"""


@PY.UBOT("asmaul")
@PY.TOP_CMD
async def asmaulhusna(client, message):
    """ᴀꜱᴍᴀᴜʟ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api.aladhan.com/v1/asmaAlHusna") as r:
                d = await r.json()
        names = d["data"]
        pick = random.choice(names)
        await message.edit(f"<b>☪️ Asmaul Husna</b>\n\n<b>{pick['name']}</b>\n<b>Latin:</b> {pick['transliteration']}\n<b>Arti:</b> {pick['en']['meaning']}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
