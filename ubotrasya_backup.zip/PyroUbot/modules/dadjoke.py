from PyroUbot import *
import aiohttp

__MODULE__ = "ᴅᴀᴅ ᴊᴏᴋᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}dadjoke</code></b></blockquote>"""


@PY.UBOT("dadjoke")
@PY.TOP_CMD
async def dadjoke(client, message):
    """ᴅᴀᴅ ᴊᴏᴋᴇ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://icanhazdadjoke.com/", headers={"Accept": "application/json"}) as r:
                d = await r.json()
        await message.edit(f"<b>👨 Dad Joke</b>\n\n{d['joke']}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
