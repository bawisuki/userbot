from PyroUbot import *
import aiohttp

__MODULE__ = "ʙᴏʀᴇᴅ 2"
__HELP__ = """<blockquote><b>⎆ <code>{0}bored2</code></b></blockquote>"""


@PY.UBOT("bored2")
@PY.TOP_CMD
async def bored2(client, message):
    """ʙᴏʀᴇᴅ 2"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://bored-api.appbrewery.com/random?type=education") as r:
                d = await r.json()
        await message.edit(f"<b>📚 Learn Something</b>\n\n{d['activity']}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
