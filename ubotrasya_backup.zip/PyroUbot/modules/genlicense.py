from PyroUbot import *
import random

__MODULE__ = "🚗 License"
__HELP__ = """<blockquote><b>⎆ <code>{0}genlicense</code></b></blockquote>"""


@PY.UBOT("genlicense")
@PY.TOP_CMD
async def genlicense(client, message):
    """🚗 License """
    try:
        result = f"{random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ')}{random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ')} {random.randint(1000,9999)} {random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ')}{random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ')}"
        await message.edit(f"<b>🚗 License Plate</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
