from PyroUbot import *
import time
from datetime import datetime

__MODULE__ = "ᴇᴘᴏᴄʜ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴇᴘᴏᴄʜ

⎆ <code>{0}epoch</code> ᴛᴀᴍᴘɪʟᴋᴀɴ ᴇᴘᴏᴄʜ ꜱᴇᴋᴀʀᴀɴɢ
⎆ <code>{0}epoch2date</code> [timestamp] ᴋᴏɴᴠᴇʀꜱɪ ᴇᴘᴏᴄʜ ᴋᴇ ᴛᴀɴɢɢᴀʟ</b></blockquote>
"""


@PY.UBOT("epoch")
@PY.TOP_CMD
async def epoch_cmd(client, message):
    try:
        now = int(time.time())
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ᴇᴘᴏᴄʜ ꜱᴇᴋᴀʀᴀɴɢ:</b>\n<code>{now}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("epoch2date")
@PY.TOP_CMD
async def epoch2date_cmd(client, message):
    args = message.text.split(None, 1)
    if len(args) < 2:
        return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.epoch2date [timestamp]</code>", parse_mode=ParseMode.HTML)
    try:
        ts = int(args[1])
        dt = datetime.utcfromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S UTC")
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ᴇᴘᴏᴄʜ:</b> <code>{ts}</code>\n<b>⎆ ᴅᴀᴛᴇ:</b> <code>{dt}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
