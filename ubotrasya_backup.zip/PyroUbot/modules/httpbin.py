from PyroUbot import *
import aiohttp

__MODULE__ = "ʜᴛᴛᴘʙɪɴ"
__HELP__ = """<blockquote><b>⎆ <code>{0}httpbin</code></b></blockquote>"""


@PY.UBOT("httpbin")
@PY.TOP_CMD
async def httpbin(client, message):
    """ʜᴛᴛᴘʙɪɴ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://httpbin.org/get") as r:
                d = await r.json()
        txt = (
            f"<b>🌐 HTTPBin Response</b>\n\n"
            f"<b>IP:</b> <code>{d['origin']}</code>\n"
            f"<b>URL:</b> <code>{d['url']}</code>\n"
            f"<b>Headers:</b>\n"
        )
        for k, v in list(d['headers'].items())[:5]:
            txt += f"  • <b>{k}:</b> <code>{v[:50]}</code>\n"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
