from PyroUbot import *

__MODULE__ = "🔤 Double Letters"
__HELP__ = """<blockquote><b>⎆ <code>{0}double</code></b></blockquote>"""


@PY.UBOT("double")
@PY.TOP_CMD
async def double(client, message):
    """🔤 Double Letters"""
    try:
        text = message.text.split(None, 1)[1]
        result = "".join(c*2 for c in text)
        await message.edit(f"<code>{result[:3000]}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Provide text.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
