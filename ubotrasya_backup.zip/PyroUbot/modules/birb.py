from PyroUbot import *
import aiohttp

__MODULE__ = "ʙɪʀᴅ"
__HELP__ = """<blockquote><b>⎆ <code>{0}birb</code></b></blockquote>"""


@PY.UBOT("birb")
@PY.TOP_CMD
async def birb(client, message):
    """ʙɪʀᴅ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("http://shibe.online/api/birds?count=1") as r:
                d = await r.json()
        await message.edit(f"<b>🐦 Random Bird</b>\n\n<a href='{d[0]}'>🖼 View Image</a>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
