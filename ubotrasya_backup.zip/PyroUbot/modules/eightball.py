from PyroUbot import *
import aiohttp

__MODULE__ = "8ʙᴀʟʟ"
__HELP__ = """<blockquote><b>⎆ <code>{0}8ball</code></b></blockquote>"""


@PY.UBOT("8ball")
@PY.TOP_CMD
async def eightball(client, message):
    """8ʙᴀʟʟ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://eightballapi.com/api") as r:
                d = await r.json()
        await message.edit(f"<b>🎱 Magic 8-Ball</b>\n\n<i>{d['reading']}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
