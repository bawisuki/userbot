from PyroUbot import *
import aiohttp

__MODULE__ = "📋 Busywo"
__HELP__ = """<blockquote><b>⎆ <code>{0}boredbusywork</code></b></blockquote>"""


@PY.UBOT("boredbusywork")
@PY.TOP_CMD
async def boredbusywork(client, message):
    """📋 Busywo"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://bored-api.appbrewery.com/random?type=busywork") as r:
                d = await r.json(content_type=None)
        result = d["activity"]
        await message.edit(f"<b>📋 Busywork</b>\n\n{result}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
