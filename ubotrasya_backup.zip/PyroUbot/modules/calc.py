from PyroUbot import *
import ast
import operator

__MODULE__ = "ᴋᴀʟᴋᴜʟᴀᴛᴏʀ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴋᴀʟᴋᴜʟᴀᴛᴏʀ

⎆ <code>{0}calc</code> [expr]
   ʜɪᴛᴜɴɢ ᴇᴋꜱᴘʀᴇꜱɪ ᴍᴀᴛᴇᴍᴀᴛɪᴋᴀ</b></blockquote>
"""

_OPS = {
    ast.Add: operator.add, ast.Sub: operator.sub,
    ast.Mult: operator.mul, ast.Div: operator.truediv,
    ast.Pow: operator.pow, ast.Mod: operator.mod,
    ast.FloorDiv: operator.floordiv, ast.USub: operator.neg,
}


def _safe_eval(node):
    if isinstance(node, ast.Num):
        return node.n
    elif isinstance(node, ast.BinOp):
        return _OPS[type(node.op)](_safe_eval(node.left), _safe_eval(node.right))
    elif isinstance(node, ast.UnaryOp):
        return _OPS[type(node.op)](_safe_eval(node.operand))
    raise ValueError("Ekspresi tidak valid")


@PY.UBOT("calc")
@PY.TOP_CMD
async def calc_cmd(client, message):
    args = message.text.split(None, 1)
    if len(args) < 2:
        return await message.edit("<b><emoji id=5210952531676504517>❌</emoji> ɢᴜɴᴀᴋᴀɴ: <code>.calc [expr]</code></b>")
    expr = args[1].strip()
    try:
        tree = ast.parse(expr, mode="eval")
        result = _safe_eval(tree.body)
        await message.edit(f"<b><emoji id=5206607081334906820>✅</emoji> ᴋᴀʟᴋᴜʟᴀᴛᴏʀ:</b>\n<code>{expr} = {result}</code>")
    except Exception as e:
        await message.edit(f"<b><emoji id=5210952531676504517>❌</emoji> ᴇʀʀᴏʀ:</b> <code>{e}</code>")
