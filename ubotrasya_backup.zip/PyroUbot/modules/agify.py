from PyroUbot import *
import aiohttp

__MODULE__ = "ᴀɢɪꜰʏ"
__HELP__ = """<blockquote><b>⎆ <code>{0}agify</code></b></blockquote>"""


@PY.UBOT("agify")
@PY.TOP_CMD
async def agify(client, message):
    """ᴀɢɪꜰʏ"""
    try:
        name = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.agify.io?name={name}") as r:
                d = await r.json()
        await message.edit(f"<b>🎂 Age Prediction</b>\n\n<b>Name:</b> {d['name']}\n<b>Predicted Age:</b> {d['age']}", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.agify name</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
