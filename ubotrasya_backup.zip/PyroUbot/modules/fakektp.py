from PyroUbot import *
import aiohttp
import os
import random

__MODULE__ = "ᴍᴀᴋᴇʀ & ꜰᴀᴋᴇ"
__HELP__ = """
<blockquote><b>⎆ <code>{0}fakektp</code> [reply foto] ɢᴇɴ ᴋᴛᴘ
⎆ <code>{0}fakedana</code> [nominal] ꜰᴀᴋᴇ ᴅᴀɴᴀ
⎆ <code>{0}wastatus</code> [nama|waktu|teks] ᴡᴀ ꜱᴛᴀᴛᴜꜱ
⎆ <code>{0}iqc</code> [text] ɪǫᴄ ᴍᴀᴋᴇʀ
⎆ <code>{0}carbon2</code> [code] ᴄᴀʀʙᴏɴ
⎆ <code>{0}qrgen2</code> [text] ǫʀ ᴄᴏᴅᴇ</b></blockquote>
"""



@PY.UBOT("fakektp")
@PY.TOP_CMD
async def fakektp(client, message):
    """ꜰᴀᴋᴇ ᴋᴛᴘ"""
    try:
        reply = message.reply_to_message
        if not reply or not (reply.photo or reply.document):
            return await message.edit(
                "<b>⚠️ Reply ke foto (pas foto) dengan format:</b>\n"
                "<code>.fakektp nama|ttl|alamat</code>\n\n"
                "<b>Contoh:</b>\n"
                "<code>.fakektp BUDI SANTOSO|Bandung, 25-01-1990|Jl. Merdeka No. 10</code>\n\n"
                "<i>Atau reply foto tanpa argumen untuk data random.</i>",
                parse_mode=ParseMode.HTML
            )

        await message.edit("<b>⏳ Generating e-KTP...</b>", parse_mode=ParseMode.HTML)

        # Parse arguments or use random data
        args_text = message.text.split(None, 1)[1] if len(message.text.split()) > 1 else ""
        parts = args_text.split("|") if args_text else []

        provinsi_list = ["JAWA BARAT", "JAWA TENGAH", "JAWA TIMUR", "DKI JAKARTA", "BANTEN", "SUMATERA UTARA", "SULAWESI SELATAN", "BALI", "YOGYAKARTA"]
        kota_list = ["BANDUNG", "SEMARANG", "SURABAYA", "JAKARTA SELATAN", "TANGERANG", "MEDAN", "MAKASSAR", "DENPASAR", "YOGYAKARTA"]
        nama_list = ["BUDI SANTOSO", "AGUS SETIAWAN", "DEWI LESTARI", "SITI RAHAYU", "AHMAD FAUZI", "RINA WATI", "DIAN PERMATA", "HENDRA GUNAWAN"]
        pekerjaan_list = ["Wiraswasta", "Karyawan Swasta", "PNS", "Pelajar/Mahasiswa", "Pedagang", "Buruh", "Petani"]
        agama_list = ["Islam", "Kristen", "Katolik", "Hindu", "Buddha"]

        nama = parts[0].strip().upper() if len(parts) > 0 else random.choice(nama_list)
        ttl = parts[1].strip() if len(parts) > 1 else f"{random.choice(['Bandung','Jakarta','Surabaya','Semarang','Medan'])}, {random.randint(1,28):02d}-{random.randint(1,12):02d}-{random.randint(1970,2000)}"
        alamat = parts[2].strip() if len(parts) > 2 else f"Jl. {random.choice(['Merdeka','Sudirman','Gatot Subroto','Ahmad Yani','Diponegoro'])} No. {random.randint(1,100)}"

        idx = random.randint(0, len(provinsi_list)-1)
        nik = f"{random.randint(1000,9999)}{random.randint(10,99)}{random.randint(100000,999999)}{random.randint(1000,9999)}"

        data = {
            "provinsi": provinsi_list[idx],
            "kota": kota_list[idx],
            "nik": nik,
            "nama": nama,
            "ttl": ttl,
            "jenis_kelamin": random.choice(["Laki-laki", "Perempuan"]),
            "golongan_darah": random.choice(["A", "B", "AB", "O"]),
            "alamat": alamat,
            "rt_rw": f"{random.randint(1,20):03d}/{random.randint(1,15):03d}",
            "kel_desa": random.choice(["Braga", "Menteng", "Kebayoran", "Tegalsari", "Gondokusuman"]),
            "kecamatan": random.choice(["Sumur Bandung", "Menteng", "Kebayoran Baru", "Tegalsari", "Gondokusuman"]),
            "agama": random.choice(agama_list),
            "status": random.choice(["Kawin", "Belum Kawin"]),
            "pekerjaan": random.choice(pekerjaan_list),
            "kewarganegaraan": "WNI",
            "masa_berlaku": "Seumur Hidup",
            "terbuat": f"{random.randint(1,28):02d}-{random.randint(1,12):02d}-2023",
        }

        # Download photo
        photo_path = await reply.download()

        async with aiohttp.ClientSession() as s:
            form = aiohttp.FormData()
            for key, val in data.items():
                form.add_field(key, val)
            form.add_field("file", open(photo_path, "rb"), filename="foto.jpg", content_type="image/jpeg")

            async with s.post("https://api-nanzz.my.id/docs/api/maker/e-ktp.php", data=form) as r:
                if r.status == 200:
                    content_type = r.headers.get("Content-Type", "")
                    if "image" in content_type:
                        img_data = await r.read()
                        ktp_path = "/tmp/fakektp.png"
                        with open(ktp_path, "wb") as f:
                            f.write(img_data)
                        await message.reply_photo(ktp_path, caption=f"<b>🪪 e-KTP Generator</b>\n\n<b>Nama:</b> {nama}\n<b>NIK:</b> {nik}", parse_mode=ParseMode.HTML)
                        await message.delete()
                        os.remove(ktp_path)
                    else:
                        d = await r.json()
                        if d.get("status"):
                            url = d.get("result", d.get("url", d.get("data", "")))
                            if url:
                                async with s.get(url) as img_r:
                                    img_data = await img_r.read()
                                ktp_path = "/tmp/fakektp.png"
                                with open(ktp_path, "wb") as f:
                                    f.write(img_data)
                                await message.reply_photo(ktp_path, caption=f"<b>🪪 e-KTP Generator</b>\n\n<b>Nama:</b> {nama}\n<b>NIK:</b> {nik}", parse_mode=ParseMode.HTML)
                                await message.delete()
                                os.remove(ktp_path)
                            else:
                                await message.edit(f"<b>❌ No URL in response</b>", parse_mode=ParseMode.HTML)
                        else:
                            await message.edit(f"<b>❌ Gagal:</b> <code>{d.get('message', 'Unknown error')}</code>", parse_mode=ParseMode.HTML)
                else:
                    await message.edit(f"<b>❌ API Error:</b> Status {r.status}", parse_mode=ParseMode.HTML)

        os.remove(photo_path)
    except IndexError:
        await message.edit("<b>⚠️ Reply ke foto untuk generate e-KTP.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
