from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄᴏᴍᴍɪᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}commit</code></b></blockquote>"""


@PY.UBOT("commit")
@PY.TOP_CMD
async def commit(client, message):
    """ᴄᴏᴍᴍɪᴛ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://whatthecommit.com/index.txt") as r:
                txt = await r.text()
        await message.edit(f"<b>💻 Random Commit Message</b>\n\n<code>{txt.strip()}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
