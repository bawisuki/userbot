from PyroUbot import *

__MODULE__ = "🔤 Get Initials"
__HELP__ = """<blockquote><b>⎆ <code>{0}initials</code></b></blockquote>"""


@PY.UBOT("initials")
@PY.TOP_CMD
async def initials(client, message):
    """🔤 Get Initials"""
    try:
        text = message.text.split(None, 1)[1]
        result = "".join(w[0].upper() for w in text.split() if w)
        await message.edit(f"<b>🔤 Initials:</b> <code>{result}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Provide text.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
