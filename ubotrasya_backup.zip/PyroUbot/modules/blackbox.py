from PyroUbot import *
import aiohttp
from urllib.parse import quote

__MODULE__ = "ʙʟᴀᴄᴋʙᴏx"
__HELP__ = """<blockquote><b>⎆ <code>{0}blackbox</code></b></blockquote>"""


@PY.UBOT("blackbox")
@PY.TOP_CMD
async def blackbox(client, message):
    """ʙʟᴀᴄᴋʙᴏx"""
    try:
        args = message.text.split(None, 1)
        text = args[1] if len(args) > 1 else (message.reply_to_message.text if message.reply_to_message else None)
        if not text:
            return await message.edit("<b>⚠️ Usage:</b> <code>.blackbox [text/reply]</code>", parse_mode=ParseMode.HTML)
        await message.edit("<b>⏳ Blackbox AI...</b>", parse_mode=ParseMode.HTML)
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api-nanzz.my.id/docs/api/ai/blackbox.php?q={quote(text)}") as r:
                d = await r.json()
        if d.get("status"):
            res = d["result"]
            answer = res.get("response", str(res)) if isinstance(res, dict) else str(res)
            answer = answer.replace("<think>", "").split("</think>")[-1].strip()
            await message.edit(f"<b>⬛ Blackbox AI</b>\n\n{answer[:4000]}", parse_mode=ParseMode.HTML)
        else:
            await message.edit("<b>❌ Gagal.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
