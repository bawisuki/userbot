from PyroUbot import *

__MODULE__ = "🎂 Age"
__HELP__ = """<blockquote><b>⎆ <code>{0}agecalc</code></b></blockquote>"""


@PY.UBOT("agecalc")
@PY.TOP_CMD
async def agecalc2(client, message):
    """🎂 Age"""
    try:
        args = message.text.split()
        from datetime import datetime
        year = int(args[1])
        month = int(args[2]) if len(args) > 2 else 1
        day = int(args[3]) if len(args) > 3 else 1
        born = datetime(year, month, day)
        now = datetime.now()
        age = now.year - born.year - ((now.month, now.day) < (born.month, born.day))
        days = (now - born).days
        await message.edit(f"<b>🎂 Age Calculator</b>\n\n<b>Born:</b> {born.strftime('%Y-%m-%d')}\n<b>Age:</b> {age} years\n<b>Days:</b> {days:,}", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Usage:</b> <code>.agecalc year</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
