from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ acre2sqm"
__HELP__ = """<blockquote><b>⎆ <code>{0}acre2sqm</code></b></blockquote>"""


@PY.UBOT("acre2sqm")
@PY.TOP_CMD
async def acre2sqm(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val * 4046.86
        await message.edit(f"<b>📐 {val} acres = {result:.4f} sq meters</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.acre2sqm value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
