from PyroUbot import *

__MODULE__ = "📝 Base64"
__HELP__ = """<blockquote><b>⎆ <code>{0}genbase64</code></b></blockquote>"""


@PY.UBOT("genbase64")
@PY.TOP_CMD
async def genbase64(client, message):
    """📝 Base64"""
    try:
        import random, string, uuid, hashlib, os, secrets, base64
        r = __import__('base64').b64encode(__import__('os').urandom(24)).decode()
        await message.edit(f"<b>📝 Base64 Key</b>\n\n<code>{str(r)}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
