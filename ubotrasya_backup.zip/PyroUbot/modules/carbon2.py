from PyroUbot import *
import aiohttp
import os

__MODULE__ = "ᴄᴀʀʙᴏɴ carbon2"
__HELP__ = """<blockquote><b>⎆ <code>{0}carbon2</code></b></blockquote>"""


@PY.UBOT("carbon2")
@PY.TOP_CMD
async def carbon2(client, message):
    """ᴄᴀʀʙᴏɴ"""
    try:
        text = message.text.split(None, 1)[1] if len(message.text.split()) > 1 else (message.reply_to_message.text if message.reply_to_message else None)
        if not text:
            return await message.edit("<b>⚠️ Reply to code or provide text.</b>", parse_mode=ParseMode.HTML)
        await message.edit("<b>⏳ Generating carbon...</b>", parse_mode=ParseMode.HTML)
        async with aiohttp.ClientSession() as s:
            async with s.post("https://carbonara.solopov.dev/api/cook", json={"code": text[:1500], "theme": "dracula"}) as r:
                if r.status == 200:
                    img = await r.read()
                    path = "/tmp/carbon2.png"
                    with open(path, "wb") as f:
                        f.write(img)
                    await message.reply_photo(path)
                    await message.delete()
                    os.remove(path)
                else:
                    await message.edit("<b>❌ Failed.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
