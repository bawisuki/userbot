from PyroUbot import *

__MODULE__ = "📊 Char Frequency"
__HELP__ = """<blockquote><b>⎆ <code>{0}charfreq</code></b></blockquote>"""


@PY.UBOT("charfreq")
@PY.TOP_CMD
async def charfreq(client, message):
    """📊 Char Frequency"""
    try:
        text = message.text.split(None, 1)[1]
        from collections import Counter
        freq = Counter(text.lower())
        top = freq.most_common(10)
        result = "\n".join([f"  '{c}': {n}" for c, n in top])
        await message.edit(f"<b>📊 Character Frequency</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Provide text.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
