from PyroUbot import *
import aiohttp

__MODULE__ = "ɢʜ ꜱᴛᴀʀꜱ"
__HELP__ = """<blockquote><b>⎆ <code>{0}ghstars</code></b></blockquote>"""


@PY.UBOT("ghstars")
@PY.TOP_CMD
async def github_stars(client, message):
    """ɢʜ ꜱᴛᴀʀꜱ"""
    try:
        user = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.github.com/users/{user}/starred?per_page=5") as r:
                d = await r.json()
        txt = f"<b>⭐ Starred by {user}</b>\n\n"
        for repo in d[:5]:
            txt += f"• <b>{repo['full_name']}</b> ({repo['stargazers_count']}★)\n"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.ghstars username</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
