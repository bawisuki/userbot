from PyroUbot import *

__MODULE__ = "ᴅᴇᴄ ᴛᴏ ʜᴇx"
__HELP__ = """<blockquote><b>⎆ <code>{0}dec2hex</code></b></blockquote>"""


@PY.UBOT("dec2hex")
@PY.TOP_CMD
async def dec2hex(client, message):
    """ᴅᴇᴄ ᴛᴏ ʜᴇx"""
    try:
        val = int(message.text.split(None, 1)[1])
        await message.edit(f"<b>🔢 Decimal {val} = Hex {hex(val)[2:].upper()}</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.dec2hex 255</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
