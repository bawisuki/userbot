from PyroUbot import *
import aiohttp
import os

__MODULE__ = "ꜰᴀᴄᴇʙᴏᴏᴋ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ꜰᴀᴄᴇʙᴏᴏᴋ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ

⎆ <code>{0}fb</code> [url]
   ᴅᴏᴡɴʟᴏᴀᴅ ᴠɪᴅᴇᴏ ꜰᴀᴄᴇʙᴏᴏᴋ</b></blockquote>
"""


@PY.UBOT("fb")
@PY.TOP_CMD
async def facebook_dl(client, message):
    url = message.text.split(None, 1)
    if len(url) < 2:
        return await message.edit("<b><emoji id=5210952531676504517>❌</emoji> ɢᴜɴᴀᴋᴀɴ: <code>.fb [url]</code></b>")
    url = url[1].strip()
    await message.edit("<b><emoji id=5789858554890425372>🔄</emoji> ꜱᴇᴅᴀɴɢ ᴍᴇɴᴅᴏᴡɴʟᴏᴀᴅ...</b>")
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"https://api.ryzumi.net/api/downloader/facebook?url={url}") as resp:
                res = await resp.json(content_type=None)
            data = res.get("data", {})
            video_url = data.get("hd") or data.get("sd")
            if not video_url:
                return await message.edit("<b><emoji id=5210952531676504517>❌</emoji> ɢᴀɢᴀʟ ᴍᴇɴᴅᴀᴘᴀᴛᴋᴀɴ ᴠɪᴅᴇᴏ</b>")
            async with session.get(video_url) as vid:
                with open("facebook_dl.mp4", "wb") as f:
                    f.write(await vid.read())
        await message.delete()
        await client.send_video(message.chat.id, "facebook_dl.mp4", caption="<b><emoji id=5206607081334906820>✅</emoji> ꜰᴀᴄᴇʙᴏᴏᴋ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ</b>")
    except Exception as e:
        await message.edit(f"<b><emoji id=5210952531676504517>❌</emoji> ᴇʀʀᴏʀ:</b> <code>{e}</code>")
    finally:
        if os.path.exists("facebook_dl.mp4"):
            os.remove("facebook_dl.mp4")
