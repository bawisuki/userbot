from PyroUbot import *
import random

__MODULE__ = "📁 Project"
__HELP__ = """<blockquote><b>⎆ <code>{0}genproject</code></b></blockquote>"""


@PY.UBOT("genproject")
@PY.TOP_CMD
async def genproject(client, message):
    """📁 Project """
    try:
        result = f"{random.choice(['Project','Operation','Mission','Initiative'])} {random.choice(['Phoenix','Thunder','Aurora','Eclipse','Nebula','Quantum','Horizon','Zenith'])}"
        await message.edit(f"<b>📁 Project Name</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
