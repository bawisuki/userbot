from PyroUbot import *

__MODULE__ = "ᴄʀᴏɴ ʜᴇʟᴘ"
__HELP__ = """<blockquote><b>⎆ <code>{0}cronhelp</code></b></blockquote>"""


@PY.UBOT("cronhelp")
@PY.TOP_CMD
async def crontranslate(client, message):
    """ᴄʀᴏɴ ʜᴇʟᴘ"""
    try:
        examples = [
            ("*/5 * * * *", "Every 5 minutes"),
            ("0 * * * *", "Every hour"),
            ("0 0 * * *", "Every day at midnight"),
            ("0 0 * * 0", "Every Sunday at midnight"),
            ("0 0 1 * *", "First day of every month"),
            ("30 2 * * 1-5", "Mon-Fri at 2:30 AM"),
            ("0 9,17 * * *", "At 9 AM and 5 PM"),
            ("*/15 9-17 * * 1-5", "Every 15min, 9-5, Mon-Fri"),
        ]
        txt = "<b>⏰ Cron Expression Examples</b>\n\n<code>min hour day month weekday</code>\n\n"
        for expr, desc in examples:
            txt += f"<code>{expr}</code> → {desc}\n"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
