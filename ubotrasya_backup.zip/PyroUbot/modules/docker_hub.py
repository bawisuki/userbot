from PyroUbot import *
import aiohttp

__MODULE__ = "ᴅᴏᴄᴋᴇʀ"
__HELP__ = """<blockquote><b>⎆ <code>{0}docker</code></b></blockquote>"""


@PY.UBOT("docker")
@PY.TOP_CMD
async def docker_hub(client, message):
    """ᴅᴏᴄᴋᴇʀ"""
    try:
        image = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://hub.docker.com/v2/repositories/library/{image}/") as r:
                d = await r.json()
        txt = (
            f"<b>🐳 {d['name']}</b>\n\n"
            f"<b>⭐ Stars:</b> {d.get('star_count', 0)}\n"
            f"<b>📥 Pulls:</b> {d.get('pull_count', 0):,}\n"
            f"<b>📝 Description:</b> {d.get('description', 'N/A')[:200]}"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.docker image_name</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
