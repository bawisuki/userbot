from PyroUbot import *
from datetime import datetime, timezone, timedelta

__MODULE__ = "ᴊᴀᴍ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴊᴀᴍ

⎆ <code>{0}jam</code> ᴡᴀᴋᴛᴜ WIB/WITA/WIT ꜱᴇᴋᴀʀᴀɴɢ
⎆ <code>{0}tanggal</code> ᴛᴀɴɢɢᴀʟ ʜᴀʀɪ ɪɴɪ</b></blockquote>
"""


@PY.UBOT("jam")
@PY.TOP_CMD
async def jam_cmd(client, message):
    wib = datetime.now(timezone(timedelta(hours=7))).strftime("%H:%M:%S")
    wita = datetime.now(timezone(timedelta(hours=8))).strftime("%H:%M:%S")
    wit = datetime.now(timezone(timedelta(hours=9))).strftime("%H:%M:%S")
    await message.edit(
        f"<b><emoji id=5206607081334906820>✅</emoji> ᴡᴀᴋᴛᴜ ɪɴᴅᴏɴᴇꜱɪᴀ:</b>\n\n"
        f"<b>🕐 WIB:</b> <code>{wib}</code>\n"
        f"<b>🕐 WITA:</b> <code>{wita}</code>\n"
        f"<b>🕐 WIT:</b> <code>{wit}</code>"
    )


@PY.UBOT("tanggal")
@PY.TOP_CMD
async def tanggal_cmd(client, message):
    now = datetime.now(timezone(timedelta(hours=7)))
    hari = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    h = hari[now.weekday()]
    b = bulan[now.month - 1]
    await message.edit(f"<b><emoji id=5206607081334906820>✅</emoji> ᴛᴀɴɢɢᴀʟ:</b>\n<code>{h}, {now.day} {b} {now.year}</code>")
