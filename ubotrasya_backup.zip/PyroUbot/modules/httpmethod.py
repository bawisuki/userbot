from PyroUbot import *
import aiohttp

__MODULE__ = "ᴍᴇᴛʜᴏᴅꜱ"
__HELP__ = """<blockquote><b>⎆ <code>{0}methods</code></b></blockquote>"""


@PY.UBOT("methods")
@PY.TOP_CMD
async def httpmethod(client, message):
    """ᴍᴇᴛʜᴏᴅꜱ"""
    try:
        url = message.text.split(None, 1)[1]
        if not url.startswith("http"):
            url = "https://" + url
        methods = ["GET","POST","PUT","DELETE","PATCH","HEAD","OPTIONS"]
        results = []
        async with aiohttp.ClientSession() as s:
            for m in methods:
                try:
                    async with s.request(m, url, timeout=aiohttp.ClientTimeout(total=5)) as r:
                        results.append(f"{'✅' if r.status < 400 else '❌'} {m}: {r.status}")
                except:
                    results.append(f"❌ {m}: Failed")
        txt = f"<b>🔧 HTTP Methods: {url}</b>\n\n" + "\n".join(results)
        await message.edit(txt, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.methods url</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
