from PyroUbot import *
import math

__MODULE__ = "ᴀꜱᴘᴇᴄᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}aspect</code></b></blockquote>"""


@PY.UBOT("aspect")
@PY.TOP_CMD
async def aspect(client, message):
    """ᴀꜱᴘᴇᴄᴛ"""
    try:
        args = message.text.split()
        w, h = int(args[1]), int(args[2])
        gcd = math.gcd(w, h)
        await message.edit(f"<b>📐 Aspect Ratio</b>\n\n<b>Resolution:</b> {w}x{h}\n<b>Ratio:</b> {w//gcd}:{h//gcd}\n<b>Megapixels:</b> {w*h/1000000:.2f} MP", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.aspect 1920 1080</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
