from PyroUbot import *
import aiohttp

__MODULE__ = "ꜰᴏx"
__HELP__ = """<blockquote><b>⎆ <code>{0}fox</code></b></blockquote>"""


@PY.UBOT("fox")
@PY.TOP_CMD
async def fox(client, message):
    """ꜰᴏx"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://randomfox.ca/floof/") as r:
                d = await r.json()
        await message.edit(f"<b>🦊 Random Fox</b>\n\n<a href='{d['image']}'>🖼 View Image</a>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
