from PyroUbot import *
import aiohttp

__MODULE__ = "🦘 Kangaroo"
__HELP__ = """<blockquote><b>⎆ <code>{0}kangaroo</code></b></blockquote>"""


@PY.UBOT("kangaroo")
@PY.TOP_CMD
async def kangaroo(client, message):
    """🦘 Kangaroo"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://some-random-api.com/animal/kangaroo") as r:
                d = await r.json()
        result = d.get('fact','No fact')
        await message.edit(f"<b>🦘 Kangaroo Fact</b>\n\n{result}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
