from PyroUbot import *
import random

__MODULE__ = "ᴄᴏᴍᴘᴀᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}compat</code></b></blockquote>"""


@PY.UBOT("compat")
@PY.TOP_CMD
async def compatibility(client, message):
    """ᴄᴏᴍᴘᴀᴛ"""
    try:
        args = message.text.split(None, 1)[1].split(" and ") if len(message.text.split()) > 1 else ["You", "Someone"]
        if len(args) < 2:
            args = [args[0], "Someone"]
        pct = random.randint(10, 100)
        await message.edit(f"<b>💞 Compatibility</b>\n\n<b>{args[0]}</b> & <b>{args[1]}</b>\n\n{'💖' * (pct//20)} {pct}%", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
