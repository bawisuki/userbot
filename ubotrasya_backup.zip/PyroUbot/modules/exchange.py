from PyroUbot import *
import aiohttp

__MODULE__ = "ᴇxᴄʜᴀɴɢᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}rate</code></b></blockquote>"""


@PY.UBOT("rate")
@PY.TOP_CMD
async def exchange(client, message):
    """ᴇxᴄʜᴀɴɢᴇ"""
    try:
        args = message.text.split()
        base, target = args[1].upper(), args[2].upper()
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://open.er-api.com/v6/latest/{base}") as r:
                d = await r.json()
        if d.get("result") != "success":
            return await message.edit("<b>❌ Invalid currency.</b>", parse_mode=ParseMode.HTML)
        rate = d["rates"].get(target)
        if not rate:
            return await message.edit(f"<b>❌ Currency {target} not found.</b>", parse_mode=ParseMode.HTML)
        txt = f"<b>💱 Exchange Rate</b>\n\n<b>1 {base}</b> = <b>{rate:,.4f} {target}</b>"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.rate USD IDR</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
