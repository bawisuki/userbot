from PyroUbot import *

__MODULE__ = "⛽ Fuel"
__HELP__ = """<blockquote><b>⎆ <code>{0}fuel</code></b></blockquote>"""


@PY.UBOT("fuel")
@PY.TOP_CMD
async def fuelcalc(client, message):
    """⛽ Fuel"""
    try:
        args = message.text.split()
        km = float(args[1])
        liters = float(args[2])
        consumption = liters / km * 100
        await message.edit(f"<b>⛽ Fuel Economy</b>\n\n<b>{km}km on {liters}L</b>\n<b>Consumption:</b> {consumption:.2f} L/100km\n<b>Efficiency:</b> {km/liters:.2f} km/L", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Usage:</b> <code>.fuel km liters</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
