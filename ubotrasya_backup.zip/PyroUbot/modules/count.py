from PyroUbot import *

__MODULE__ = "ᴄᴏᴜɴᴛ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴄᴏᴜɴᴛ

⎆ <code>{0}count</code>
   ʜɪᴛᴜɴɢ ᴊᴜᴍʟᴀʜ ᴘᴇꜱᴀɴ ᴅɪ ᴄʜᴀᴛ

⎆ <code>{0}mycount</code>
   ʜɪᴛᴜɴɢ ᴘᴇꜱᴀɴ ꜱᴇɴᴅɪʀɪ ᴅɪ ᴄʜᴀᴛ</b></blockquote>
"""


@PY.UBOT("count")
@PY.TOP_CMD
async def count(client, message):
    try:
        await message.edit("<emoji id=5789858554890425372>🔄</emoji> <b>ᴍᴇɴɢʜɪᴛᴜɴɢ ᴘᴇꜱᴀɴ...</b>", parse_mode=ParseMode.HTML)
        total = await client.search_messages_count(message.chat.id)
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ᴛᴏᴛᴀʟ ᴘᴇꜱᴀɴ ᴅɪ ᴄʜᴀᴛ ɪɴɪ:</b> <code>{total}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("mycount")
@PY.TOP_CMD
async def mycount(client, message):
    try:
        await message.edit("<emoji id=5789858554890425372>🔄</emoji> <b>ᴍᴇɴɢʜɪᴛᴜɴɢ ᴘᴇꜱᴀɴ...</b>", parse_mode=ParseMode.HTML)
        me = await client.get_me()
        total = await client.search_messages_count(message.chat.id, from_user=me.id)
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ᴛᴏᴛᴀʟ ᴘᴇꜱᴀɴ ᴋᴀᴍᴜ ᴅɪ ᴄʜᴀᴛ ɪɴɪ:</b> <code>{total}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)
