from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄʀʏᴘᴛᴏ & ꜰɪɴᴀɴᴄᴇ"
__HELP__ = """
<blockquote><b>⎆ <code>{0}btc</code> <code>{0}eth</code> <code>{0}sol</code> ʜᴀʀɢᴀ ᴄʀʏᴘᴛᴏ
⎆ <code>{0}doge</code> <code>{0}ada</code> <code>{0}bnb</code> <code>{0}xrp</code>
⎆ <code>{0}topcoins</code> ᴛᴏᴘ 10 ᴄʀʏᴘᴛᴏ
⎆ <code>{0}rate</code> [FROM] [TO] ᴋᴜʀꜱ
⎆ <code>{0}kurs</code> [mata uang] ꜱᴇᴍᴜᴀ ᴋᴜʀꜱ
⎆ <code>{0}stock</code> [symbol] ꜱᴀʜᴀᴍ
⎆ <code>{0}gold</code> ʜᴀʀɢᴀ ᴇᴍᴀꜱ</b></blockquote>
"""



async def _get_crypto(message, coin):
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana&vs_currencies=usd") as r:
                d = await r.json()
        price = d[coin]["usd"]
        symbol = {"bitcoin": "₿ BTC", "ethereum": "⟠ ETH", "solana": "◎ SOL"}[coin]
        await message.edit(f"<b>{symbol}</b>\n💰 <b>Price:</b> ${price:,.2f} USD", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)

@PY.UBOT("btc")
@PY.TOP_CMD
async def btc(client, message):
    """ᴄʀʏᴘᴛᴏ"""
    await _get_crypto(message, "bitcoin")

@PY.UBOT("eth")
@PY.TOP_CMD
async def eth(client, message):
    """ᴄʀʏᴘᴛᴏ"""
    await _get_crypto(message, "ethereum")

@PY.UBOT("sol")
@PY.TOP_CMD
async def sol(client, message):
    """ᴄʀʏᴘᴛᴏ"""
    await _get_crypto(message, "solana")
