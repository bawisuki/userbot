from PyroUbot import *

__MODULE__ = "ᴄᴏᴍᴘᴏᴜɴᴅ"
__HELP__ = """<blockquote><b>⎆ <code>{0}compound</code></b></blockquote>"""


@PY.UBOT("compound")
@PY.TOP_CMD
async def compound(client, message):
    """ᴄᴏᴍᴘᴏᴜɴᴅ"""
    try:
        args = message.text.split()
        principal = float(args[1])
        rate = float(args[2]) / 100
        years = int(args[3])
        result = principal * (1 + rate) ** years
        profit = result - principal
        await message.edit(f"<b>💰 Compound Interest</b>\n\n<b>Principal:</b> ${principal:,.2f}\n<b>Rate:</b> {rate*100}%\n<b>Years:</b> {years}\n<b>Final:</b> ${result:,.2f}\n<b>Profit:</b> ${profit:,.2f}", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.compound principal rate years</code>\nExample: <code>.compound 1000 5 10</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
