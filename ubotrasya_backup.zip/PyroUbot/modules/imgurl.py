from PyroUbot import *
import aiohttp
import os

__MODULE__ = "ɪᴍɢ ᴜʀʟ"
__HELP__ = """<blockquote><b>⎆ <code>{0}imgurl</code></b></blockquote>"""


@PY.UBOT("imgurl")
@PY.TOP_CMD
async def imgurl(client, message):
    """ɪᴍɢ ᴜʀʟ"""
    try:
        reply = message.reply_to_message
        if not reply or not (reply.photo or reply.document):
            return await message.edit("<b>⚠️ Reply to a photo to upload.</b>", parse_mode=ParseMode.HTML)
        await message.edit("<b>⏳ Uploading image...</b>", parse_mode=ParseMode.HTML)
        path = await reply.download()
        async with aiohttp.ClientSession() as s:
            data = aiohttp.FormData()
            data.add_field("file", open(path, "rb"), filename="image.jpg", content_type="image/jpeg")
            async with s.post("https://telegra.ph/upload", data=data) as r:
                d = await r.json()
        os.remove(path)
        if isinstance(d, list) and "src" in d[0]:
            url = f"https://telegra.ph{d[0]['src']}"
            await message.edit(f"<b>🖼 Image Uploaded!</b>\n\n<b>🔗 URL:</b> {url}", parse_mode=ParseMode.HTML, disable_web_page_preview=True)
        else:
            await message.edit("<b>❌ Upload failed.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
