from PyroUbot import *
import random

__MODULE__ = "💝"
__HELP__ = """<blockquote><b>⎆ <code>{0}howkind</code></b></blockquote>"""


@PY.UBOT("howkind")
@PY.TOP_CMD
async def howkind(client, message):
    """💝"""
    try:
        target = message.reply_to_message.from_user.first_name if message.reply_to_message else "You"
        pct = random.randint(0, 100)
        await message.edit(f"<b>💝 How Kind?</b>\n\n{target} is <b>{pct}%</b> kind!", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
