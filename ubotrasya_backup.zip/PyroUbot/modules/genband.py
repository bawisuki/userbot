from PyroUbot import *
import random

__MODULE__ = "🎸 Band Nam"
__HELP__ = """<blockquote><b>⎆ <code>{0}genband</code></b></blockquote>"""


@PY.UBOT("genband")
@PY.TOP_CMD
async def genband(client, message):
    """🎸 Band Nam"""
    try:
        result = f"The {random.choice(['Electric','Cosmic','Midnight','Neon','Crystal','Velvet','Iron','Golden'])} {random.choice(['Wolves','Dragons','Phantoms','Knights','Ravens','Foxes','Tigers','Vipers'])}"
        await message.edit(f"<b>🎸 Band Name</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
