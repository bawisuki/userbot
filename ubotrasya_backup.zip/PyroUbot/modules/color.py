from PyroUbot import *
import os

__MODULE__ = "ᴄᴏʟᴏʀ color"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴄᴏʟᴏʀ

⎆ <code>{0}color</code> [hex]
   ɢᴇɴᴇʀᴀᴛᴇ ɢᴀᴍʙᴀʀ ᴡᴀʀɴᴀ ꜱᴏʟɪᴅ 200x200</b></blockquote>
"""


@PY.UBOT("color")
@PY.TOP_CMD
async def color_cmd(client, message):
    args = message.text.split(None, 1)
    if len(args) < 2:
        return await message.edit("<b><emoji id=5210952531676504517>❌</emoji> ɢᴜɴᴀᴋᴀɴ: <code>.color [hex]</code></b>")
    hex_color = args[1].strip().lstrip("#")
    await message.edit("<b><emoji id=5789858554890425372>🔄</emoji> ᴍᴇᴍʙᴜᴀᴛ ᴡᴀʀɴᴀ...</b>")
    try:
        from PIL import Image
        rgb = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        img = Image.new("RGB", (200, 200), rgb)
        file_path = "color_output.png"
        img.save(file_path)
        await client.send_photo(message.chat.id, file_path, caption=f"<b><emoji id=5206607081334906820>✅</emoji> ᴄᴏʟᴏʀ:</b> <code>#{hex_color.upper()}</code>", quote=True)
        await message.delete()
        os.remove(file_path)
    except Exception as e:
        await message.edit(f"<b><emoji id=5210952531676504517>❌</emoji> ᴇʀʀᴏʀ:</b> <code>{e}</code>")
