from PyroUbot import *

__MODULE__ = "ʙɪᴛʀᴀᴛᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}bitrate</code></b></blockquote>"""


@PY.UBOT("bitrate")
@PY.TOP_CMD
async def bitrateconv(client, message):
    """ʙɪᴛʀᴀᴛᴇ"""
    try:
        args = message.text.split()
        kbps = float(args[1])
        duration_min = float(args[2]) if len(args) > 2 else 3
        size_mb = (kbps * 1000 * duration_min * 60) / 8 / 1048576
        await message.edit(f"<b>🎵 Bitrate Calculator</b>\n\n<b>Bitrate:</b> {kbps} kbps\n<b>Duration:</b> {duration_min} min\n<b>File Size:</b> {size_mb:.2f} MB", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.bitrate kbps [minutes]</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
