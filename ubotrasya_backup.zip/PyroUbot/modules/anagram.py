from PyroUbot import *

__MODULE__ = "🔤 Anagram Check"
__HELP__ = """<blockquote><b>⎆ <code>{0}anagram</code></b></blockquote>"""


@PY.UBOT("anagram")
@PY.TOP_CMD
async def anagram(client, message):
    """🔤 Anagram Check"""
    try:
        args = message.text.split(None, 1)[1].split(",")
        if len(args) < 2:
            return await message.edit("<b>⚠️ Usage:</b> <code>.anagram word1, word2</code>", parse_mode=ParseMode.HTML)
        a = sorted(args[0].strip().lower().replace(" ",""))
        b = sorted(args[1].strip().lower().replace(" ",""))
        is_anagram = a == b
        status = "✅ Yes!" if is_anagram else "❌ No"
        await message.edit(f"<b>🔤 Anagram?</b>\n\n<code>{args[0].strip()}</code> & <code>{args[1].strip()}</code>\n\n<b>{status}</b>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Provide text.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
