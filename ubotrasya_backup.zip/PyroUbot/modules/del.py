from PyroUbot import *

__MODULE__ = "ᴅᴇʟᴇᴛᴇ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴅᴇʟᴇᴛᴇ

⎆ <code>{0}del</code>
   ʀᴇᴘʟʏ ᴍꜱɢ ᴜɴᴛᴜᴋ ʜᴀᴘᴜꜱ

⎆ <code>{0}delme</code>
   ʜᴀᴘᴜꜱ ᴘᴇꜱᴀɴ ꜱᴇɴᴅɪʀɪ</b></blockquote>
"""


@PY.UBOT("del")
@PY.TOP_CMD
async def delete(client, message):
    try:
        reply = message.reply_to_message
        if not reply:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ʀᴇᴘʟʏ ᴋᴇ ᴘᴇꜱᴀɴ!</b>", parse_mode=ParseMode.HTML)
        await reply.delete()
        await message.delete()
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("delme")
@PY.TOP_CMD
async def delme(client, message):
    try:
        await message.delete()
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)
