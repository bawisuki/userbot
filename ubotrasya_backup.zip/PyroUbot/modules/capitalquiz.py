from PyroUbot import *
import random

__MODULE__ = "ᴄᴀᴘɪᴛᴀʟ ǫᴜɪᴢ"
__HELP__ = """<blockquote><b>⎆ <code>{0}capitalquiz</code></b></blockquote>"""


@PY.UBOT("capitalquiz")
@PY.TOP_CMD
async def capitalquiz(client, message):
    """ᴄᴀᴘɪᴛᴀʟ ǫᴜɪᴢ"""
    try:
        capitals = {"Indonesia":"Jakarta","Japan":"Tokyo","France":"Paris","Germany":"Berlin","Brazil":"Brasilia","Australia":"Canberra","Canada":"Ottawa","Egypt":"Cairo","Thailand":"Bangkok","Vietnam":"Hanoi"}
        country, capital = random.choice(list(capitals.items()))
        await message.edit(f"<b>🌍 Capital Quiz</b>\n\nWhat is the capital of <b>{country}</b>?\n\n<tg-spoiler><b>Answer:</b> {capital}</tg-spoiler>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
