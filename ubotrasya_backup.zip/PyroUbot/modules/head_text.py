from PyroUbot import *

__MODULE__ = "ᴛᴏᴏʟ head"
__HELP__ = """<blockquote><b>⎆ <code>{0}head</code></b></blockquote>"""


@PY.UBOT("head")
@PY.TOP_CMD
async def head_text(client, message):
    """ᴛᴏᴏʟ"""
    try:
        args = message.text.split(None, 1)
        n = int(args[1]) if len(args) > 1 else 5
        text = message.reply_to_message.text if message.reply_to_message else ""
        lines = text.split("\n")[:n]
        await message.edit(f"<code>{chr(10).join(lines)}</code>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, TypeError):
        await message.edit("<b>⚠️ Provide text or reply to a message.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
