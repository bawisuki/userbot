from PyroUbot import *
import aiohttp
import random

__MODULE__ = "ʜᴀᴅɪᴛʜ"
__HELP__ = """<blockquote><b>⎆ <code>{0}hadith</code></b></blockquote>"""


@PY.UBOT("hadith")
@PY.TOP_CMD
async def hadith(client, message):
    """ʜᴀᴅɪᴛʜ"""
    try:
        num = message.text.split(None, 1)[1] if len(message.text.split()) > 1 else str(random.randint(1, 300))
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.hadith.gading.dev/books/muslim/{num}") as r:
                d = await r.json()
        if d.get("code") != 200:
            return await message.edit("<b>❌ Hadith not found.</b>", parse_mode=ParseMode.HTML)
        h = d["data"]["contents"]
        txt = f"<b>📜 Hadith Muslim #{num}</b>\n\n<b>{h['arab'][:1000]}</b>\n\n<i>{h['id'][:2000]}</i>"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
