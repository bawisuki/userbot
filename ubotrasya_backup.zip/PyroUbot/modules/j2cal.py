from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ j2cal"
__HELP__ = """<blockquote><b>⎆ <code>{0}j2cal</code></b></blockquote>"""


@PY.UBOT("j2cal")
@PY.TOP_CMD
async def j2cal(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val * 0.239006
        await message.edit(f"<b>📐 {val} joules = {result:.4f} calories</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.j2cal value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
