from PyroUbot import *
import random

__MODULE__ = "ᴋᴀᴏᴍᴏᴊɪ"
__HELP__ = """
<blockquote><b>꒰ 🧸 ꒱ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴋᴀᴏᴍᴏᴊɪ

⎆ <code>{0}kao</code> ᴋᴀᴏᴍᴏᴊɪ ʀᴀɴᴅᴏᴍ
⎆ <code>{0}kaohappy</code> ᴋᴀᴏᴍᴏᴊɪ ꜱᴇɴᴀɴɢ
⎆ <code>{0}kaosad</code> ᴋᴀᴏᴍᴏᴊɪ ꜱᴇᴅɪʜ
⎆ <code>{0}kaolove</code> ᴋᴀᴏᴍᴏᴊɪ ᴄɪɴᴛᴀ
⎆ <code>{0}kaoangry</code> ᴋᴀᴏᴍᴏᴊɪ ᴍᴀʀᴀʜ
⎆ <code>{0}kaocute</code> ᴋᴀᴏᴍᴏᴊɪ ɪᴍᴜᴛ
⎆ <code>{0}kaoshrug</code> ᴋᴀᴏᴍᴏᴊɪ ʙɪɴɢᴜɴɢ
⎆ <code>{0}textart</code> [text] ᴛᴇxᴛ ᴅᴇɴɢᴀɴ ᴅᴇᴋᴏʀᴀꜱɪ ɢᴇᴍᴏʏ</b></blockquote>
"""

HAPPY = [
    "(◕ᴗ◕✿)", "( ˶ˆᗜˆ˵ )", "(≧◡≦)", "(ᵔᴗᵔ)", "(*≧ω≦)",
    "(☆▽☆)", "(✧ω✧)", "( ˃̣̣̥ω˂̣̣̥ )", "ヽ(>∀<☆)ノ", "(ﾉ◕ヮ◕)ﾉ*:・ﾟ✧",
    "٩(◕‿◕｡)۶", "(◠‿◠)", "(*^‿^*)", "(⌒‿⌒)", "☆*:.｡.o(≧▽≦)o.｡.:*☆",
]

SAD = [
    "(╥﹏╥)", "(ᗒᗩᗕ)", "(｡•́︿•̀｡)", "(っ˘̩╭╮˘̩)っ", "( ´ ; ω ; ` )",
    "(ノ_<。)", "(T_T)", "( ; ω ; )", "｡ﾟ(ﾟ´ω`ﾟ)ﾟ｡", "(ಥ_ಥ)",
    "( ´•̥̥̥ω•̥̥̥` )", "(⌯˃̶᷄ ﹏ ˂̶᷄⌯)", "( ˃̣̣̥⌓˂̣̣̥ )", "ᶘ ᵒᴥᵒᶅ", "(｡ŏ﹏ŏ)",
]

LOVE = [
    "(♡ᴗ♡)", "(◍•ᴗ•◍)❤", "♡(ᐢ ᵕᐢ)", "(´,,•ω•,,)♡", "(*♡∀♡)",
    "(ɔˆ ³(ˆ⌣ˆc)", "( ˘ ³˘)♥", "♡＾▽＾♡", "(◕‿◕)♡", "❤(ˆ‿ˆ)❤",
    "( ◜‿◝ )♡", "♡(◡‿◡)", "(灬♥ω♥灬)", "(*˘︶˘*).｡*♡", "꒰˶• ༝ •˶꒱♡",
]

ANGRY = [
    "(╬ Ò﹏Ó)", "(ノಠ益ಠ)ノ彡┻━┻", "ヽ(`Д´)ノ", "(╯°□°）╯︵ ┻━┻",
    "(ᗒᗣᗕ)՞", "( ` ω ´ )", "(*`益´*)", "щ(ಠ益ಠщ)", "(≖_≖ )",
    "( •̀ω•́ )σ", "(¬_¬)", "ಠ_ಠ", "(눈_눈)", "(-_-メ)", "(ꐦ°᷄д°᷅)",
]

CUTE = [
    "꒰ᐢ. ̫ .ᐢ꒱", "꒰˶• ༝ •˶꒱", "(ᵔᴗᵔ)", "( ˘ᴗ˘ )", "ʕ•ᴥ•ʔ",
    "(◕ᴥ◕)", "₍ᐢ..ᐢ₎", "( ˶ˆ꒳ˆ˵ )", "꒰ ꒱", "(ᐡ •͈ ·̫ •͈ ᐡ)",
    "ᶻ 𝗓 𐰁", "( ᴗ͈ˬᴗ͈)◞", "꒰ ᐢ. ̫ .ᐢ ꒱", "(⑅˘͈ ᵕ ˘͈ )", "( ˃̶͈̀ᴗ˂̶͈́ )੭ꠥ⁾⁾",
]

SHRUG = [
    "¯\\_(ツ)_/¯", "┐(´д`)┌", "╮(╯_╰)╭", "¯\\(°_o)/¯", "ᕕ( ᐛ )ᕗ",
    "(ㆆ_ㆆ)", "( ˙-˙ )", "(・・ ) ?", "(?_?)", "( ´_ゝ`)",
]


@PY.UBOT("kao")
@PY.TOP_CMD
async def kao_random(client, message):
    all_kao = HAPPY + SAD + LOVE + ANGRY + CUTE + SHRUG
    await message.reply(random.choice(all_kao))


@PY.UBOT("kaohappy")
@PY.TOP_CMD
async def kao_happy(client, message):
    await message.reply(random.choice(HAPPY))


@PY.UBOT("kaosad")
@PY.TOP_CMD
async def kao_sad(client, message):
    await message.reply(random.choice(SAD))


@PY.UBOT("kaolove")
@PY.TOP_CMD
async def kao_love(client, message):
    await message.reply(random.choice(LOVE))


@PY.UBOT("kaoangry")
@PY.TOP_CMD
async def kao_angry(client, message):
    await message.reply(random.choice(ANGRY))


@PY.UBOT("kaocute")
@PY.TOP_CMD
async def kao_cute(client, message):
    await message.reply(random.choice(CUTE))


@PY.UBOT("kaoshrug")
@PY.TOP_CMD
async def kao_shrug(client, message):
    await message.reply(random.choice(SHRUG))


@PY.UBOT("textart")
@PY.TOP_CMD
async def textart_cmd(client, message):
    if len(message.command) < 2 and not (message.reply_to_message and message.reply_to_message.text):
        return await message.reply("ketik text nya~ ꒰ᐢ. ̫ .ᐢ꒱", quote=True)
    
    text = message.reply_to_message.text if message.reply_to_message and message.reply_to_message.text else " ".join(message.command[1:])
    
    styles = [
        f"┊ ˚ ₊ ✧ {text} ✧ ₊ ˚ ┊",
        f"꒰ 🎀 ꒱ {text} ꒰ 🎀 ꒱",
        f"⋆˚✿˖° {text} °˖✿˚⋆",
        f"─── ⋆⋅☆⋅⋆ ── {text} ── ⋆⋅☆⋅⋆ ───",
        f"✦•┈๑⋅⋯ {text} ⋯⋅๑┈•✦",
        f"╭─── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ───╮\n   {text}\n╰─── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ───╯",
        f"♡₊˚ 🦢・₊✧ {text} ✧₊・🦢 ˚₊♡",
        f"˗ˏˋ ꒰ {text} ꒱ ˎˊ˗",
    ]
    result = "\n\n".join(styles)
    await message.reply(result, quote=True)
