from PyroUbot import *
import random

__MODULE__ = "ʜᴏᴡ ꜰᴜɴɴʏ"
__HELP__ = """<blockquote><b>⎆ <code>{0}howfunny</code></b></blockquote>"""


@PY.UBOT("howfunny")
@PY.TOP_CMD
async def howfunny(client, message):
    """ʜᴏᴡ ꜰᴜɴɴʏ"""
    try:
        target = message.reply_to_message.from_user.first_name if message.reply_to_message else "You"
        pct = random.randint(0, 100)
        await message.edit(f"<b>😂 How Funny?</b>\n\n{target} is <b>{pct}%</b> funny!", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
