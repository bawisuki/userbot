from PyroUbot import *
import aiohttp

__MODULE__ = "ᴀɢᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}age</code></b></blockquote>"""


@PY.UBOT("age")
@PY.TOP_CMD
async def age(client, message):
    """ᴀɢᴇ"""
    try:
        from datetime import datetime
        dob = message.text.split(None, 1)[1]
        birth = datetime.strptime(dob, "%Y-%m-%d")
        now = datetime.now()
        age_years = now.year - birth.year - ((now.month, now.day) < (birth.month, birth.day))
        days_alive = (now - birth).days
        await message.edit(f"<b>🎂 Age Calculator</b>\n\n<b>Age:</b> {age_years} years\n<b>Days alive:</b> {days_alive:,}", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.age 2000-01-15</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
