from PyroUbot import *
import random

__MODULE__ = "ʜᴏᴡ ʀɪᴄʜ"
__HELP__ = """<blockquote><b>⎆ <code>{0}howrich</code></b></blockquote>"""


@PY.UBOT("howrich")
@PY.TOP_CMD
async def howrich(client, message):
    """ʜᴏᴡ ʀɪᴄʜ"""
    try:
        target = message.reply_to_message.from_user.first_name if message.reply_to_message else "You"
        money = random.randint(0, 999999999)
        await message.edit(f"<b>💰 How Rich?</b>\n\n{target}\'s net worth: <b>${money:,}</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
