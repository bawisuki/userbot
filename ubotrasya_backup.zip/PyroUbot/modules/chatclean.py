from PyroUbot import *

__MODULE__ = "ᴄʟᴇᴀɴ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴄʟᴇᴀɴ

⎆ <code>{0}clean</code> [n] ʜᴀᴘᴜꜱ ɴ ᴘᴇꜱᴀɴ ᴛᴇʀᴀᴋʜɪʀ ᴅɪ ᴄʜᴀᴛ</b></blockquote>
"""


@PY.UBOT("clean")
@PY.TOP_CMD
async def clean_cmd(client, message):
    try:
        args = message.text.split(None, 1)
        if len(args) < 2 or not args[1].isdigit():
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.clean [jumlah]</code>", parse_mode=ParseMode.HTML)
        n = int(args[1])
        if n > 100:
            n = 100
        await message.delete()
        msg_ids = []
        async for msg in client.get_chat_history(message.chat.id, limit=n):
            msg_ids.append(msg.id)
        if msg_ids:
            for i in range(0, len(msg_ids), 100):
                await client.delete_messages(message.chat.id, msg_ids[i:i+100])
        await client.send_message(
            message.chat.id,
            f"<emoji id=5206607081334906820>✅</emoji> <b>ʙᴇʀʜᴀꜱɪʟ ᴍᴇɴɢʜᴀᴘᴜꜱ {len(msg_ids)} ᴘᴇꜱᴀɴ!</b>",
            parse_mode=ParseMode.HTML,
        )
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
