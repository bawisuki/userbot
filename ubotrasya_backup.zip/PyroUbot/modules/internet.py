from PyroUbot import *
import random

__MODULE__ = "🌐 Intern"
__HELP__ = """<blockquote><b>⎆ <code>{0}netfact</code></b></blockquote>"""


@PY.UBOT("netfact")
@PY.TOP_CMD
async def internet(client, message):
    """🌐 Intern"""
    try:
        items = ['The first email was sent in 1971.', 'Google processes over 8.5 billion searches per day.', 'The first website went live on August 6, 1991.', 'Over 500 hours of video are uploaded to YouTube every minute.', 'The internet weighs about 50 grams (the weight of electrons).']
        await message.edit(f"<b>🌐 Internet</b>\n\n<i>{random.choice(items)}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
