from PyroUbot import *
import json

__MODULE__ = "ʙᴏᴏᴋᴍᴀʀᴋ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ʙᴏᴏᴋᴍᴀʀᴋ

⎆ <code>{0}bm add</code> [url] [nama] ꜱɪᴍᴘᴀɴ ʙᴏᴏᴋᴍᴀʀᴋ
⎆ <code>{0}bm list</code> ʟɪʜᴀᴛ ꜱᴇᴍᴜᴀ ʙᴏᴏᴋᴍᴀʀᴋ
⎆ <code>{0}bm del</code> [nama] ʜᴀᴘᴜꜱ ʙᴏᴏᴋᴍᴀʀᴋ</b></blockquote>
"""


@PY.UBOT("bm")
@PY.TOP_CMD
async def bookmark_cmd(client, message):
    try:
        args = message.text.split(None, 3)
        if len(args) < 2:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.bm add/list/del</code>", parse_mode=ParseMode.HTML)
        sub = args[1].lower()
        bm_raw = await get_vars(client.me.id, "BOOKMARK_DATA")
        bm = json.loads(bm_raw) if bm_raw else {}

        if sub == "add":
            if len(args) < 4:
                return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.bm add [url] [nama]</code>", parse_mode=ParseMode.HTML)
            url, nama = args[2], args[3].lower()
            bm[nama] = url
            await set_vars(client.me.id, "BOOKMARK_DATA", json.dumps(bm))
            await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ʙᴏᴏᴋᴍᴀʀᴋ '<code>{nama}</code>' ᴅɪꜱɪᴍᴘᴀɴ!</b>", parse_mode=ParseMode.HTML)

        elif sub == "list":
            if not bm:
                return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ʙᴇʟᴜᴍ ᴀᴅᴀ ʙᴏᴏᴋᴍᴀʀᴋ!</b>", parse_mode=ParseMode.HTML)
            text = "<emoji id=5206607081334906820>✅</emoji> <b>ᴅᴀꜰᴛᴀʀ ʙᴏᴏᴋᴍᴀʀᴋ:</b>\n\n"
            for i, (nama, url) in enumerate(bm.items(), 1):
                text += f"  {i}. <b>{nama}</b> - <code>{url}</code>\n"
            await message.edit(text, parse_mode=ParseMode.HTML)

        elif sub == "del":
            if len(args) < 3:
                return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.bm del [nama]</code>", parse_mode=ParseMode.HTML)
            nama = args[2].lower()
            if nama not in bm:
                return await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ʙᴏᴏᴋᴍᴀʀᴋ '<code>{nama}</code>' ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ!</b>", parse_mode=ParseMode.HTML)
            del bm[nama]
            await set_vars(client.me.id, "BOOKMARK_DATA", json.dumps(bm))
            await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ʙᴏᴏᴋᴍᴀʀᴋ '<code>{nama}</code>' ᴅɪʜᴀᴘᴜꜱ!</b>", parse_mode=ParseMode.HTML)
        else:
            await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.bm add/list/del</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
