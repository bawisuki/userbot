from pyrogram import filters
from PyroUbot import *
from PyroUbot.core.database import db_exec, db_fetchone

__MODULE__ = "ɢᴏᴏᴅʙʏᴇ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ɢᴏᴏᴅʙʏᴇ

⎆ <code>{0}setgoodbye [text]</code> ꜱᴇᴛ ᴘᴇꜱᴀɴ ɢᴏᴏᴅʙʏᴇ
⎆ <code>{0}delgoodbye</code> ʜᴀᴘᴜꜱ ᴘᴇꜱᴀɴ ɢᴏᴏᴅʙʏᴇ</b></blockquote>
"""


@PY.UBOT("setgoodbye")
@PY.TOP_CMD
async def setgoodbye_cmd(client, message):
    try:
        args = message.text.split(None, 1)
        if len(args) < 2:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ: .setgoodbye [text]</b>", parse_mode=ParseMode.HTML)
        text = args[1]
        chat_id = message.chat.id
        await db_exec("INSERT INTO goodbye (chat_id, message) VALUES (%s, %s) ON DUPLICATE KEY UPDATE message=%s", (chat_id, text, text))
        await message.edit("<emoji id=5206607081334906820>✅</emoji> <b>ᴘᴇꜱᴀɴ ɢᴏᴏᴅʙʏᴇ ᴅɪꜱᴇᴛ!</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("delgoodbye")
@PY.TOP_CMD
async def delgoodbye_cmd(client, message):
    try:
        await db_exec("DELETE FROM goodbye WHERE chat_id=%s", (message.chat.id,))
        await message.edit("<emoji id=5206607081334906820>✅</emoji> <b>ᴘᴇꜱᴀɴ ɢᴏᴏᴅʙʏᴇ ᴅɪʜᴀᴘᴜꜱ!</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)


(filters.left_chat_member)
async def goodbye_handler(client, message):
    chat_id = message.chat.id
    row = await db_fetchone("SELECT message FROM goodbye WHERE chat_id=%s", (chat_id,))
    if not row:
        return
    user = message.left_chat_member
    text = row["message"].replace("{name}", user.first_name).replace("{id}", str(user.id)).replace("{chat}", message.chat.title or "")
    try:
        await message.reply(text, parse_mode=ParseMode.HTML, quote=True)
    except Exception:
        pass
