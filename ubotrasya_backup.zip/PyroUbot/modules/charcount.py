from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄʜᴀʀ ᴄᴏᴜɴᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}charcount</code></b></blockquote>"""


@PY.UBOT("charcount")
@PY.TOP_CMD
async def charcount(client, message):
    """ᴄʜᴀʀ ᴄᴏᴜɴᴛ"""
    try:
        text = message.reply_to_message.text if message.reply_to_message else message.text.split(None, 1)[1]
        chars = len(text)
        words = len(text.split())
        lines = text.count("\n") + 1
        await message.edit(f"<b>📊 Text Stats</b>\n\n<b>Characters:</b> {chars}\n<b>Words:</b> {words}\n<b>Lines:</b> {lines}", parse_mode=ParseMode.HTML)
    except (IndexError, TypeError):
        await message.edit("<b>⚠️ Reply to a message or provide text.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
