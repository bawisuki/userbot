from PyroUbot import *
import hashlib

__MODULE__ = "ʜᴀꜱʜ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ʜᴀꜱʜ

⎆ <code>{0}md5</code> [text]
   ʜᴀꜱʜ ᴍᴅ5

⎆ <code>{0}sha1</code> [text]
   ʜᴀꜱʜ ꜱʜᴀ1

⎆ <code>{0}sha256</code> [text]
   ʜᴀꜱʜ ꜱʜᴀ256</b></blockquote>
"""


@PY.UBOT("md5")
@PY.TOP_CMD
async def md5(client, message):
    try:
        text = message.text.split(None, 1)
        if len(text) < 2:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.md5 [text]</code>", parse_mode=ParseMode.HTML)
        result = hashlib.md5(text[1].encode()).hexdigest()
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ᴍᴅ5:</b>\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("sha1")
@PY.TOP_CMD
async def sha1(client, message):
    try:
        text = message.text.split(None, 1)
        if len(text) < 2:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.sha1 [text]</code>", parse_mode=ParseMode.HTML)
        result = hashlib.sha1(text[1].encode()).hexdigest()
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ꜱʜᴀ1:</b>\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("sha256")
@PY.TOP_CMD
async def sha256(client, message):
    try:
        text = message.text.split(None, 1)
        if len(text) < 2:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.sha256 [text]</code>", parse_mode=ParseMode.HTML)
        result = hashlib.sha256(text[1].encode()).hexdigest()
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ꜱʜᴀ256:</b>\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)
