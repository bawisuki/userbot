from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄʀᴀᴛᴇꜱ"
__HELP__ = """<blockquote><b>⎆ <code>{0}crates</code></b></blockquote>"""


@PY.UBOT("crates")
@PY.TOP_CMD
async def crates(client, message):
    """ᴄʀᴀᴛᴇꜱ"""
    try:
        pkg = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://crates.io/api/v1/crates/{pkg}") as r:
                if r.status != 200:
                    return await message.edit("<b>❌ Crate not found.</b>", parse_mode=ParseMode.HTML)
                d = await r.json()
        c = d["crate"]
        txt = (
            f"<b>🦀 {c['name']}</b> v{c.get('newest_version', 'N/A')}\n\n"
            f"<b>📝 Description:</b> {c.get('description', 'N/A')}\n"
            f"<b>📥 Downloads:</b> {c.get('downloads', 0):,}\n"
            f"<b>🔗 URL:</b> https://crates.io/crates/{pkg}"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.crates package</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
