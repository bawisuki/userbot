from PyroUbot import *
import random

__MODULE__ = "ꜰʟᴀɢ ǫᴜɪᴢ"
__HELP__ = """<blockquote><b>⎆ <code>{0}flagquiz</code></b></blockquote>"""


@PY.UBOT("flagquiz")
@PY.TOP_CMD
async def flagquiz(client, message):
    """ꜰʟᴀɢ ǫᴜɪᴢ"""
    try:
        flags = {"🇮🇩":"Indonesia","🇯🇵":"Japan","🇺🇸":"USA","🇬🇧":"UK","🇫🇷":"France","🇩🇪":"Germany","🇧🇷":"Brazil","🇰🇷":"South Korea","🇮🇳":"India","🇦🇺":"Australia","🇨🇦":"Canada","🇲🇽":"Mexico","🇮🇹":"Italy","🇪🇸":"Spain","🇷🇺":"Russia"}
        flag, country = random.choice(list(flags.items()))
        await message.edit(f"<b>🏳️ Flag Quiz</b>\n\n{flag}\n\n<tg-spoiler><b>Answer:</b> {country}</tg-spoiler>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
