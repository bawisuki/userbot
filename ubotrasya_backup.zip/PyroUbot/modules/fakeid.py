from PyroUbot import *
import aiohttp

__MODULE__ = "ꜰᴀᴋᴇ ɪᴅ"
__HELP__ = """<blockquote><b>⎆ <code>{0}fakeid</code></b></blockquote>"""


@PY.UBOT("fakeid")
@PY.TOP_CMD
async def fakeid(client, message):
    """ꜰᴀᴋᴇ ɪᴅ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://randomuser.me/api/") as r:
                d = (await r.json())["results"][0]
        name = f"{d['name']['first']} {d['name']['last']}"
        txt = (
            f"<b>🎭 Fake Identity</b>\n\n"
            f"<b>👤 Name:</b> {name}\n"
            f"<b>📧 Email:</b> {d['email']}\n"
            f"<b>📱 Phone:</b> {d['phone']}\n"
            f"<b>🏠 Address:</b> {d['location']['street']['number']} {d['location']['street']['name']}, {d['location']['city']}, {d['location']['country']}\n"
            f"<b>🎂 DOB:</b> {d['dob']['date'][:10]}\n"
            f"<b>🌐 Username:</b> {d['login']['username']}"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
