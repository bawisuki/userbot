from PyroUbot import *
import aiohttp

__MODULE__ = "ᴅɴꜱ ᴛxᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}dnstxt</code></b></blockquote>"""


@PY.UBOT("dnstxt")
@PY.TOP_CMD
async def dnstxt(client, message):
    """ᴅɴꜱ ᴛxᴛ"""
    try:
        domain = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://dns.google/resolve?name={domain}&type=TXT") as r:
                d = await r.json()
        if "Answer" not in d:
            return await message.edit("<b>❌ No TXT records.</b>", parse_mode=ParseMode.HTML)
        records = "\n".join([f"• <code>{a['data'][:100]}</code>" for a in d["Answer"][:10]])
        await message.edit(f"<b>📝 TXT Records: {domain}</b>\n\n{records}", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.dnstxt domain</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
