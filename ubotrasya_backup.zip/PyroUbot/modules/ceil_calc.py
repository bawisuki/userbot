from PyroUbot import *

__MODULE__ = "ceiling"
__HELP__ = """<blockquote><b>⎆ <code>{0}ceil</code></b></blockquote>"""


@PY.UBOT("ceil")
@PY.TOP_CMD
async def ceil_calc(client, message):
    """ceiling"""
    try:
        import math
        val = float(message.text.split(None, 1)[1])
        await message.edit(f"<b>⌈{val}⌉ = {math.ceil(val)}</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Provide valid numbers.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
