from PyroUbot import *
import time
import os

_START_TIME = time.time()

__MODULE__ = "ᴀʟɪᴠᴇ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴀʟɪᴠᴇ

⎆ <code>{0}alive2</code> ᴛᴀᴍᴘɪʟᴋᴀɴ ʙᴏᴛ ᴀʟɪᴠᴇ ᴍᴇꜱꜱᴀɢᴇ</b></blockquote>
"""


@PY.UBOT("alive2")
@PY.TOP_CMD
async def alive_cmd(client, message):
    try:
        uptime_sec = int(time.time() - _START_TIME)
        hours, remainder = divmod(uptime_sec, 3600)
        mins, secs = divmod(remainder, 60)
        modules_path = os.path.dirname(os.path.abspath(__file__))
        modules_count = len([f for f in os.listdir(modules_path) if f.endswith(".py") and f != "__init__.py"])
        prefix = await ubot.get_prefix(client.me.id)
        prefix_str = prefix[0] if prefix else "."
        text = (
            f"<emoji id=5206607081334906820>✅</emoji> <b>ʀᴀꜱʏᴀxɪɴꜱᴀᴀ ᴜꜱᴇʀʙᴏᴛ</b>\n\n"
            f"<b>⎆ ᴏᴡɴᴇʀ:</b> <a href='tg://user?id={client.me.id}'>{client.me.first_name}</a>\n"
            f"<b>⎆ ᴜᴘᴛɪᴍᴇ:</b> <code>{hours}j {mins}m {secs}s</code>\n"
            f"<b>⎆ ᴍᴏᴅᴜʟᴇꜱ:</b> <code>{modules_count}</code>\n"
            f"<b>⎆ ᴘʀᴇꜰɪx:</b> <code>{prefix_str}</code>\n\n"
            f"<b>⚡ ᴘᴏᴡᴇʀᴇᴅ ʙʏ ʀᴀꜱʏᴀxɪɴꜱᴀᴀ</b>"
        )
        await message.edit(text, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
