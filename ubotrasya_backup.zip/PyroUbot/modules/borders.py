from PyroUbot import *
import aiohttp
from urllib.parse import quote

__MODULE__ = "ʙᴏʀᴅᴇʀꜱ"
__HELP__ = """<blockquote><b>⎆ <code>{0}borders</code></b></blockquote>"""


@PY.UBOT("borders")
@PY.TOP_CMD
async def borders(client, message):
    """ʙᴏʀᴅᴇʀꜱ"""
    try:
        name = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://restcountries.com/v3.1/name/{quote(name)}?fields=name,borders") as r:
                d = await r.json()
        c = d[0]
        borders = c.get("borders", [])
        await message.edit(f"<b>🗺 Borders: {c['name']['common']}</b>\n\n<b>Neighbors:</b> {', '.join(borders) if borders else 'None (island)'}", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.borders country</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
