import re
from pyrogram import filters
from PyroUbot import *
from PyroUbot.core.database import db_exec, db_fetchone

__MODULE__ = "ᴀɴᴛɪʟɪɴᴋ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴀɴᴛɪʟɪɴᴋ

⎆ <code>{0}antilink on</code> ᴀᴋᴛɪꜰᴋᴀɴ ᴀɴᴛɪʟɪɴᴋ
⎆ <code>{0}antilink off</code> ᴍᴀᴛɪᴋᴀɴ ᴀɴᴛɪʟɪɴᴋ</b></blockquote>
"""

LINK_PATTERN = re.compile(r"https?://|t\.me/|telegram\.me/", re.IGNORECASE)


@PY.UBOT("antilink")
@PY.TOP_CMD
async def antilink_cmd(client, message):
    try:
        args = message.text.split(None, 1)
        if len(args) < 2:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ: .antilink on/off</b>", parse_mode=ParseMode.HTML)
        val = args[1].strip().lower()
        chat_id = message.chat.id
        if val == "on":
            await db_exec("INSERT INTO antilink (chat_id, status) VALUES (%s, 1) ON DUPLICATE KEY UPDATE status=1", (chat_id,))
            await message.edit("<emoji id=5206607081334906820>✅</emoji> <b>ᴀɴᴛɪʟɪɴᴋ ᴅɪᴀᴋᴛɪꜰᴋᴀɴ!</b>", parse_mode=ParseMode.HTML)
        elif val == "off":
            await db_exec("UPDATE antilink SET status=0 WHERE chat_id=%s", (chat_id,))
            await message.edit("<emoji id=5206607081334906820>✅</emoji> <b>ᴀɴᴛɪʟɪɴᴋ ᴅɪᴍᴀᴛɪᴋᴀɴ!</b>", parse_mode=ParseMode.HTML)
        else:
            await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ: .antilink on/off</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)


(filters.group & filters.incoming & ~filters.me)
async def antilink_handler(client, message):
    if not message.text and not message.caption:
        return
    text = message.text or message.caption or ""
    if not LINK_PATTERN.search(text):
        return
    chat_id = message.chat.id
    row = await db_fetchone("SELECT status FROM antilink WHERE chat_id=%s", (chat_id,))
    if row and row.get("status") == 1:
        try:
            await message.delete()
        except Exception:
            pass
