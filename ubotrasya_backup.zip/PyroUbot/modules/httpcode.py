from PyroUbot import *

__MODULE__ = "ʜᴛᴛᴘ ᴄᴏᴅᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}httpcode</code></b></blockquote>"""


@PY.UBOT("httpcode")
@PY.TOP_CMD
async def httpcode(client, message):
    """ʜᴛᴛᴘ ᴄᴏᴅᴇ"""
    try:
        code = message.text.split(None, 1)[1]
        codes = {"200":"OK","201":"Created","204":"No Content","301":"Moved Permanently","302":"Found","304":"Not Modified","400":"Bad Request","401":"Unauthorized","403":"Forbidden","404":"Not Found","405":"Method Not Allowed","408":"Request Timeout","429":"Too Many Requests","500":"Internal Server Error","502":"Bad Gateway","503":"Service Unavailable","504":"Gateway Timeout"}
        desc = codes.get(code, "Unknown")
        await message.edit(f"<b>📡 HTTP {code}</b>\n\n<b>Description:</b> {desc}\n<b>🐱 Cat:</b> https://http.cat/{code}", parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.httpcode 404</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
