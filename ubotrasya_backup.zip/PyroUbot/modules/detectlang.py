from PyroUbot import *
import aiohttp
from urllib.parse import quote

__MODULE__ = "ᴅᴇᴛᴇᴄᴛ ʟᴀɴɢ"
__HELP__ = """<blockquote><b>⎆ <code>{0}detectlang</code></b></blockquote>"""


@PY.UBOT("detectlang")
@PY.TOP_CMD
async def detectlang(client, message):
    """ᴅᴇᴛᴇᴄᴛ ʟᴀɴɢ"""
    try:
        text = message.text.split(None, 1)[1] if len(message.text.split()) > 1 else (message.reply_to_message.text if message.reply_to_message else None)
        if not text:
            return await message.edit("<b>⚠️ Provide text or reply.</b>", parse_mode=ParseMode.HTML)
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.mymemory.translated.net/get?q={quote(text[:200])}&langpair=auto|en") as r:
                d = await r.json()
        lang = d.get("responseData", {}).get("detectedLanguage", "unknown")
        await message.edit(f"<b>🔍 Detected Language:</b> <code>{lang}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
