from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄᴀʀʙᴏɴ carbon"
__HELP__ = """<blockquote><b>⎆ <code>{0}carbon</code></b></blockquote>"""


@PY.UBOT("carbon")
@PY.TOP_CMD
async def carbon(client, message):
    """ᴄᴀʀʙᴏɴ"""
    try:
        reply = message.reply_to_message
        if not reply or not reply.text:
            return await message.edit("<b>⚠️ Reply to a text message.</b>", parse_mode=ParseMode.HTML)
        code = reply.text[:1000]
        url = f"https://carbonara.solopov.dev/api/cook"
        async with aiohttp.ClientSession() as s:
            async with s.post(url, json={"code": code, "theme": "monokai"}) as r:
                if r.status == 200:
                    data = await r.read()
                    with open("/tmp/carbon.png", "wb") as f:
                        f.write(data)
                    await message.reply_photo("/tmp/carbon.png")
                    await message.delete()
                else:
                    await message.edit("<b>❌ Failed to generate carbon image.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
