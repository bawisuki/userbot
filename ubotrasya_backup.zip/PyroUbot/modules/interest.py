from PyroUbot import *

__MODULE__ = "simple interest"
__HELP__ = """<blockquote><b>⎆ <code>{0}interest</code></b></blockquote>"""


@PY.UBOT("interest")
@PY.TOP_CMD
async def interest(client, message):
    """simple interest"""
    try:
        args = message.text.split()
        p = float(args[1])
        r = float(args[2])
        t = float(args[3])
        i = p * r * t / 100
        await message.edit(f"<b>💰 Simple Interest</b>\n\nP={p:,.0f} R={r}% T={t}yr\n<b>Interest: {i:,.2f}</b>\n<b>Total: {p+i:,.2f}</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Provide valid numbers.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
