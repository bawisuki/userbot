from PyroUbot import *
import aiohttp

__MODULE__ = "ᴅᴇʙɪɴᴀʀʏ"
__HELP__ = """<blockquote><b>⎆ <code>{0}debinary</code></b></blockquote>"""


@PY.UBOT("debinary")
@PY.TOP_CMD
async def debinary(client, message):
    """ᴅᴇʙɪɴᴀʀʏ"""
    try:
        code = message.text.split(None, 1)[1]
        chars = code.split()
        result = "".join(chr(int(b, 2)) for b in chars)
        await message.edit(f"<b>💻 Decoded Binary</b>\n\n<code>{result[:3000]}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.debinary 01001000 01101001</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
