from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ ft2m"
__HELP__ = """<blockquote><b>⎆ <code>{0}ft2m</code></b></blockquote>"""


@PY.UBOT("ft2m")
@PY.TOP_CMD
async def ft2m(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val * 0.3048
        await message.edit(f"<b>📐 {val} feet = {result:.4f} meters</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.ft2m value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
