from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ hp2watt"
__HELP__ = """<blockquote><b>⎆ <code>{0}hp2watt</code></b></blockquote>"""


@PY.UBOT("hp2watt")
@PY.TOP_CMD
async def hp2watt2(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val*745.7
        await message.edit(f"<b>📐 {val} hp = {result:.6g} watts</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.hp2watt value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
