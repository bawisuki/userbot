from PyroUbot import *
import aiohttp
from urllib.parse import quote

__MODULE__ = "ᴄᴏᴜɴᴛʀʏ ᴄᴏᴅᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}countrycode</code></b></blockquote>"""


@PY.UBOT("countrycode")
@PY.TOP_CMD
async def countryphone(client, message):
    """ᴄᴏᴜɴᴛʀʏ ᴄᴏᴅᴇ"""
    try:
        name = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://restcountries.com/v3.1/name/{quote(name)}?fields=name,cca2,idd,capital,population,region") as r:
                d = await r.json()
        c = d[0]
        root = c.get("idd",{}).get("root","")
        suffix = c.get("idd",{}).get("suffixes",[""])[0]
        await message.edit(f"<b>🌍 {c['name']['common']}</b>\n\n<b>Code:</b> {c['cca2']}\n<b>Phone:</b> {root}{suffix}\n<b>Capital:</b> {', '.join(c.get('capital',[]))}\n<b>Population:</b> {c['population']:,}\n<b>Region:</b> {c['region']}", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.countrycode name</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
