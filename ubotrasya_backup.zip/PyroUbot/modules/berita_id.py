from PyroUbot import *
import aiohttp

__MODULE__ = "ʙᴇʀɪᴛᴀ"
__HELP__ = """
<blockquote><b>꒰ 📰 ꒱ ʙᴀɴᴛᴜᴀɴ ʙᴇʀɪᴛᴀ ɪɴᴅᴏɴᴇꜱɪᴀ
⎆ <code>{0}berita</code> ʙᴇʀɪᴛᴀ ᴛᴇʀᴋɪɴɪ CNN
⎆ <code>{0}beritacnn</code> ʙᴇʀɪᴛᴀ CNN ɪɴᴅᴏɴᴇꜱɪᴀ
⎆ <code>{0}beritacnbc</code> ʙᴇʀɪᴛᴀ CNBC ɪɴᴅᴏɴᴇꜱɪᴀ</b></blockquote>
"""


async def _fetch_news(message, url, source):
    await message.edit("<b>꒰ 📰 ꒱ ꜱᴇᴅᴀɴɢ ᴍᴇᴍᴜᴀᴛ...</b>")
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                data = (await resp.json(content_type=None))["data"]
        text = f"<b>꒰ 📰 ꒱ ʙᴇʀɪᴛᴀ {source}</b>\n\n"
        for item in data[:7]:
            title = item.get("title", "")
            link = item.get("link", "")
            text += f"• <a href='{link}'>{title}</a>\n\n"
        await message.edit(text, disable_web_page_preview=True)
    except Exception as e:
        await message.edit(f"<b>꒰ ❌ ꒱ ᴇʀʀᴏʀ:</b> <code>{e}</code>")


@PY.UBOT("berita")
@PY.TOP_CMD
async def berita_cmd(client, message):
    await _fetch_news(message, "https://berita-indo-api-next.vercel.app/api/cnn-news", "CNN ɪɴᴅᴏɴᴇꜱɪᴀ")


@PY.UBOT("beritacnn")
@PY.TOP_CMD
async def beritacnn_cmd(client, message):
    await _fetch_news(message, "https://berita-indo-api-next.vercel.app/api/cnn-news", "CNN ɪɴᴅᴏɴᴇꜱɪᴀ")


@PY.UBOT("beritacnbc")
@PY.TOP_CMD
async def beritacnbc_cmd(client, message):
    await _fetch_news(message, "https://berita-indo-api-next.vercel.app/api/cnbc-news", "CNBC ɪɴᴅᴏɴᴇꜱɪᴀ")
