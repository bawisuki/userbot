from PyroUbot import *

__MODULE__ = "ᴇᴍᴏᴊɪꜰʏ"
__HELP__ = """<blockquote><b>⎆ <code>{0}emojify</code></b></blockquote>"""


@PY.UBOT("emojify")
@PY.TOP_CMD
async def emojify(client, message):
    """ᴇᴍᴏᴊɪꜰʏ"""
    try:
        text = message.text.split(None, 1)[1]
        result = ""
        for c in text.lower():
            if c.isalpha():
                result += f":regional_indicator_{c}: "
            elif c == " ":
                result += "   "
            elif c.isdigit():
                nums = ["zero","one","two","three","four","five","six","seven","eight","nine"]
                result += f":{nums[int(c)]}: "
            else:
                result += c
        await message.edit(result[:4000], parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.emojify text</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
