from PyroUbot import *
import aiohttp

__MODULE__ = "ᴇxᴄᴜꜱᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}excuse</code></b></blockquote>"""


@PY.UBOT("excuse")
@PY.TOP_CMD
async def excuse(client, message):
    """ᴇxᴄᴜꜱᴇ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://excuser-three.vercel.app/v1/excuse") as r:
                d = await r.json()
        await message.edit(f"<b>🙈 Random Excuse</b>\n\n<i>{d[0]['excuse']}</i>\n\n<b>Category:</b> {d[0]['category']}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
