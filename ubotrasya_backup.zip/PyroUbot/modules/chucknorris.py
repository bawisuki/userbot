from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄʜᴜᴄᴋ"
__HELP__ = """<blockquote><b>⎆ <code>{0}chuck</code></b></blockquote>"""


@PY.UBOT("chuck")
@PY.TOP_CMD
async def chucknorris(client, message):
    """ᴄʜᴜᴄᴋ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api.chucknorris.io/jokes/random") as r:
                d = await r.json()
        await message.edit(f"<b>🤠 Chuck Norris Joke</b>\n\n{d['value']}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
