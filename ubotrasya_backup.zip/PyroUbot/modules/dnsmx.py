from PyroUbot import *
import aiohttp

__MODULE__ = "ᴅɴꜱ ᴍx"
__HELP__ = """<blockquote><b>⎆ <code>{0}dnsmx</code></b></blockquote>"""


@PY.UBOT("dnsmx")
@PY.TOP_CMD
async def dnsmx(client, message):
    """ᴅɴꜱ ᴍx"""
    try:
        domain = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://dns.google/resolve?name={domain}&type=MX") as r:
                d = await r.json()
        if "Answer" not in d:
            return await message.edit("<b>❌ No MX records.</b>", parse_mode=ParseMode.HTML)
        records = "\n".join([f"• <code>{a['data']}</code> (Priority: {a.get('data','').split()[0] if ' ' in a.get('data','') else 'N/A'})" for a in d["Answer"][:10]])
        await message.edit(f"<b>📧 MX Records: {domain}</b>\n\n{records}", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.dnsmx domain</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
