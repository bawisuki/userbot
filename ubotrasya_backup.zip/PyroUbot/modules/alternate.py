from PyroUbot import *

__MODULE__ = "alternate case"
__HELP__ = """<blockquote><b>⎆ <code>{0}alternate</code></b></blockquote>"""


@PY.UBOT("alternate")
@PY.TOP_CMD
async def alternate(client, message):
    """alternate case"""
    try:
        text = message.text.split(None, 1)[1]
        result = ''.join(c.upper() if i%2==0 else c.lower() for i,c in enumerate(text))
        await message.edit(f"<code>{result}</code>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Provide text.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
