from PyroUbot import *
import aiohttp

__MODULE__ = "ᴋᴜʀꜱ"
__HELP__ = """<blockquote><b>⎆ <code>{0}kurs</code></b></blockquote>"""


@PY.UBOT("kurs")
@PY.TOP_CMD
async def exchangemulti(client, message):
    """ᴋᴜʀꜱ"""
    try:
        base = message.text.split(None, 1)[1].upper() if len(message.text.split()) > 1 else "USD"
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://open.er-api.com/v6/latest/{base}") as r:
                d = await r.json()
        if d.get("result") != "success":
            return await message.edit("<b>❌ Mata uang tidak valid.</b>", parse_mode=ParseMode.HTML)
        targets = ["IDR","USD","EUR","GBP","JPY","SGD","MYR","AUD","CNY","KRW"]
        txt = f"<b>💱 Kurs {base}</b>\n\n"
        for t in targets:
            if t != base and t in d["rates"]:
                txt += f"<b>{t}:</b> {d['rates'][t]:,.2f}\n"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
