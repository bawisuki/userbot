from PyroUbot import *

__MODULE__ = "🌐 IPv6"
__HELP__ = """<blockquote><b>⎆ <code>{0}genipv6</code></b></blockquote>"""


@PY.UBOT("genipv6")
@PY.TOP_CMD
async def genipv6(client, message):
    """🌐 IPv6"""
    try:
        import random, string, uuid, hashlib, os, secrets, base64
        r = ':'.join(f'{__import__("random").randint(0,0xFFFF):04x}' for _ in range(8))
        await message.edit(f"<b>🌐 IPv6</b>\n\n<code>{str(r)}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
