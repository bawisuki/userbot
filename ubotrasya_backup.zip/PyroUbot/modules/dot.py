from PyroUbot import *
import aiohttp

__MODULE__ = "🟣 DOT"
__HELP__ = """<blockquote><b>⎆ <code>{0}dot</code></b></blockquote>"""


@PY.UBOT("dot")
@PY.TOP_CMD
async def dot(client, message):
    """🟣 DOT"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api.coingecko.com/api/v3/simple/price?ids=polkadot&vs_currencies=usd&include_24hr_change=true") as r:
                d = await r.json()
        price = d["polkadot"]["usd"]
        change = d["polkadot"].get("usd_24h_change", 0)
        emoji_c = "📈" if change >= 0 else "📉"
        await message.edit(f"<b>🟣 DOT</b>\n\n<b>💰 Price:</b> ${price}\n<b>{emoji_c} 24h:</b> {change:.2f}%", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
