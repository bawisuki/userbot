from PyroUbot import *
import aiohttp

__MODULE__ = "ʙʀᴇᴡᴇʀʏ"
__HELP__ = """<blockquote><b>⎆ <code>{0}brewery</code></b></blockquote>"""


@PY.UBOT("brewery")
@PY.TOP_CMD
async def brewery(client, message):
    """ʙʀᴇᴡᴇʀʏ"""
    try:
        city = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.openbrewerydb.org/v1/breweries?by_city={city}&per_page=5") as r:
                d = await r.json()
        if not d:
            return await message.edit("<b>❌ No breweries found.</b>", parse_mode=ParseMode.HTML)
        txt = f"<b>🍺 Breweries in {city}</b>\n\n"
        for b in d:
            txt += f"• <b>{b['name']}</b> ({b.get('brewery_type', 'N/A')})\n  📍 {b.get('city', '')}, {b.get('state', '')}\n"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.brewery city</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
