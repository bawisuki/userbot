from PyroUbot import *
import aiohttp

__MODULE__ = "ᴀʟǫᴜʀᴀɴ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴀʟǫᴜʀᴀɴ

⎆ <code>{0}alquran</code> [surah] [ayat]
   ᴍᴇɴᴀᴍᴘɪʟᴋᴀɴ ᴀʏᴀᴛ + ᴛᴇʀᴊᴇᴍᴀʜᴀɴ + ᴀᴜᴅɪᴏ</b></blockquote>
"""


@PY.UBOT("alquran")
@PY.TOP_CMD
async def alquran_cmd(client, message):
    args = message.command[1:]
    if len(args) < 2 or not args[0].isdigit() or not args[1].isdigit():
        return await message.reply("Format: <code>.alquran [surah] [ayat]</code>\nContoh: <code>.alquran 1 2</code>", quote=True)

    surah, ayat = int(args[0]), int(args[1])
    prs = await message.reply("<emoji id=5789858554890425372>🔄</emoji> <b>ᴍᴇᴍᴜᴀᴛ...</b>", quote=True)

    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://equran.id/api/v2/surat/{surah}/ayat/{ayat}") as r:
                if r.status != 200:
                    return await prs.edit("<emoji id=5210952531676504517>❌</emoji> Surah/ayat tidak ditemukan")
                data = await r.json(content_type=None)

        d = data.get("data", {})
        arab = d.get("tpieks", "") or d.get("arab", "")
        latin = d.get("latin", "")
        arti = d.get("arti", "")
        surah_name = data.get("surah", {}).get("namaLatin", f"Surah {surah}")
        audio_url = d.get("audio", {}).get("01", "") if isinstance(d.get("audio"), dict) else ""

        text = f"""<b>{surah_name} : {ayat}</b>

<blockquote>{arab}</blockquote>

<i>{latin}</i>

<b>Artinya:</b> {arti}"""

        await prs.edit(text)
        if audio_url:
            await client.send_audio(message.chat.id, audio_url, caption=f"{surah_name} ayat {ayat}", reply_to_message_id=message.id)
    except Exception as e:
        await prs.edit(f"<emoji id=5210952531676504517>❌</emoji> Error: {str(e)[:100]}")
