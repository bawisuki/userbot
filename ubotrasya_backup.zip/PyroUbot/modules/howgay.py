from PyroUbot import *
import random

__MODULE__ = "ʜᴏᴡ ɢᴀʏ"
__HELP__ = """<blockquote><b>⎆ <code>{0}howgay</code></b></blockquote>"""


@PY.UBOT("howgay")
@PY.TOP_CMD
async def howgay(client, message):
    """ʜᴏᴡ ɢᴀʏ"""
    try:
        target = message.reply_to_message.from_user.first_name if message.reply_to_message else "You"
        pct = random.randint(0, 100)
        await message.edit(f"<b>🏳️‍🌈 How Gay?</b>\n\n{target} is <b>{pct}%</b> gay!", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
