from PyroUbot import *
import aiohttp

__MODULE__ = "ɢʜ ɪꜱꜱᴜᴇꜱ"
__HELP__ = """<blockquote><b>⎆ <code>{0}ghissues</code></b></blockquote>"""


@PY.UBOT("ghissues")
@PY.TOP_CMD
async def github_issues(client, message):
    """ɢʜ ɪꜱꜱᴜᴇꜱ"""
    try:
        repo = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.github.com/repos/{repo}/issues?per_page=5&state=open") as r:
                d = await r.json()
        if isinstance(d, dict) and "message" in d:
            return await message.edit("<b>❌ Repo not found.</b>", parse_mode=ParseMode.HTML)
        txt = f"<b>🐛 Open Issues: {repo}</b>\n\n"
        for i in d[:5]:
            txt += f"• #{i['number']} {i['title'][:50]}\n"
        await message.edit(txt or "<b>No open issues.</b>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.ghissues user/repo</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
