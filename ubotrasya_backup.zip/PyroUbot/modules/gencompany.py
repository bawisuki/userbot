from PyroUbot import *
import random

__MODULE__ = "🏢 Company"
__HELP__ = """<blockquote><b>⎆ <code>{0}gencompany</code></b></blockquote>"""


@PY.UBOT("gencompany")
@PY.TOP_CMD
async def gencompany(client, message):
    """🏢 Company """
    try:
        result = f"{random.choice(['Tech','Digi','Cyber','Neo','Quantum','Cloud','Data','Smart'])} {random.choice(['Corp','Labs','Systems','Solutions','Works','Hub','Forge','Dynamics'])}"
        await message.edit(f"<b>🏢 Company Name</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
