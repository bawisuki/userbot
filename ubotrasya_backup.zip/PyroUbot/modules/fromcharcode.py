from PyroUbot import *

__MODULE__ = "ᴛᴏᴏʟ fromcode"
__HELP__ = """<blockquote><b>⎆ <code>{0}fromcode</code></b></blockquote>"""


@PY.UBOT("fromcode")
@PY.TOP_CMD
async def fromcharcode(client, message):
    """ᴛᴏᴏʟ"""
    try:
        codes = message.text.split(None, 1)[1].split()
        result = "".join([chr(int(c)) for c in codes])
        await message.edit(f"<b>🔤 From Codes</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, TypeError):
        await message.edit("<b>⚠️ Provide text or reply to a message.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
