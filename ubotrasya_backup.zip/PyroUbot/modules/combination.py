from PyroUbot import *

__MODULE__ = "combination"
__HELP__ = """<blockquote><b>⎆ <code>{0}comb</code></b></blockquote>"""


@PY.UBOT("comb")
@PY.TOP_CMD
async def combination(client, message):
    """combination"""
    try:
        import math
        args = message.text.split()
        n, r = int(args[1]), int(args[2])
        result = math.factorial(n) // (math.factorial(r) * math.factorial(n-r))
        await message.edit(f"<b>C({n},{r}) = {result}</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Provide valid numbers.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
