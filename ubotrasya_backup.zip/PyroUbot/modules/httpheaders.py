from PyroUbot import *
import aiohttp

__MODULE__ = "ꜱᴇᴄ ʜᴇᴀᴅᴇʀꜱ"
__HELP__ = """<blockquote><b>⎆ <code>{0}secheaders</code></b></blockquote>"""


@PY.UBOT("secheaders")
@PY.TOP_CMD
async def httpheaders(client, message):
    """ꜱᴇᴄ ʜᴇᴀᴅᴇʀꜱ"""
    try:
        url = message.text.split(None, 1)[1]
        if not url.startswith("http"):
            url = "https://" + url
        async with aiohttp.ClientSession() as s:
            async with s.get(url, timeout=aiohttp.ClientTimeout(total=10)) as r:
                headers = r.headers
        security = ["Strict-Transport-Security","Content-Security-Policy","X-Frame-Options","X-Content-Type-Options","X-XSS-Protection","Referrer-Policy"]
        txt = f"<b>🔒 Security Headers: {url}</b>\n\n"
        for h in security:
            val = headers.get(h, "❌ Missing")
            emoji = "✅" if val != "❌ Missing" else "❌"
            txt += f"{emoji} <b>{h}:</b> <code>{val[:50]}</code>\n"
        await message.edit(txt, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.secheaders url</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
