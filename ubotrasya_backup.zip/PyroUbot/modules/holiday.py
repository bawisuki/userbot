from PyroUbot import *
import aiohttp

__MODULE__ = "ʜᴏʟɪᴅᴀʏ"
__HELP__ = """<blockquote><b>⎆ <code>{0}holiday</code></b></blockquote>"""


@PY.UBOT("holiday")
@PY.TOP_CMD
async def holiday(client, message):
    """ʜᴏʟɪᴅᴀʏ"""
    try:
        args = message.text.split()
        if len(args) < 3:
            return await message.edit("<b>⚠️ Usage:</b> <code>.holiday country_code year</code>\nExample: <code>.holiday ID 2024</code>", parse_mode=ParseMode.HTML)
        cc, year = args[1].upper(), args[2]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://date.nager.at/api/v3/PublicHolidays/{year}/{cc}") as r:
                if r.status != 200:
                    return await message.edit("<b>❌ Invalid country/year.</b>", parse_mode=ParseMode.HTML)
                d = await r.json()
        txt = f"<b>📅 Holidays in {cc} ({year})</b>\n\n"
        for h in d[:10]:
            txt += f"• <b>{h['date']}</b> - {h['localName']}\n"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
