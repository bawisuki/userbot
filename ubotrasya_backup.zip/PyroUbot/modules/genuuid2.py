from PyroUbot import *

__MODULE__ = "🔑 UUID v"
__HELP__ = """<blockquote><b>⎆ <code>{0}genuuid2</code></b></blockquote>"""


@PY.UBOT("genuuid2")
@PY.TOP_CMD
async def genuuid2(client, message):
    """🔑 UUID v"""
    try:
        import random, string, uuid, hashlib, os, secrets, base64
        r = __import__('uuid').uuid4()
        await message.edit(f"<b>🔑 UUID v4</b>\n\n<code>{str(r)}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
