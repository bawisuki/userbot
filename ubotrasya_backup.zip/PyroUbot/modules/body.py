from PyroUbot import *
import random

__MODULE__ = "🫀 Body"
__HELP__ = """<blockquote><b>⎆ <code>{0}bodyfact</code></b></blockquote>"""


@PY.UBOT("bodyfact")
@PY.TOP_CMD
async def body(client, message):
    """🫀 Body"""
    try:
        items = ['Your nose can remember 50,000 different scents.', "The human brain uses 20% of the body's total energy.", 'Your body has enough iron to make a 3-inch nail.', 'Humans share 60% of their DNA with bananas.', 'The average person walks about 100,000 miles in a lifetime.']
        await message.edit(f"<b>🫀 Body</b>\n\n<i>{random.choice(items)}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
