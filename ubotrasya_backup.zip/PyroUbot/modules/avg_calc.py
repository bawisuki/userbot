from PyroUbot import *

__MODULE__ = "average"
__HELP__ = """<blockquote><b>⎆ <code>{0}avg</code></b></blockquote>"""


@PY.UBOT("avg")
@PY.TOP_CMD
async def avg_calc(client, message):
    """average"""
    try:
        nums = [float(x) for x in message.text.split(None, 1)[1].split(',')]
        await message.edit(f"<b>Average of {len(nums)} numbers = {sum(nums)/len(nums):.4f}</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Provide valid numbers.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
