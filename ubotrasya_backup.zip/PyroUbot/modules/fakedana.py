from PyroUbot import *
import aiohttp
import os

__MODULE__ = "ꜰᴀᴋᴇ ᴅᴀɴᴀ"
__HELP__ = """<blockquote><b>⎆ <code>{0}fakedana</code></b></blockquote>"""


@PY.UBOT("fakedana")
@PY.TOP_CMD
async def fakedana(client, message):
    """ꜰᴀᴋᴇ ᴅᴀɴᴀ"""
    try:
        args = message.text.split(None, 1)
        nominal = args[1].strip() if len(args) > 1 else "50000"
        await message.edit("<b>⏳ Generating Fake Dana...</b>", parse_mode=ParseMode.HTML)
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api-nanzz.my.id/docs/api/maker/fake-dana.php?nominal={nominal}") as r:
                if r.status == 200 and "image" in r.headers.get("Content-Type", ""):
                    img = await r.read()
                    path = "/tmp/fakedana.png"
                    with open(path, "wb") as f:
                        f.write(img)
                    await message.reply_photo(path, caption=f"<b>💙 Fake Dana</b>\n<b>Nominal:</b> Rp{nominal}")
                    await message.delete()
                    os.remove(path)
                else:
                    await message.edit("<b>❌ Gagal generate Fake Dana.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
