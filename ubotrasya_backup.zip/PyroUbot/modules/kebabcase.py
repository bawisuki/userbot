from PyroUbot import *
import aiohttp

__MODULE__ = "ᴋᴇʙᴀʙ"
__HELP__ = """<blockquote><b>⎆ <code>{0}kebab</code></b></blockquote>"""


@PY.UBOT("kebab")
@PY.TOP_CMD
async def kebabcase(client, message):
    """ᴋᴇʙᴀʙ"""
    try:
        text = message.text.split(None, 1)[1]
        result = "-".join(text.lower().split())
        await message.edit(f"<b>🍢 kebab-case</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.kebab hello world</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
