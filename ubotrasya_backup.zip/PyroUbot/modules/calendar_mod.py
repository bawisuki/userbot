from PyroUbot import *
import calendar

__MODULE__ = "ᴄᴀʟᴇɴᴅᴀʀ"
__HELP__ = """<blockquote><b>⎆ <code>{0}cal</code></b></blockquote>"""


@PY.UBOT("cal")
@PY.TOP_CMD
async def calendar_mod(client, message):
    """ᴄᴀʟᴇɴᴅᴀʀ"""
    try:
        args = message.text.split()
        from datetime import datetime
        year = int(args[1]) if len(args) > 1 else datetime.now().year
        month = int(args[2]) if len(args) > 2 else datetime.now().month
        cal = calendar.month(year, month)
        await message.edit(f"<code>{cal}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
