from PyroUbot import *
import aiohttp

__MODULE__ = "ᴅᴇꜰɪɴᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}define</code></b></blockquote>"""


@PY.UBOT("define")
@PY.TOP_CMD
async def define(client, message):
    """ᴅᴇꜰɪɴᴇ"""
    try:
        word = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.dictionaryapi.dev/api/v2/entries/en/{word}") as r:
                if r.status != 200:
                    return await message.edit("<b>❌ Word not found.</b>", parse_mode=ParseMode.HTML)
                d = await r.json()
        entry = d[0]
        meanings = ""
        for m in entry["meanings"][:3]:
            defi = m["definitions"][0]["definition"]
            meanings += f"\n<b>({m['partOfSpeech']})</b> {defi}"
        phonetic = entry.get("phonetic", "")
        await message.edit(f"<b>📖 {entry['word']}</b> {phonetic}\n{meanings}", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.define word</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
