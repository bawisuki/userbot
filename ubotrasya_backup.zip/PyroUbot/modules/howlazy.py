from PyroUbot import *
import random

__MODULE__ = "ʜᴏᴡ ʟᴀᴢʏ"
__HELP__ = """<blockquote><b>⎆ <code>{0}howlazy</code></b></blockquote>"""


@PY.UBOT("howlazy")
@PY.TOP_CMD
async def howlazy(client, message):
    """ʜᴏᴡ ʟᴀᴢʏ"""
    try:
        target = message.reply_to_message.from_user.first_name if message.reply_to_message else "You"
        pct = random.randint(0, 100)
        await message.edit(f"<b>😴 How Lazy?</b>\n\n{target} is <b>{pct}%</b> lazy!", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
