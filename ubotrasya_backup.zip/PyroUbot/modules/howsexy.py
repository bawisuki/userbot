from PyroUbot import *
import random

__MODULE__ = "ʜᴏᴡ ꜱᴇxʏ"
__HELP__ = """<blockquote><b>⎆ <code>{0}howsexy</code></b></blockquote>"""


@PY.UBOT("howsexy")
@PY.TOP_CMD
async def howsexy(client, message):
    """ʜᴏᴡ ꜱᴇxʏ"""
    try:
        target = message.reply_to_message.from_user.first_name if message.reply_to_message else "You"
        pct = random.randint(0, 100)
        await message.edit(f"<b>🔥 How Sexy?</b>\n\n{target} is <b>{pct}%</b> sexy!", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
