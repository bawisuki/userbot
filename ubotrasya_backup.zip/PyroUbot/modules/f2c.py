from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ f2c"
__HELP__ = """<blockquote><b>⎆ <code>{0}f2c</code></b></blockquote>"""


@PY.UBOT("f2c")
@PY.TOP_CMD
async def f2c(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val(v-32)*5/9
        await message.edit(f"<b>📐 {val} °F = {result:.6g} °C</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.f2c value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
