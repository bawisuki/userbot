from PyroUbot import *

__MODULE__ = "ᴄʜᴍᴏᴅ"
__HELP__ = """<blockquote><b>⎆ <code>{0}chmod</code></b></blockquote>"""


@PY.UBOT("chmod")
@PY.TOP_CMD
async def chmod(client, message):
    """ᴄʜᴍᴏᴅ"""
    try:
        val = message.text.split(None, 1)[1]
        perms = {"7":"rwx","6":"rw-","5":"r-x","4":"r--","3":"-wx","2":"-w-","1":"--x","0":"---"}
        if val.isdigit() and len(val) == 3:
            symbolic = "".join(perms.get(c,"???") for c in val)
            await message.edit(f"<b>📁 chmod {val}</b>\n\n<code>{symbolic}</code>\n\nOwner: {perms.get(val[0])}\nGroup: {perms.get(val[1])}\nOther: {perms.get(val[2])}", parse_mode=ParseMode.HTML)
        else:
            await message.edit("<b>⚠️ Usage:</b> <code>.chmod 755</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.chmod 755</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
