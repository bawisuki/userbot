from PyroUbot import *
import random

__MODULE__ = "🐾 Animal"
__HELP__ = """<blockquote><b>⎆ <code>{0}animalfact</code></b></blockquote>"""


@PY.UBOT("animalfact")
@PY.TOP_CMD
async def animal(client, message):
    """🐾 Animal"""
    try:
        items = ["A group of flamingos is called a 'flamboyance'.", 'Cows have best friends and get stressed when separated.', 'Octopuses have three hearts and blue blood.', 'A snail can sleep for three years.', "Elephants are the only animals that can't jump."]
        await message.edit(f"<b>🐾 Animal</b>\n\n<i>{random.choice(items)}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
