from PyroUbot import *
import aiohttp

__MODULE__ = "ɴᴇᴛᴡᴏʀᴋ ᴛᴏᴏʟꜱ"
__HELP__ = """
<blockquote><b>⎆ <code>{0}dns</code> [domain] ᴅɴꜱ ʟᴏᴏᴋᴜᴘ
⎆ <code>{0}dnsmx</code> [domain] ᴍx ʀᴇᴄᴏʀᴅ
⎆ <code>{0}dnstxt</code> [domain] ᴛxᴛ ʀᴇᴄᴏʀᴅ
⎆ <code>{0}sslcheck</code> [domain] ᴄᴇᴋ ꜱꜱʟ
⎆ <code>{0}port</code> [ip] [port] ᴄᴇᴋ ᴘᴏʀᴛ
⎆ <code>{0}headers</code> [url] ʜᴇᴀᴅᴇʀꜱ
⎆ <code>{0}httpstat</code> [url] ꜱᴛᴀᴛᴜꜱ
⎆ <code>{0}ipgeo</code> [ip] ɢᴇᴏʟᴏᴄᴀᴛɪᴏɴ
⎆ <code>{0}whoisip</code> [ip] ᴡʜᴏɪꜱ
⎆ <code>{0}speed2</code> ꜱᴘᴇᴇᴅ ᴛᴇꜱᴛ</b></blockquote>
"""



@PY.UBOT("dns")
@PY.TOP_CMD
async def dnscheck(client, message):
    """ᴅɴꜱ"""
    try:
        domain = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://dns.google/resolve?name={domain}&type=A") as r:
                d = await r.json()
        if "Answer" not in d:
            return await message.edit("<b>❌ No DNS records found.</b>", parse_mode=ParseMode.HTML)
        records = "\n".join([f"<code>{a['data']}</code> (TTL: {a['TTL']})" for a in d["Answer"]])
        txt = f"<b>🌐 DNS Records for {domain}</b>\n\n{records}"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.dns domain</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
