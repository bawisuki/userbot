from PyroUbot import *
import aiohttp

__MODULE__ = "ɢᴏʟᴅ"
__HELP__ = """<blockquote><b>⎆ <code>{0}gold</code></b></blockquote>"""


@PY.UBOT("gold")
@PY.TOP_CMD
async def gold(client, message):
    """ɢᴏʟᴅ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api.metalpriceapi.com/v1/latest?api_key=demo&base=USD&currencies=XAU") as r:
                d = await r.json()
        if d.get("success"):
            price = 1 / d["rates"]["XAU"]
            await message.edit(f"<b>🥇 Gold Price</b>\n\n<b>💰 1 oz:</b> ${price:,.2f} USD", parse_mode=ParseMode.HTML)
        else:
            await message.edit("<b>❌ Failed to get gold price.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
