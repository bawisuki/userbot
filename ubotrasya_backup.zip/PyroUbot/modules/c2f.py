from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ c2f"
__HELP__ = """<blockquote><b>⎆ <code>{0}c2f</code></b></blockquote>"""


@PY.UBOT("c2f")
@PY.TOP_CMD
async def c2f(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val9/5+32
        await message.edit(f"<b>📐 {val} °C = {result:.6g} °F</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.c2f value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
