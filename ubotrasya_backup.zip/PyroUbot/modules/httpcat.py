from PyroUbot import *
import aiohttp
import os

__MODULE__ = "ʜᴛᴛᴘ ᴄᴀᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}httpcat</code></b></blockquote>"""


@PY.UBOT("httpcat")
@PY.TOP_CMD
async def httpcat(client, message):
    """ʜᴛᴛᴘ ᴄᴀᴛ"""
    try:
        code = message.text.split(None, 1)[1]
        url = f"https://http.cat/{code}"
        async with aiohttp.ClientSession() as s:
            async with s.get(url) as r:
                if r.status == 200:
                    img = await r.read()
                    path = "/tmp/httpcat.jpg"
                    with open(path, "wb") as f:
                        f.write(img)
                    await message.reply_photo(path, caption=f"<b>🐱 HTTP {code}</b>", parse_mode=ParseMode.HTML)
                    await message.delete()
                    os.remove(path)
                else:
                    await message.edit(f"<b>❌ No cat for {code}</b>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.httpcat 404</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
