from PyroUbot import *

__MODULE__ = "distance"
__HELP__ = """<blockquote><b>⎆ <code>{0}distance</code></b></blockquote>"""


@PY.UBOT("distance")
@PY.TOP_CMD
async def distance_calc(client, message):
    """distance"""
    try:
        import math
        args = message.text.split()
        x1,y1,x2,y2 = float(args[1]),float(args[2]),float(args[3]),float(args[4])
        dist = math.sqrt((x2-x1)**2 + (y2-y1)**2)
        await message.edit(f"<b>📏 Distance = {dist:.4f}</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Provide valid numbers.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
