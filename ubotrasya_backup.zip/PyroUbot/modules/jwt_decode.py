from PyroUbot import *
import base64, json

__MODULE__ = "ᴊᴡᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}jwtdecode</code></b></blockquote>"""


@PY.UBOT("jwtdecode")
@PY.TOP_CMD
async def jwt_decode(client, message):
    """ᴊᴡᴛ"""
    try:
        token = message.text.split(None, 1)[1]
        parts = token.split(".")
        if len(parts) != 3:
            return await message.edit("<b>❌ Invalid JWT format.</b>", parse_mode=ParseMode.HTML)
        header = json.loads(base64.urlsafe_b64decode(parts[0] + "=="))
        payload = json.loads(base64.urlsafe_b64decode(parts[1] + "=="))
        txt = f"<b>🔑 JWT Decoded</b>\n\n<b>Header:</b>\n<code>{json.dumps(header, indent=2)}</code>\n\n<b>Payload:</b>\n<code>{json.dumps(payload, indent=2)[:2000]}</code>"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.jwtdecode token</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
