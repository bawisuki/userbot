from PyroUbot import *
import aiohttp

__MODULE__ = "🦊 Fox Fact"
__HELP__ = """<blockquote><b>⎆ <code>{0}foxfact</code></b></blockquote>"""


@PY.UBOT("foxfact")
@PY.TOP_CMD
async def foxfact(client, message):
    """🦊 Fox Fact"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://some-random-api.com/animal/fox") as r:
                d = await r.json()
        result = d.get('fact','No fact')
        await message.edit(f"<b>🦊 Fox Fact</b>\n\n{result}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
