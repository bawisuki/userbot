from PyroUbot import *
import aiohttp

__MODULE__ = "ᴅᴇʜᴇx"
__HELP__ = """<blockquote><b>⎆ <code>{0}dehex</code></b></blockquote>"""


@PY.UBOT("dehex")
@PY.TOP_CMD
async def dehex(client, message):
    """ᴅᴇʜᴇx"""
    try:
        hex_str = message.text.split(None, 1)[1].replace(" ", "")
        result = bytes.fromhex(hex_str).decode()
        await message.edit(f"<b>🔢 Hex to Text</b>\n\n<code>{result[:3000]}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.dehex 48656c6c6f</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
