from PyroUbot import *
import aiohttp

__MODULE__ = "ꜰᴏᴏᴛʙᴀʟʟ"
__HELP__ = """<blockquote><b>⎆ <code>{0}football</code></b></blockquote>"""


@PY.UBOT("football")
@PY.TOP_CMD
async def apifootball(client, message):
    """ꜰᴏᴏᴛʙᴀʟʟ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://www.scorebat.com/video-api/v3/feed/?token=MTk1MDhfMTcwMTM1MjgwMF9kNjI3") as r:
                d = await r.json()
        txt = "<b>⚽ Recent Football Highlights</b>\n\n"
        for m in d.get("response", [])[:5]:
            txt += f"• <b>{m['title']}</b>\n"
        await message.edit(txt or "<b>No data</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
