from PyroUbot import *
import aiohttp
from urllib.parse import quote

__MODULE__ = "ᴄᴇᴋ ʀᴇᴋ"
__HELP__ = """<blockquote><b>⎆ <code>{0}cekrek</code></b></blockquote>"""


@PY.UBOT("cekrek")
@PY.TOP_CMD
async def cekrekening(client, message):
    """ᴄᴇᴋ ʀᴇᴋ"""
    try:
        args = message.text.split(None, 2)
        if len(args) < 3:
            return await message.edit("<b>⚠️ Usage:</b> <code>.cekrek bank nomor</code>\n<b>Contoh:</b> <code>.cekrek bca 1234567890</code>", parse_mode=ParseMode.HTML)
        bank, nomor = args[1].upper(), args[2]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://cekrekening.id/api/rekening/{bank}/{nomor}") as r:
                if r.status == 200:
                    d = await r.json()
                    nama = d.get("data", {}).get("nama", "Unknown")
                    await message.edit(f"<b>🏦 Cek Rekening</b>\n\n<b>Bank:</b> {bank}\n<b>No:</b> {nomor}\n<b>Nama:</b> {nama}", parse_mode=ParseMode.HTML)
                else:
                    await message.edit(f"<b>🏦 Cek Rekening</b>\n\n<b>Bank:</b> {bank}\n<b>No:</b> {nomor}\n<b>Status:</b> Tidak dapat diverifikasi", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
