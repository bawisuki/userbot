import os
from PIL import Image
from PyroUbot import *

__MODULE__ = "ᴄʀᴏᴘ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴄʀᴏᴘ

⎆ <code>{0}crop</code> ʀᴇᴘʟʏ ꜰᴏᴛᴏ ᴄʀᴏᴘ ᴊᴀᴅɪ ꜱQᴜᴀʀᴇ (ᴄᴇɴᴛᴇʀ ᴄʀᴏᴘ)</b></blockquote>
"""


@PY.UBOT("crop")
@PY.TOP_CMD
async def crop_cmd(client, message):
    try:
        reply = message.reply_to_message
        if not reply or not reply.photo:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ʀᴇᴘʟʏ ᴋᴇ ꜰᴏᴛᴏ!</b>", parse_mode=ParseMode.HTML)
        await message.edit("<emoji id=5206607081334906820>✅</emoji> <b>ᴍᴇᴍᴘʀᴏꜱᴇꜱ...</b>", parse_mode=ParseMode.HTML)
        path = await client.download_media(reply, file_name="./downloads/")
        img = Image.open(path)
        w, h = img.size
        size = min(w, h)
        left = (w - size) // 2
        top = (h - size) // 2
        img = img.crop((left, top, left + size, top + size))
        out = "./downloads/cropped.png"
        img.save(out, "PNG")
        await client.send_photo(message.chat.id, out, reply_to_message_id=message.id)
        await message.delete()
        os.remove(path)
        os.remove(out)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)
