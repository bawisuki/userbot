from PyroUbot import *
import aiohttp

__MODULE__ = "ɪᴘ ᴡʜᴏɪꜱ"
__HELP__ = """<blockquote><b>⎆ <code>{0}ipwhois</code></b></blockquote>"""


@PY.UBOT("ipwhois")
@PY.TOP_CMD
async def ipwhois(client, message):
    """ɪᴘ ᴡʜᴏɪꜱ"""
    try:
        ip = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://ipwhois.app/json/{ip}") as r:
                d = await r.json()
        txt = (
            f"<b>🌐 IP Whois: {ip}</b>\n\n"
            f"<b>🏳️ Country:</b> {d.get('country', 'N/A')}\n"
            f"<b>🏙 City:</b> {d.get('city', 'N/A')}\n"
            f"<b>🌐 ISP:</b> {d.get('isp', 'N/A')}\n"
            f"<b>🏢 Org:</b> {d.get('org', 'N/A')}\n"
            f"<b>⏰ Timezone:</b> {d.get('timezone', 'N/A')}"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.ipwhois ip</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
