from PyroUbot import *
import math

__MODULE__ = "ᴄɪʀᴄʟᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}circle</code></b></blockquote>"""


@PY.UBOT("circle")
@PY.TOP_CMD
async def area_circle(client, message):
    """ᴄɪʀᴄʟᴇ"""
    try:
        r = float(message.text.split(None, 1)[1])
        area = math.pi * r ** 2
        circumference = 2 * math.pi * r
        await message.edit(f"<b>⭕ Circle (r={r})</b>\n\n<b>Area:</b> {area:.4f}\n<b>Circumference:</b> {circumference:.4f}", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.circle radius</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
