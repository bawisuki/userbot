from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ j2btu"
__HELP__ = """<blockquote><b>⎆ <code>{0}j2btu</code></b></blockquote>"""


@PY.UBOT("j2btu")
@PY.TOP_CMD
async def j2btu(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val/1055.06
        await message.edit(f"<b>📐 {val} joules = {result:.6g} BTU</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.j2btu value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
