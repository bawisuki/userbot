from PyroUbot import *
import aiohttp

__MODULE__ = "ʙᴏʀᴇᴅ 3"
__HELP__ = """<blockquote><b>⎆ <code>{0}bored3</code></b></blockquote>"""


@PY.UBOT("bored3")
@PY.TOP_CMD
async def bored3(client, message):
    """ʙᴏʀᴇᴅ 3"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://bored-api.appbrewery.com/random?type=social") as r:
                d = await r.json()
        await message.edit(f"<b>👥 Social Activity</b>\n\n{d['activity']}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
