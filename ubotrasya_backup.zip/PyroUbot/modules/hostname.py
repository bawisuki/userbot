from PyroUbot import *
import socket

__MODULE__ = "ʜᴏꜱᴛɴᴀᴍᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}hostname</code></b></blockquote>"""


@PY.UBOT("hostname")
@PY.TOP_CMD
async def hostname(client, message):
    """ʜᴏꜱᴛɴᴀᴍᴇ"""
    try:
        h = socket.gethostname()
        ip = socket.gethostbyname(h)
        await message.edit(f"<b>🖥 Hostname</b>\n\n<b>Name:</b> <code>{h}</code>\n<b>IP:</b> <code>{ip}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
