from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ kb2mb"
__HELP__ = """<blockquote><b>⎆ <code>{0}kb2mb</code></b></blockquote>"""


@PY.UBOT("kb2mb")
@PY.TOP_CMD
async def kb2mb(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val * 0.001
        await message.edit(f"<b>📐 {val} KB = {result:.4f} MB</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.kb2mb value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
