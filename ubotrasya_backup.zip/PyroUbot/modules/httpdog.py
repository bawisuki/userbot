from PyroUbot import *
import aiohttp
import os

__MODULE__ = "ʜᴛᴛᴘ ᴅᴏɢ"
__HELP__ = """<blockquote><b>⎆ <code>{0}httpdog</code></b></blockquote>"""


@PY.UBOT("httpdog")
@PY.TOP_CMD
async def httpdog(client, message):
    """ʜᴛᴛᴘ ᴅᴏɢ"""
    try:
        code = message.text.split(None, 1)[1]
        url = f"https://http.dog/{code}.jpg"
        async with aiohttp.ClientSession() as s:
            async with s.get(url) as r:
                if r.status == 200:
                    img = await r.read()
                    path = "/tmp/httpdog.jpg"
                    with open(path, "wb") as f:
                        f.write(img)
                    await message.reply_photo(path, caption=f"<b>🐕 HTTP {code}</b>", parse_mode=ParseMode.HTML)
                    await message.delete()
                    os.remove(path)
                else:
                    await message.edit(f"<b>❌ No dog for {code}</b>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.httpdog 404</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
