from PyroUbot import *

__MODULE__ = "🔑 Passph"
__HELP__ = """<blockquote><b>⎆ <code>{0}passphrase</code></b></blockquote>"""


@PY.UBOT("passphrase")
@PY.TOP_CMD
async def genpassphrase(client, message):
    """🔑 Passph"""
    try:
        import random, string, uuid, hashlib, os, secrets, base64
        r = ' '.join(__import__('random').choices(['correct','horse','battery','staple','purple','monkey','dishwasher','elephant','rainbow','thunder','crystal','shadow','phoenix','dragon','wizard','cosmic','stellar','nebula','quantum','cipher'], k=4))
        await message.edit(f"<b>🔑 Passphrase</b>\n\n<code>{str(r)}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
