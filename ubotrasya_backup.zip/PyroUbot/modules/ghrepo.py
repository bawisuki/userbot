from PyroUbot import *
import aiohttp

__MODULE__ = "ɢɪᴛʜᴜʙ"
__HELP__ = """
<blockquote><b>⎆ <code>{0}ghrepo</code> [user/repo] ɪɴꜰᴏ ʀᴇᴘᴏ
⎆ <code>{0}ghuser</code> [user] ᴘʀᴏꜰɪʟ ᴜꜱᴇʀ
⎆ <code>{0}github_trending</code> ᴛᴏᴘ ʀᴇᴘᴏ
⎆ <code>{0}github_search</code> [q] ᴄᴀʀɪ ʀᴇᴘᴏ
⎆ <code>{0}github_lang</code> [user/repo] ʟᴀɴɢᴜᴀɢᴇ
⎆ <code>{0}ghcommits</code> [user/repo] ᴄᴏᴍᴍɪᴛꜱ
⎆ <code>{0}ghissues</code> [user/repo] ɪꜱꜱᴜᴇꜱ
⎆ <code>{0}ghrelease</code> [user/repo] ʀᴇʟᴇᴀꜱᴇ
⎆ <code>{0}ghreadme</code> [user/repo] ʀᴇᴀᴅᴍᴇ</b></blockquote>
"""



@PY.UBOT("ghrepo")
@PY.TOP_CMD
async def ghrepo(client, message):
    """ɢɪᴛʜᴜʙ"""
    try:
        repo = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.github.com/repos/{repo}") as r:
                d = await r.json()
        if "message" in d and d["message"] == "Not Found":
            return await message.edit("<b>❌ Repository not found.</b>", parse_mode=ParseMode.HTML)
        txt = (
            f"<b>📦 {d['full_name']}</b>\n"
            f"<b>⭐ Stars:</b> {d['stargazers_count']}\n"
            f"<b>🍴 Forks:</b> {d['forks_count']}\n"
            f"<b>👁 Watchers:</b> {d['watchers_count']}\n"
            f"<b>🌐 Language:</b> {d.get('language', 'N/A')}\n"
            f"<b>📝 Description:</b> {d.get('description', 'N/A')}\n"
            f"<b>🔗 URL:</b> {d['html_url']}"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.ghrepo user/repo</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
