from PyroUbot import *
import aiohttp

__MODULE__ = "ᴅɪꜱᴋ"
__HELP__ = """<blockquote><b>⎆ <code>{0}disk</code></b></blockquote>"""


@PY.UBOT("disk")
@PY.TOP_CMD
async def disk(client, message):
    """ᴅɪꜱᴋ"""
    try:
        import shutil
        total, used, free = shutil.disk_usage("/")
        txt = (
            f"<b>💾 Disk Usage</b>\n\n"
            f"<b>Total:</b> {total // (1024**3)} GB\n"
            f"<b>Used:</b> {used // (1024**3)} GB ({used*100//total}%)\n"
            f"<b>Free:</b> {free // (1024**3)} GB"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
