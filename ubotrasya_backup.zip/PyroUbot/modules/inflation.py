from PyroUbot import *

__MODULE__ = "inflation"
__HELP__ = """<blockquote><b>⎆ <code>{0}inflation</code></b></blockquote>"""


@PY.UBOT("inflation")
@PY.TOP_CMD
async def inflation(client, message):
    """inflation"""
    try:
        args = message.text.split()
        amount = float(args[1])
        rate = float(args[2])
        years = int(args[3])
        future = amount * (1 + rate/100) ** years
        await message.edit(f"<b>📈 Inflation Calculator</b>\n\n<b>Today:</b> {amount:,.2f}\n<b>Rate:</b> {rate}%/yr\n<b>After {years}yr:</b> {future:,.2f}", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Provide valid numbers.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
