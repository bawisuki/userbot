from PyroUbot import *

__MODULE__ = "ᴄᴍ ᴛᴏ ɪɴ"
__HELP__ = """<blockquote><b>⎆ <code>{0}cm2in</code></b></blockquote>"""


@PY.UBOT("cm2in")
@PY.TOP_CMD
async def cm2inch(client, message):
    """ᴄᴍ ᴛᴏ ɪɴ"""
    try:
        val = float(message.text.split(None, 1)[1])
        await message.edit(f"<b>📏 {val} cm = {val / 2.54:.2f} inches</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.cm2in 100</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
