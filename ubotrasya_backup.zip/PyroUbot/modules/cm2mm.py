from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ cm2mm"
__HELP__ = """<blockquote><b>⎆ <code>{0}cm2mm</code></b></blockquote>"""


@PY.UBOT("cm2mm")
@PY.TOP_CMD
async def cm2mm(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val*10
        await message.edit(f"<b>📐 {val} cm = {result:.6g} mm</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.cm2mm value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
