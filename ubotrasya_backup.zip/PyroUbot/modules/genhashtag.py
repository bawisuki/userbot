from PyroUbot import *
import random

__MODULE__ = "# Hashtag"
__HELP__ = """<blockquote><b>⎆ <code>{0}genhashtag</code></b></blockquote>"""


@PY.UBOT("genhashtag")
@PY.TOP_CMD
async def genhashtag(client, message):
    """# Hashtag"""
    try:
        result = f"#{random.choice(['coding','developer','tech','programming','webdev','devlife','100daysofcode','opensource','javascript','python'])}"
        await message.edit(f"<b># Hashtag</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
