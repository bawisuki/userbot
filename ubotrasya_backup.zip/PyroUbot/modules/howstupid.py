from PyroUbot import *
import random

__MODULE__ = "ʜᴏᴡ ꜱᴛᴜᴘɪᴅ"
__HELP__ = """<blockquote><b>⎆ <code>{0}howstupid</code></b></blockquote>"""


@PY.UBOT("howstupid")
@PY.TOP_CMD
async def howstupid(client, message):
    """ʜᴏᴡ ꜱᴛᴜᴘɪᴅ"""
    try:
        target = message.reply_to_message.from_user.first_name if message.reply_to_message else "You"
        pct = random.randint(0, 100)
        await message.edit(f"<b>🤡 How Stupid?</b>\n\n{target} is <b>{pct}%</b> stupid!", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
