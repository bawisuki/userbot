from PyroUbot import *

__MODULE__ = "ᴇɴᴇʀɢʏ"
__HELP__ = """<blockquote><b>⎆ <code>{0}energy</code></b></blockquote>"""


@PY.UBOT("energy")
@PY.TOP_CMD
async def energyconv(client, message):
    """ᴇɴᴇʀɢʏ"""
    try:
        args = message.text.split()
        watts = float(args[1])
        hours = float(args[2]) if len(args) > 2 else 24
        kwh = watts * hours / 1000
        cost_idr = kwh * 1500
        await message.edit(f"<b>⚡ Energy Calculator</b>\n\n<b>Power:</b> {watts}W\n<b>Duration:</b> {hours}h\n<b>Energy:</b> {kwh:.2f} kWh\n<b>Est. Cost (IDR):</b> Rp{cost_idr:,.0f}/day", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.energy watts [hours]</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
