from PyroUbot import *

__MODULE__ = "ɪᴅ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ɪᴅ

⎆ <code>{0}id</code>
   ᴛᴀᴍᴘɪʟᴋᴀɴ ɪᴅ ᴄʜᴀᴛ/ᴜꜱᴇʀ/ʀᴇᴘʟʏ</b></blockquote>
"""


@PY.UBOT("id")
@PY.TOP_CMD
async def getid(client, message):
    try:
        text = f"<emoji id=5206607081334906820>✅</emoji> <b>ɪɴꜰᴏ ɪᴅ</b>\n\n"
        text += f"<b>⎆ ᴄʜᴀᴛ ɪᴅ:</b> <code>{message.chat.id}</code>\n"
        text += f"<b>⎆ ᴍʏ ɪᴅ:</b> <code>{message.from_user.id}</code>\n"
        if message.reply_to_message:
            reply = message.reply_to_message
            text += f"<b>⎆ ʀᴇᴘʟʏ ᴜꜱᴇʀ ɪᴅ:</b> <code>{reply.from_user.id}</code>\n"
            if reply.forward_from:
                text += f"<b>⎆ ꜰᴏʀᴡᴀʀᴅ ꜰʀᴏᴍ ɪᴅ:</b> <code>{reply.forward_from.id}</code>\n"
        await message.edit(text, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)
