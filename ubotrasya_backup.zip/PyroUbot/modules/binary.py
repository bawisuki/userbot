from PyroUbot import *
import aiohttp

__MODULE__ = "ʙɪɴᴀʀʏ"
__HELP__ = """<blockquote><b>⎆ <code>{0}binary</code></b></blockquote>"""


@PY.UBOT("binary")
@PY.TOP_CMD
async def binary(client, message):
    """ʙɪɴᴀʀʏ"""
    try:
        text = message.text.split(None, 1)[1]
        result = " ".join(format(ord(c), '08b') for c in text)
        await message.edit(f"<b>💻 Binary</b>\n\n<code>{result[:3000]}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.binary text</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
