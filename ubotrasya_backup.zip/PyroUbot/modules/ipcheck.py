from PyroUbot import *
import aiohttp

__MODULE__ = "ɪᴘ ᴄʜᴇᴄᴋ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ɪᴘ ᴄʜᴇᴄᴋ

⎆ <code>{0}myip</code> ᴛᴀᴍᴘɪʟᴋᴀɴ ᴘᴜʙʟɪᴄ ɪᴘ ꜱᴇʀᴠᴇʀ</b></blockquote>
"""


@PY.UBOT("myip")
@PY.TOP_CMD
async def myip_cmd(client, message):
    try:
        await message.edit("<emoji id=5789858554890425372>🔄</emoji> <b>ᴄʜᴇᴄᴋɪɴɢ...</b>", parse_mode=ParseMode.HTML)
        async with aiohttp.ClientSession() as session:
            async with session.get("https://api.ipify.org?format=json") as resp:
                data = await resp.json()
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ᴘᴜʙʟɪᴄ ɪᴘ:</b>\n<code>{data['ip']}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
