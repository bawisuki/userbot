from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ cal2j"
__HELP__ = """<blockquote><b>⎆ <code>{0}cal2j</code></b></blockquote>"""


@PY.UBOT("cal2j")
@PY.TOP_CMD
async def cal2j(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val * 4.184
        await message.edit(f"<b>📐 {val} calories = {result:.4f} joules</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.cal2j value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
