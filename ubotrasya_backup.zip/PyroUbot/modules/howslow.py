from PyroUbot import *
import random

__MODULE__ = "🐌"
__HELP__ = """<blockquote><b>⎆ <code>{0}howslow</code></b></blockquote>"""


@PY.UBOT("howslow")
@PY.TOP_CMD
async def howslow(client, message):
    """🐌"""
    try:
        target = message.reply_to_message.from_user.first_name if message.reply_to_message else "You"
        pct = random.randint(0, 100)
        await message.edit(f"<b>🐌 How Slow?</b>\n\n{target} is <b>{pct}%</b> slow!", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
