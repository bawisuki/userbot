from PyroUbot import *

__MODULE__ = "ʙɪᴏ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ʙɪᴏ

⎆ <code>{0}setbio</code> [text]
   ꜱᴇᴛ ʙɪᴏ ᴛᴇʟᴇɢʀᴀᴍ

⎆ <code>{0}getbio</code>
   ʟɪʜᴀᴛ ʙɪᴏ ꜱᴀᴀᴛ ɪɴɪ</b></blockquote>
"""


@PY.UBOT("setbio")
@PY.TOP_CMD
async def setbio(client, message):
    try:
        text = message.text.split(None, 1)
        if len(text) < 2:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.setbio [text]</code>", parse_mode=ParseMode.HTML)
        bio = text[1]
        await client.update_profile(bio=bio)
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ʙɪᴏ ʙᴇʀʜᴀꜱɪʟ ᴅɪᴜʙᴀʜ ᴋᴇ:</b>\n<code>{bio}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("getbio")
@PY.TOP_CMD
async def getbio(client, message):
    try:
        me = await client.get_chat("me")
        bio = me.bio or "ᴛɪᴅᴀᴋ ᴀᴅᴀ ʙɪᴏ"
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ʙɪᴏ ꜱᴀᴀᴛ ɪɴɪ:</b>\n<code>{bio}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)
