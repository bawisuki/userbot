from PyroUbot import *

__MODULE__ = "ʜᴇx ᴛᴏ ᴅᴇᴄ"
__HELP__ = """<blockquote><b>⎆ <code>{0}hex2dec</code></b></blockquote>"""


@PY.UBOT("hex2dec")
@PY.TOP_CMD
async def hex2dec(client, message):
    """ʜᴇx ᴛᴏ ᴅᴇᴄ"""
    try:
        val = message.text.split(None, 1)[1]
        result = int(val, 16)
        await message.edit(f"<b>🔢 Hex {val} = Decimal {result}</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.hex2dec FF</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
