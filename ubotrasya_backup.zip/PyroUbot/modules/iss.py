from PyroUbot import *
import aiohttp

__MODULE__ = "ɪꜱꜱ"
__HELP__ = """<blockquote><b>⎆ <code>{0}iss</code></b></blockquote>"""


@PY.UBOT("iss")
@PY.TOP_CMD
async def iss(client, message):
    """ɪꜱꜱ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("http://api.open-notify.org/iss-now.json") as r:
                d = await r.json()
            async with s.get("http://api.open-notify.org/astros.json") as r2:
                a = await r2.json()
        pos = d["iss_position"]
        txt = (
            f"<b>🛸 ISS Position</b>\n\n"
            f"<b>📍 Latitude:</b> {pos['latitude']}\n"
            f"<b>📍 Longitude:</b> {pos['longitude']}\n"
            f"<b>👨‍🚀 People in Space:</b> {a['number']}"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
