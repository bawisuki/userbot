from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ g2oz"
__HELP__ = """<blockquote><b>⎆ <code>{0}g2oz</code></b></blockquote>"""


@PY.UBOT("g2oz")
@PY.TOP_CMD
async def g2oz(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val * 0.035274
        await message.edit(f"<b>📐 {val} grams = {result:.4f} ounces</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.g2oz value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
