from PyroUbot import *
import aiohttp

__MODULE__ = "ᴀᴠᴀᴛᴀʀ"
__HELP__ = """<blockquote><b>⎆ <code>{0}avatar</code></b></blockquote>"""


@PY.UBOT("avatar")
@PY.TOP_CMD
async def avatar(client, message):
    """ᴀᴠᴀᴛᴀʀ"""
    try:
        name = message.text.split(None, 1)[1] if len(message.text.split()) > 1 else "User"
        url = f"https://ui-avatars.com/api/?name={name}&size=256&background=random"
        await message.edit(f"<b>👤 Avatar Generated</b>\n\n<b>Name:</b> {name}\n<b>🔗 URL:</b> {url}", parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
