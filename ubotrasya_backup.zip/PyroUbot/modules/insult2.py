from PyroUbot import *
import random

__MODULE__ = "friendly i"
__HELP__ = """<blockquote><b>⎆ <code>{0}insult2</code></b></blockquote>"""


@PY.UBOT("insult2")
@PY.TOP_CMD
async def insult2(client, message):
    """friendly i"""
    try:
        items = ["You're like a cloud. When you disappear, it's a beautiful day.", "I'd explain it to you but I left my crayons at home.", "You're not stupid; you just have bad luck thinking.", "If you were any more inbred, you'd be a sandwich.", 'You bring everyone so much joy... when you leave.', "I'm not saying you're boring, but you make plain yogurt look exciting."]
        await message.edit(f"<b>🎲 Friendly Insult</b>\n\n<i>{random.choice(items)}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
