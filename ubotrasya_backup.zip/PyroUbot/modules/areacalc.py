from PyroUbot import *

__MODULE__ = "📐 Area"
__HELP__ = """<blockquote><b>⎆ <code>{0}area</code></b></blockquote>"""


@PY.UBOT("area")
@PY.TOP_CMD
async def areacalc(client, message):
    """📐 Area"""
    try:
        args = message.text.split()
        length = float(args[1])
        width = float(args[2])
        result = length * width
        await message.edit(f"<b>📐 Area</b>\n\n<b>{length} × {width} = {result}</b> sq units", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Usage:</b> <code>.area length width</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
