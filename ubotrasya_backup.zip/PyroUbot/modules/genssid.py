from PyroUbot import *
import random

__MODULE__ = "📶 WiFi Nam"
__HELP__ = """<blockquote><b>⎆ <code>{0}genssid</code></b></blockquote>"""


@PY.UBOT("genssid")
@PY.TOP_CMD
async def genssid(client, message):
    """📶 WiFi Nam"""
    try:
        result = f"{random.choice(['Home','Office','Guest','Private','Public'])}_{random.choice(['Net','WiFi','Network','LAN','5G'])}_{random.randint(1,99)}"
        await message.edit(f"<b>📶 WiFi Name</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
