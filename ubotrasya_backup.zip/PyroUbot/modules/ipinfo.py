from PyroUbot import *
import aiohttp

__MODULE__ = "ɪᴘ ɪɴꜰᴏ ipinfo"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ɪᴘ ɪɴꜰᴏ

⎆ <code>{0}ipinfo</code> [ip]
   ᴄᴇᴋ ɪɴꜰᴏʀᴍᴀꜱɪ ɪᴘ ᴀᴅᴅʀᴇꜱꜱ</b></blockquote>
"""


@PY.UBOT("ipinfo")
@PY.TOP_CMD
async def ipinfo_cmd(client, message):
    if len(message.command) < 2:
        return await message.reply("<emoji id=5210952531676504517>❌</emoji> Format: <code>.ipinfo [ip]</code>", quote=True)
    ip = message.command[1]
    prs = await message.reply("<emoji id=5789858554890425372>🔄</emoji> <b>ᴍᴇɴɢᴇᴄᴇᴋ...</b>", quote=True)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://ipwho.is/{ip}", timeout=aiohttp.ClientTimeout(total=8)) as r:
                data = await r.json(content_type=None)
        if data.get("success"):
            text = (
                f"<b><emoji id=5206607081334906820>✅</emoji> IP Info: <code>{ip}</code></b>\n\n"
                f"<b>🌍 Country:</b> {data.get('country', '?')}\n"
                f"<b>🏙 City:</b> {data.get('city', '?')}\n"
                f"<b>📍 Region:</b> {data.get('region', '?')}\n"
                f"<b>🏢 ISP:</b> {data.get('connection', {}).get('isp', '?')}\n"
                f"<b>🕐 Timezone:</b> {data.get('timezone', {}).get('id', '?')}\n"
                f"<b>📌 Lat/Lon:</b> {data.get('latitude')}, {data.get('longitude')}"
            )
            await prs.edit(text)
        else:
            await prs.edit(f"<emoji id=5210952531676504517>❌</emoji> IP tidak valid: {data.get('message', '?')}")
    except Exception as e:
        await prs.edit(f"<emoji id=5210952531676504517>❌</emoji> Error: {str(e)[:80]}")
