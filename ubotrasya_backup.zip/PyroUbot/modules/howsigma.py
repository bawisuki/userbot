from PyroUbot import *
import random

__MODULE__ = "🐺 How Si"
__HELP__ = """<blockquote><b>⎆ <code>{0}howsigma</code></b></blockquote>"""


@PY.UBOT("howsigma")
@PY.TOP_CMD
async def howsigma(client, message):
    """🐺 How Si"""
    try:
        target = message.reply_to_message.from_user.first_name if message.reply_to_message else "You"
        pct = random.randint(0, 100)
        await message.edit(f"<b>🐺 How Sigma?</b>\n\n{target} is <b>{pct}%</b> sigma!", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
