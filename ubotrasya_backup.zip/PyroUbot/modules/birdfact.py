from PyroUbot import *
import aiohttp

__MODULE__ = "🐦 Bird Fac"
__HELP__ = """<blockquote><b>⎆ <code>{0}birdfact</code></b></blockquote>"""


@PY.UBOT("birdfact")
@PY.TOP_CMD
async def birdfact(client, message):
    """🐦 Bird Fac"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://some-random-api.com/animal/bird") as r:
                d = await r.json()
        result = d.get('fact','No fact')
        await message.edit(f"<b>🐦 Bird Fact</b>\n\n{result}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
