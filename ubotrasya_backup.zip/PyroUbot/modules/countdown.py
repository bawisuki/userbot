from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄᴏᴜɴᴛᴅᴏᴡɴ"
__HELP__ = """<blockquote><b>⎆ <code>{0}countdown</code></b></blockquote>"""


@PY.UBOT("countdown")
@PY.TOP_CMD
async def countdown(client, message):
    """ᴄᴏᴜɴᴛᴅᴏᴡɴ"""
    try:
        from datetime import datetime
        target = message.text.split(None, 1)[1]
        target_date = datetime.strptime(target, "%Y-%m-%d")
        now = datetime.now()
        diff = target_date - now
        if diff.days < 0:
            return await message.edit("<b>❌ Date is in the past!</b>", parse_mode=ParseMode.HTML)
        await message.edit(f"<b>⏳ Countdown to {target}</b>\n\n<b>{diff.days} days</b> remaining", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.countdown 2025-12-31</code>", parse_mode=ParseMode.HTML)
    except ValueError:
        await message.edit("<b>⚠️ Format: YYYY-MM-DD</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
