from PyroUbot import *

__MODULE__ = "ʙᴀɴᴅᴡɪᴅᴛʜ"
__HELP__ = """<blockquote><b>⎆ <code>{0}bandwidth</code></b></blockquote>"""


@PY.UBOT("bandwidth")
@PY.TOP_CMD
async def bandwidth(client, message):
    """ʙᴀɴᴅᴡɪᴅᴛʜ"""
    try:
        args = message.text.split()
        size_mb = float(args[1])
        speed_mbps = float(args[2]) if len(args) > 2 else 10
        time_sec = (size_mb * 8) / speed_mbps
        if time_sec > 3600:
            time_str = f"{time_sec/3600:.1f} hours"
        elif time_sec > 60:
            time_str = f"{time_sec/60:.1f} minutes"
        else:
            time_str = f"{time_sec:.1f} seconds"
        await message.edit(f"<b>📡 Download Time</b>\n\n<b>File:</b> {size_mb} MB\n<b>Speed:</b> {speed_mbps} Mbps\n<b>Time:</b> {time_str}", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.bandwidth size_mb [speed_mbps]</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
