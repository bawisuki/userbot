from PyroUbot import *
import random

__MODULE__ = "ʜᴀɴɢᴍᴀɴ"
__HELP__ = """<blockquote><b>⎆ <code>{0}hangman</code></b></blockquote>"""


@PY.UBOT("hangman")
@PY.TOP_CMD
async def hangman(client, message):
    """ʜᴀɴɢᴍᴀɴ"""
    try:
        words = ["python","telegram","programming","developer","algorithm","database","network","security","function","variable"]
        word = random.choice(words)
        hint = "".join(c if i % 3 == 0 else "_" for i, c in enumerate(word))
        await message.edit(f"<b>🎮 Hangman</b>\n\nWord: <code>{hint}</code> ({len(word)} letters)\n\n<tg-spoiler><b>Answer:</b> {word}</tg-spoiler>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
