from PyroUbot import *
import random

__MODULE__ = "Guess a nu"
__HELP__ = """<blockquote><b>⎆ <code>{0}guess</code></b></blockquote>"""


@PY.UBOT("guess")
@PY.TOP_CMD
async def guessnum(client, message):
    """Guess a nu"""
    try:
        result = random.randint(1, 100)
        await message.edit(f"<b>Guess a number 1-100 Guess Number</b>\n\n<b>Result:</b> {result}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
