from PyroUbot import *
import aiohttp

__MODULE__ = "ᴇᴍᴏᴊɪ"
__HELP__ = """<blockquote><b>⎆ <code>{0}emoji2</code></b></blockquote>"""


@PY.UBOT("emoji2")
@PY.TOP_CMD
async def emojimix(client, message):
    """ᴇᴍᴏᴊɪ"""
    try:
        args = message.text.split(None, 1)
        if len(args) < 2:
            return await message.edit("<b>⚠️ Usage:</b> <code>.emoji2 emoji</code>", parse_mode=ParseMode.HTML)
        emoji = args[1]
        code = f"{ord(emoji[0]):x}" if emoji else ""
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://emojihub.yurace.pro/api/all/group/smileys-and-people") as r:
                d = await r.json()
        item = d[0] if d else None
        if item:
            await message.edit(f"<b>😀 Emoji Info</b>\n\n<b>Name:</b> {item['name']}\n<b>Category:</b> {item['category']}\n<b>Group:</b> {item['group']}\n<b>Unicode:</b> {' '.join(item['unicode'])}", parse_mode=ParseMode.HTML)
        else:
            await message.edit("<b>❌ No emoji data.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
