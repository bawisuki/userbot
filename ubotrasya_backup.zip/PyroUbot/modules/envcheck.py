from PyroUbot import *
import os as _os

__MODULE__ = "ᴇɴᴠ"
__HELP__ = """<blockquote><b>⎆ <code>{0}envcount</code></b></blockquote>"""


@PY.UBOT("envcount")
@PY.TOP_CMD
async def envcheck(client, message):
    """ᴇɴᴠ"""
    try:
        env_count = len(_os.environ)
        path_count = len(_os.environ.get("PATH","").split(":"))
        await message.edit(f"<b>🔧 Environment</b>\n\n<b>Variables:</b> {env_count}\n<b>PATH entries:</b> {path_count}\n<b>User:</b> {_os.environ.get('USER','root')}\n<b>Shell:</b> {_os.environ.get('SHELL','N/A')}\n<b>Home:</b> {_os.environ.get('HOME','N/A')}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
