from PyroUbot import *
import random

__MODULE__ = "🍕 Food"
__HELP__ = """<blockquote><b>⎆ <code>{0}foodfact</code></b></blockquote>"""


@PY.UBOT("foodfact")
@PY.TOP_CMD
async def food(client, message):
    """🍕 Food"""
    try:
        items = ['Honey never spoils.', "Bananas are berries, but strawberries aren't.", "Peanuts aren't nuts - they're legumes.", "Apples float because they're 25% air.", 'Chocolate was once used as currency.']
        await message.edit(f"<b>🍕 Food</b>\n\n<i>{random.choice(items)}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
