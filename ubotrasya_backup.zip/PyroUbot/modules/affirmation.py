from PyroUbot import *
import aiohttp

__MODULE__ = "ᴀꜰꜰɪʀᴍ"
__HELP__ = """<blockquote><b>⎆ <code>{0}affirmation</code></b></blockquote>"""


@PY.UBOT("affirmation")
@PY.TOP_CMD
async def affirmation(client, message):
    """ᴀꜰꜰɪʀᴍ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://www.affirmations.dev/") as r:
                d = await r.json()
        await message.edit(f"<b>✨ Affirmation</b>\n\n<i>{d['affirmation']}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
