from PyroUbot import *
import aiohttp
import os

__MODULE__ = "ɪɴꜱᴛᴀɢʀᴀᴍ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ɪɴꜱᴛᴀɢʀᴀᴍ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ

⎆ <code>{0}igdl</code> [url]
   ᴅᴏᴡɴʟᴏᴀᴅ ᴍᴇᴅɪᴀ ɪɴꜱᴛᴀɢʀᴀᴍ</b></blockquote>
"""


@PY.UBOT("igdl")
@PY.TOP_CMD
async def instagram_dl(client, message):
    url = message.text.split(None, 1)
    if len(url) < 2:
        return await message.edit("<b><emoji id=5210952531676504517>❌</emoji> ɢᴜɴᴀᴋᴀɴ: <code>.igdl [url]</code></b>")
    url = url[1].strip()
    await message.edit("<b><emoji id=5789858554890425372>🔄</emoji> ꜱᴇᴅᴀɴɢ ᴍᴇɴᴅᴏᴡɴʟᴏᴀᴅ...</b>")
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"https://api.ryzumi.net/api/downloader/instagram?url={url}") as resp:
                res = await resp.json(content_type=None)
            data = res.get("data", [])
            if not data or not data[0].get("url"):
                return await message.edit("<b><emoji id=5210952531676504517>❌</emoji> ɢᴀɢᴀʟ ᴍᴇɴᴅᴀᴘᴀᴛᴋᴀɴ ᴍᴇᴅɪᴀ</b>")
            media_url = data[0]["url"]
            async with session.get(media_url) as med:
                content = await med.read()
                ext = "mp4" if "video" in med.content_type else "jpg"
                fname = f"ig_dl.{ext}"
                with open(fname, "wb") as f:
                    f.write(content)
        await message.delete()
        if ext == "mp4":
            await client.send_video(message.chat.id, fname, caption="<b><emoji id=5206607081334906820>✅</emoji> ɪɴꜱᴛᴀɢʀᴀᴍ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ</b>")
        else:
            await client.send_photo(message.chat.id, fname, caption="<b><emoji id=5206607081334906820>✅</emoji> ɪɴꜱᴛᴀɢʀᴀᴍ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ</b>")
    except Exception as e:
        await message.edit(f"<b><emoji id=5210952531676504517>❌</emoji> ᴇʀʀᴏʀ:</b> <code>{e}</code>")
    finally:
        for f in ["ig_dl.mp4", "ig_dl.jpg"]:
            if os.path.exists(f):
                os.remove(f)
