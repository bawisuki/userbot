import os
from PIL import Image
from PyroUbot import *

__MODULE__ = "ꜰʟɪᴘ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ꜰʟɪᴘ

⎆ <code>{0}fliph</code> ʀᴇᴘʟʏ ꜰᴏᴛᴏ ꜰʟɪᴘ ʜᴏʀɪᴢᴏɴᴛᴀʟ
⎆ <code>{0}flipv</code> ʀᴇᴘʟʏ ꜰᴏᴛᴏ ꜰʟɪᴘ ᴠᴇʀᴛɪᴄᴀʟ</b></blockquote>
"""


@PY.UBOT("fliph")
@PY.TOP_CMD
async def fliph_cmd(client, message):
    try:
        reply = message.reply_to_message
        if not reply or not reply.photo:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ʀᴇᴘʟʏ ᴋᴇ ꜰᴏᴛᴏ!</b>", parse_mode=ParseMode.HTML)
        await message.edit("<emoji id=5206607081334906820>✅</emoji> <b>ᴍᴇᴍᴘʀᴏꜱᴇꜱ...</b>", parse_mode=ParseMode.HTML)
        path = await client.download_media(reply, file_name="./downloads/")
        img = Image.open(path).transpose(Image.FLIP_LEFT_RIGHT)
        out = "./downloads/fliph.png"
        img.save(out, "PNG")
        await client.send_photo(message.chat.id, out, reply_to_message_id=message.id)
        await message.delete()
        os.remove(path)
        os.remove(out)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("flipv")
@PY.TOP_CMD
async def flipv_cmd(client, message):
    try:
        reply = message.reply_to_message
        if not reply or not reply.photo:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ʀᴇᴘʟʏ ᴋᴇ ꜰᴏᴛᴏ!</b>", parse_mode=ParseMode.HTML)
        await message.edit("<emoji id=5206607081334906820>✅</emoji> <b>ᴍᴇᴍᴘʀᴏꜱᴇꜱ...</b>", parse_mode=ParseMode.HTML)
        path = await client.download_media(reply, file_name="./downloads/")
        img = Image.open(path).transpose(Image.FLIP_TOP_BOTTOM)
        out = "./downloads/flipv.png"
        img.save(out, "PNG")
        await client.send_photo(message.chat.id, out, reply_to_message_id=message.id)
        await message.delete()
        os.remove(path)
        os.remove(out)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)
