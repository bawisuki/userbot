from PyroUbot import *
import random

__MODULE__ = "ᴅᴏᴀ"
__HELP__ = """<blockquote><b>⎆ <code>{0}doa</code></b></blockquote>"""


@PY.UBOT("doa")
@PY.TOP_CMD
async def doaharian(client, message):
    """ᴅᴏᴀ"""
    try:
        doas = [
            ("Doa Sebelum Makan", "اللَّهُمَّ بَارِكْ لَنَا فِيمَا رَزَقْتَنَا وَقِنَا عَذَابَ النَّارِ", "Ya Allah, berkahilah kami dalam rezeki yang Engkau berikan dan lindungilah kami dari siksa api neraka."),
            ("Doa Sesudah Makan", "الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مُسْلِمِينَ", "Segala puji bagi Allah yang telah memberi kami makan dan minum serta menjadikan kami muslim."),
            ("Doa Keluar Rumah", "بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ لاَ حَوْلَ وَلاَ قُوَّةَ إِلاَّ بِاللَّهِ", "Dengan nama Allah, aku bertawakal kepada Allah, tiada daya dan kekuatan kecuali dengan Allah."),
            ("Doa Masuk Masjid", "اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ", "Ya Allah, bukakanlah untukku pintu-pintu rahmat-Mu."),
            ("Doa Sebelum Tidur", "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا", "Dengan nama-Mu ya Allah aku mati dan aku hidup."),
        ]
        title, arab, arti = random.choice(doas)
        await message.edit(f"<b>🤲 {title}</b>\n\n<b>{arab}</b>\n\n<i>{arti}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
