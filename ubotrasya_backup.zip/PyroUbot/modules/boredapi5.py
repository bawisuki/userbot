from PyroUbot import *
import aiohttp

__MODULE__ = "ʙᴏʀᴇᴅ 5"
__HELP__ = """<blockquote><b>⎆ <code>{0}bored5</code></b></blockquote>"""


@PY.UBOT("bored5")
@PY.TOP_CMD
async def bored5(client, message):
    """ʙᴏʀᴇᴅ 5"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://bored-api.appbrewery.com/random?type=diy") as r:
                d = await r.json()
        await message.edit(f"<b>🔧 DIY Activity</b>\n\n{d['activity']}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
