from PyroUbot import *
import random

__MODULE__ = "🏰"
__HELP__ = """<blockquote><b>⎆ <code>{0}hogwarts</code></b></blockquote>"""


@PY.UBOT("hogwarts")
@PY.TOP_CMD
async def hogwarts(client, message):
    """🏰"""
    try:
        result = random.choice(['🦁 Gryffindor','🐍 Slytherin','🦅 Ravenclaw','🦡 Hufflepuff'])
        await message.edit(f"<b>🏰 Hogwarts House</b>\n\n<b>Result:</b> {result}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
