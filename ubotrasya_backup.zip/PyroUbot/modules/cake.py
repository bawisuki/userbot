from PyroUbot import *
import aiohttp

__MODULE__ = "🥞 CAKE"
__HELP__ = """<blockquote><b>⎆ <code>{0}cake</code></b></blockquote>"""


@PY.UBOT("cake")
@PY.TOP_CMD
async def cake(client, message):
    """🥞 CAKE"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api.coingecko.com/api/v3/simple/price?ids=pancakeswap-token&vs_currencies=usd&include_24hr_change=true") as r:
                d = await r.json()
        price = d["pancakeswap-token"]["usd"]
        change = d["pancakeswap-token"].get("usd_24h_change", 0)
        emoji_c = "📈" if change >= 0 else "📉"
        await message.edit(f"<b>🥞 CAKE</b>\n\n<b>💰 Price:</b> ${price}\n<b>{emoji_c} 24h:</b> {change:.2f}%", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
