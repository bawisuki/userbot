from PyroUbot import *

__MODULE__ = "ɢᴀʟ ᴛᴏ ʟ"
__HELP__ = """<blockquote><b>⎆ <code>{0}gal2l</code></b></blockquote>"""


@PY.UBOT("gal2l")
@PY.TOP_CMD
async def gal2lit(client, message):
    """ɢᴀʟ ᴛᴏ ʟ"""
    try:
        val = float(message.text.split(None, 1)[1])
        await message.edit(f"<b>🫗 {val} gallons = {val * 3.78541:.2f} liters</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.gal2l 5</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
