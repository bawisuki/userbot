from PyroUbot import *
import aiohttp

__MODULE__ = "🐶 Dog Fa"
__HELP__ = """<blockquote><b>⎆ <code>{0}dogfact2</code></b></blockquote>"""


@PY.UBOT("dogfact2")
@PY.TOP_CMD
async def dogfact2(client, message):
    """🐶 Dog Fa"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://dog-api.kinduff.com/api/facts") as r:
                d = await r.json(content_type=None)
        result = d["facts"][0]
        await message.edit(f"<b>🐶 Dog Fact</b>\n\n{result}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
