from PyroUbot import *
import asyncio, random

__MODULE__ = "ɢʟɪᴛᴄʜ"
__HELP__ = """<blockquote><b>⎆ <code>{0}glitch</code></b></blockquote>"""


@PY.UBOT("glitch")
@PY.TOP_CMD
async def glitch(client, message):
    """ɢʟɪᴛᴄʜ"""
    try:
        text = message.text.split(None, 1)[1]
        glitch_chars = "!@#$%^&*()_+-=[]{}|;:,.<>?"
        for _ in range(4):
            glitched = "".join(random.choice(glitch_chars) if random.random() > 0.6 else c for c in text)
            await message.edit(f"<code>{glitched}</code>", parse_mode=ParseMode.HTML)
            await asyncio.sleep(0.4)
        await message.edit(f"<code>{text}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.glitch text</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
