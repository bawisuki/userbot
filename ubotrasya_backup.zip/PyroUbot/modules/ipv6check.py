from PyroUbot import *
import aiohttp

__MODULE__ = "ɪᴘᴠ6"
__HELP__ = """<blockquote><b>⎆ <code>{0}ipv6</code></b></blockquote>"""


@PY.UBOT("ipv6")
@PY.TOP_CMD
async def ipv6check(client, message):
    """ɪᴘᴠ6"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api64.ipify.org?format=json") as r:
                d = await r.json()
        await message.edit(f"<b>🌐 Public IP</b>\n\n<code>{d['ip']}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
