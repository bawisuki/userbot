from PyroUbot import *
import aiohttp

__MODULE__ = "ɢʜ ᴄᴏᴍᴍɪᴛꜱ"
__HELP__ = """<blockquote><b>⎆ <code>{0}ghcommits</code></b></blockquote>"""


@PY.UBOT("ghcommits")
@PY.TOP_CMD
async def github_commits(client, message):
    """ɢʜ ᴄᴏᴍᴍɪᴛꜱ"""
    try:
        repo = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.github.com/repos/{repo}/commits?per_page=5") as r:
                d = await r.json()
        if isinstance(d, dict) and "message" in d:
            return await message.edit("<b>❌ Repo not found.</b>", parse_mode=ParseMode.HTML)
        txt = f"<b>📝 Recent Commits: {repo}</b>\n\n"
        for c in d[:5]:
            msg = c["commit"]["message"].split("\n")[0][:60]
            txt += f"• <code>{c['sha'][:7]}</code> {msg}\n"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.ghcommits user/repo</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
