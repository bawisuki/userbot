from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄᴘᴜ"
__HELP__ = """<blockquote><b>⎆ <code>{0}cpu</code></b></blockquote>"""


@PY.UBOT("cpu")
@PY.TOP_CMD
async def cpu(client, message):
    """ᴄᴘᴜ"""
    try:
        with open("/proc/cpuinfo") as f:
            cpuinfo = f.read()
        model = "Unknown"
        cores = 0
        for line in cpuinfo.split("\n"):
            if "model name" in line:
                model = line.split(":")[1].strip()
            if "processor" in line:
                cores += 1
        with open("/proc/loadavg") as f:
            load = f.read().split()[:3]
        txt = (
            f"<b>🖥 CPU Info</b>\n\n"
            f"<b>Model:</b> {model}\n"
            f"<b>Cores:</b> {cores}\n"
            f"<b>Load Avg:</b> {' '.join(load)}"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
