from PyroUbot import *
import aiohttp
import os
from urllib.parse import quote

__MODULE__ = "ɪǫᴄ"
__HELP__ = """<blockquote><b>⎆ <code>{0}iqc</code></b></blockquote>"""


@PY.UBOT("iqc")
@PY.TOP_CMD
async def iqc(client, message):
    """ɪǫᴄ"""
    try:
        args = message.text.split(None, 1)
        if len(args) < 2:
            return await message.edit("<b>⚠️ Usage:</b> <code>.iqc text</code>", parse_mode=ParseMode.HTML)
        text = args[1]
        await message.edit("<b>⏳ Generating...</b>", parse_mode=ParseMode.HTML)
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api-nanzz.my.id/docs/api/maker/iqc.php?text={quote(text)}") as r:
                if r.status == 200 and "image" in r.headers.get("Content-Type", ""):
                    img = await r.read()
                    path = "/tmp/iqc.png"
                    with open(path, "wb") as f:
                        f.write(img)
                    await message.reply_photo(path)
                    await message.delete()
                    os.remove(path)
                else:
                    await message.edit("<b>❌ Gagal generate.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
