from PyroUbot import *

__MODULE__ = "ꜰᴀᴄᴛᴏʀɪᴀʟ"
__HELP__ = """<blockquote><b>⎆ <code>{0}fact</code></b></blockquote>"""


@PY.UBOT("fact")
@PY.TOP_CMD
async def factorial(client, message):
    """ꜰᴀᴄᴛᴏʀɪᴀʟ"""
    try:
        import math
        n = int(message.text.split(None, 1)[1])
        n = min(n, 100)
        result = math.factorial(n)
        await message.edit(f"<b>🔢 {n}! = </b><code>{str(result)[:3000]}</code>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.fact 10</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
