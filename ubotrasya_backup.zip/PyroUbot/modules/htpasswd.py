from PyroUbot import *
import hashlib, base64, os as _os

__MODULE__ = "ʜᴛᴘᴀꜱꜱᴡᴅ"
__HELP__ = """<blockquote><b>⎆ <code>{0}htpasswd</code></b></blockquote>"""


@PY.UBOT("htpasswd")
@PY.TOP_CMD
async def htpasswd(client, message):
    """ʜᴛᴘᴀꜱꜱᴡᴅ"""
    try:
        args = message.text.split(None, 2)
        user = args[1]
        pwd = args[2]
        salt = _os.urandom(4)
        h = hashlib.sha1(pwd.encode() + salt).digest()
        ssha = base64.b64encode(h + salt).decode()
        apr1 = base64.b64encode(hashlib.md5(pwd.encode()).digest()).decode()
        txt = f"<b>🔑 htpasswd Generator</b>\n\n<b>User:</b> {user}\n\n<b>SHA:</b>\n<code>{user}:{{SSHA}}{ssha}</code>\n\n<b>MD5:</b>\n<code>{user}:$apr1${apr1[:8]}$</code>"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.htpasswd user password</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
