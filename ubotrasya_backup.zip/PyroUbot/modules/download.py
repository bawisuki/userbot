from PyroUbot import *
import os

__MODULE__ = "ᴅᴏᴡɴʟᴏᴀᴅ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴅᴏᴡɴʟᴏᴀᴅ

⎆ <code>{0}dl</code> ʀᴇᴘʟʏ ᴍᴇᴅɪᴀ ᴜɴᴛᴜᴋ ᴅᴏᴡɴʟᴏᴀᴅ ᴋᴇ ꜱᴇʀᴠᴇʀ
⎆ <code>{0}upload</code> [path] ᴜᴘʟᴏᴀᴅ ꜰɪʟᴇ ᴅᴀʀɪ ꜱᴇʀᴠᴇʀ</b></blockquote>
"""


@PY.UBOT("dl")
@PY.TOP_CMD
async def download_media(client, message):
    try:
        reply = message.reply_to_message
        if not reply or not reply.media:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ʀᴇᴘʟʏ ᴋᴇ ᴍᴇᴅɪᴀ ᴜɴᴛᴜᴋ ᴅᴏᴡɴʟᴏᴀᴅ!</b>", parse_mode=ParseMode.HTML)
        await message.edit("<emoji id=5789858554890425372>🔄</emoji> <b>ᴍᴇɴᴅᴏᴡɴʟᴏᴀᴅ...</b>", parse_mode=ParseMode.HTML)
        path = await reply.download(file_name="downloads/")
        size = os.path.getsize(path)
        size_str = f"{size / (1024*1024):.2f}MB" if size > 1024*1024 else f"{size / 1024:.2f}KB"
        await message.edit(
            f"<emoji id=5206607081334906820>✅</emoji> <b>ʙᴇʀʜᴀꜱɪʟ ᴅɪᴅᴏᴡɴʟᴏᴀᴅ!</b>\n"
            f"<b>⎆ ᴘᴀᴛʜ:</b> <code>{path}</code>\n"
            f"<b>⎆ ꜱɪᴢᴇ:</b> <code>{size_str}</code>",
            parse_mode=ParseMode.HTML,
        )
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("upload")
@PY.TOP_CMD
async def upload_file(client, message):
    try:
        args = message.text.split(None, 1)
        if len(args) < 2:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.upload [path]</code>", parse_mode=ParseMode.HTML)
        path = args[1]
        if not os.path.exists(path):
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ꜰɪʟᴇ ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ!</b>", parse_mode=ParseMode.HTML)
        await message.edit("<emoji id=5789858554890425372>🔄</emoji> <b>ᴍᴇɴɢᴜᴘʟᴏᴀᴅ...</b>", parse_mode=ParseMode.HTML)
        await client.send_document(message.chat.id, path, quote=True)
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ʙᴇʀʜᴀꜱɪʟ ᴅɪᴜᴘʟᴏᴀᴅ!</b>\n<b>⎆ ꜰɪʟᴇ:</b> <code>{path}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
