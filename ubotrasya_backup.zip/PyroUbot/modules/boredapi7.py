from PyroUbot import *
import aiohttp

__MODULE__ = "ʙᴏʀᴇᴅ 7"
__HELP__ = """<blockquote><b>⎆ <code>{0}bored7</code></b></blockquote>"""


@PY.UBOT("bored7")
@PY.TOP_CMD
async def bored7(client, message):
    """ʙᴏʀᴇᴅ 7"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://bored-api.appbrewery.com/random?type=relaxation") as r:
                d = await r.json()
        await message.edit(f"<b>🧘 Relaxation</b>\n\n{d['activity']}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
