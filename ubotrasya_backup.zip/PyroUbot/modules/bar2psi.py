from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ bar2psi"
__HELP__ = """<blockquote><b>⎆ <code>{0}bar2psi</code></b></blockquote>"""


@PY.UBOT("bar2psi")
@PY.TOP_CMD
async def bar2psi(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val * 14.5038
        await message.edit(f"<b>📐 {val} bar = {result:.4f} psi</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.bar2psi value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
