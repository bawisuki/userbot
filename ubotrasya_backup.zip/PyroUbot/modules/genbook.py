from PyroUbot import *
import random

__MODULE__ = "📖 Book Tit"
__HELP__ = """<blockquote><b>⎆ <code>{0}genbook</code></b></blockquote>"""


@PY.UBOT("genbook")
@PY.TOP_CMD
async def genbook(client, message):
    """📖 Book Tit"""
    try:
        result = f"{random.choice(['The','A','My','Our','Their'])} {random.choice(['Secret','Hidden','Lost','Forgotten','Ancient','Dark','Eternal'])} {random.choice(['Garden','Journey','Legacy','Promise','Truth','World','Dream'])}"
        await message.edit(f"<b>📖 Book Title</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
