from PyroUbot import *
import random

__MODULE__ = "🎮 Game Tit"
__HELP__ = """<blockquote><b>⎆ <code>{0}gengame</code></b></blockquote>"""


@PY.UBOT("gengame")
@PY.TOP_CMD
async def gengame(client, message):
    """🎮 Game Tit"""
    try:
        result = f"{random.choice(['Super','Mega','Ultra','Hyper','Turbo'])} {random.choice(['Warrior','Racer','Fighter','Builder','Shooter','Runner','Jumper'])} {random.choice(['X','Pro','2000','Deluxe','Ultimate','Remastered'])}"
        await message.edit(f"<b>🎮 Game Title</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
