from PyroUbot import *

__MODULE__ = "frame text"
__HELP__ = """<blockquote><b>⎆ <code>{0}frame</code></b></blockquote>"""


@PY.UBOT("frame")
@PY.TOP_CMD
async def frame(client, message):
    """frame text"""
    try:
        text = message.text.split(None, 1)[1]
        border = '═' * (len(text) + 2)
        result = f'╔{border}╗\n║ {text} ║\n╚{border}╝'
        await message.edit(f"<code>{result}</code>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Provide text.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
