from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ hr2min"
__HELP__ = """<blockquote><b>⎆ <code>{0}hr2min</code></b></blockquote>"""


@PY.UBOT("hr2min")
@PY.TOP_CMD
async def hr2min(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val*60
        await message.edit(f"<b>📐 {val} hours = {result:.6g} minutes</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.hr2min value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
