from PyroUbot import *
import random

__MODULE__ = "ɪᴘᴠ4 ɢᴇɴ"
__HELP__ = """<blockquote><b>⎆ <code>{0}ipv4gen</code></b></blockquote>"""


@PY.UBOT("ipv4gen")
@PY.TOP_CMD
async def ipv4gen(client, message):
    """ɪᴘᴠ4 ɢᴇɴ"""
    try:
        count = int(message.text.split(None, 1)[1]) if len(message.text.split()) > 1 else 5
        count = min(count, 20)
        ips = [".".join(str(random.randint(1,254)) for _ in range(4)) for _ in range(count)]
        await message.edit(f"<b>🌐 Random IPv4 ({count})</b>\n\n" + "\n".join([f"• <code>{ip}</code>" for ip in ips]), parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
