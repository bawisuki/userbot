from PyroUbot import *
import aiohttp

__MODULE__ = "ᴅᴇᴍᴏʀꜱᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}demorse</code></b></blockquote>"""


@PY.UBOT("demorse")
@PY.TOP_CMD
async def demorse(client, message):
    """ᴅᴇᴍᴏʀꜱᴇ"""
    try:
        code = message.text.split(None, 1)[1]
        morse_dict = {'.-':'A','-...':'B','-.-.':'C','-..':'D','.':'E','..-.':'F','--.':'G','....':'H','..':'I','.---':'J','-.-':'K','.-..':'L','--':'M','-.':'N','---':'O','.--.':'P','--.-':'Q','.-.':'R','...':'S','-':'T','..-':'U','...-':'V','.--':'W','-..-':'X','-.--':'Y','--..':'Z','-----':'0','.----':'1','..---':'2','...--':'3','....-':'4','.....':'5','-....':'6','--...':'7','---..':'8','----.':'9','/':' '}
        words = code.split("   ")
        result = ""
        for word in words:
            for char in word.split():
                result += morse_dict.get(char, "?")
            result += " "
        await message.edit(f"<b>📡 Decoded Morse</b>\n\n<code>{result.strip()}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.demorse .- -... -.-.</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
