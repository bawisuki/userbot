from PyroUbot import *

__MODULE__ = "ᴅɪᴄᴇ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴅɪᴄᴇ

⎆ <code>{0}dice</code>
   ʟᴇᴍᴘᴀʀ ᴅᴀᴅᴜ

⎆ <code>{0}dart</code>
   ʟᴇᴍᴘᴀʀ ᴅᴀʀᴛ

⎆ <code>{0}slot</code>
   ꜱʟᴏᴛ ᴍᴀᴄʜɪɴᴇ

⎆ <code>{0}ball</code>
   ʙᴏʟᴀ ʙᴀꜱᴋᴇᴛ</b></blockquote>
"""


@PY.UBOT("dice")
@PY.TOP_CMD
async def dice(client, message):
    try:
        await message.delete()
        await client.send_dice(message.chat.id, emoji="🎲")
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("dart")
@PY.TOP_CMD
async def dart(client, message):
    try:
        await message.delete()
        await client.send_dice(message.chat.id, emoji="🎯")
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("slot")
@PY.TOP_CMD
async def slot(client, message):
    try:
        await message.delete()
        await client.send_dice(message.chat.id, emoji="🎰")
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("ball")
@PY.TOP_CMD
async def ball(client, message):
    try:
        await message.delete()
        await client.send_dice(message.chat.id, emoji="🏀")
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)
