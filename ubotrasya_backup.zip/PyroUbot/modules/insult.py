from PyroUbot import *
import aiohttp

__MODULE__ = "ɪɴꜱᴜʟᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}insult</code></b></blockquote>"""


@PY.UBOT("insult")
@PY.TOP_CMD
async def insult(client, message):
    """ɪɴꜱᴜʟᴛ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://evilinsult.com/generate_insult.php?lang=en&type=json") as r:
                d = await r.json()
        await message.edit(f"<b>🤬 Evil Insult</b>\n\n{d['insult']}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
