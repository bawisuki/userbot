from PyroUbot import *
import aiohttp

__MODULE__ = "ɢʜ ʟᴀɴɢ"
__HELP__ = """<blockquote><b>⎆ <code>{0}github_lang</code></b></blockquote>"""


@PY.UBOT("github_lang")
@PY.TOP_CMD
async def github_lang(client, message):
    """ɢʜ ʟᴀɴɢ"""
    try:
        repo = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.github.com/repos/{repo}/languages") as r:
                d = await r.json()
        if not d or "message" in d:
            return await message.edit("<b>❌ Repo not found.</b>", parse_mode=ParseMode.HTML)
        total = sum(d.values())
        txt = f"<b>💻 Languages in {repo}</b>\n\n"
        for lang, bytes_count in sorted(d.items(), key=lambda x: x[1], reverse=True):
            pct = (bytes_count / total) * 100
            txt += f"• <b>{lang}:</b> {pct:.1f}%\n"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.github_lang user/repo</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
