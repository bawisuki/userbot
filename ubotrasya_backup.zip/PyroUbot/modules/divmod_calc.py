from PyroUbot import *

__MODULE__ = "divmod"
__HELP__ = """<blockquote><b>⎆ <code>{0}divmod2</code></b></blockquote>"""


@PY.UBOT("divmod2")
@PY.TOP_CMD
async def divmod_calc(client, message):
    """divmod"""
    try:
        args = message.text.split()
        a, b = int(args[1]), int(args[2])
        q, r = divmod(a, b)
        await message.edit(f"<b>{a} ÷ {b} = {q} remainder {r}</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Provide valid numbers.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
