from PyroUbot import *
import aiohttp

__MODULE__ = "ᴇᴀʀᴛʜǫᴜᴀᴋᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}earthquake</code></b></blockquote>"""


@PY.UBOT("earthquake")
@PY.TOP_CMD
async def earthquake(client, message):
    """ᴇᴀʀᴛʜǫᴜᴀᴋᴇ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/significant_week.geojson") as r:
                d = await r.json()
        quakes = d["features"][:5]
        if not quakes:
            return await message.edit("<b>❌ No significant earthquakes this week.</b>", parse_mode=ParseMode.HTML)
        txt = "<b>🌍 Recent Earthquakes</b>\n\n"
        for q in quakes:
            p = q["properties"]
            txt += f"• <b>M{p['mag']}</b> - {p['place']}\n"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
