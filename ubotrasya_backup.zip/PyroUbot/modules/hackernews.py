from PyroUbot import *
import aiohttp

__MODULE__ = "ʜᴀᴄᴋᴇʀɴᴇᴡꜱ"
__HELP__ = """<blockquote><b>⎆ <code>{0}hackernews</code></b></blockquote>"""


@PY.UBOT("hackernews")
@PY.TOP_CMD
async def hackernews(client, message):
    """ʜᴀᴄᴋᴇʀɴᴇᴡꜱ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://hacker-news.firebaseio.com/v0/topstories.json") as r:
                ids = await r.json()
            stories = []
            for sid in ids[:5]:
                async with s.get(f"https://hacker-news.firebaseio.com/v0/item/{sid}.json") as r2:
                    stories.append(await r2.json())
        txt = "<b>📰 Hacker News Top 5</b>\n\n"
        for i, st in enumerate(stories, 1):
            txt += f"{i}. <a href='{st.get('url', '')}'>{st['title']}</a> (⬆️{st.get('score', 0)})\n"
        await message.edit(txt, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
