from PyroUbot import *
import aiohttp

__MODULE__ = "ʜᴇᴀᴅᴇʀꜱ"
__HELP__ = """<blockquote><b>⎆ <code>{0}headers</code></b></blockquote>"""


@PY.UBOT("headers")
@PY.TOP_CMD
async def headers(client, message):
    """ʜᴇᴀᴅᴇʀꜱ"""
    try:
        url = message.text.split(None, 1)[1]
        if not url.startswith("http"):
            url = "https://" + url
        async with aiohttp.ClientSession() as s:
            async with s.head(url, allow_redirects=True, timeout=aiohttp.ClientTimeout(total=10)) as r:
                hdrs = "\n".join([f"<b>{k}:</b> <code>{v}</code>" for k, v in list(r.headers.items())[:15]])
        txt = f"<b>🌐 Headers for {url}</b>\n\n{hdrs}"
        await message.edit(txt, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.headers url</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
