from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄᴀɴɪᴜꜱᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}caniuse</code></b></blockquote>"""


@PY.UBOT("caniuse")
@PY.TOP_CMD
async def caniuse(client, message):
    """ᴄᴀɴɪᴜꜱᴇ"""
    try:
        feature = message.text.split(None, 1)[1]
        url = f"https://caniuse.com/?search={feature}"
        await message.edit(f"<b>🌐 Can I Use: {feature}</b>\n\n<b>🔗 Check:</b> {url}", parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.caniuse feature</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
