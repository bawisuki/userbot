from PyroUbot import *

__MODULE__ = "ʙᴀꜱᴇ58"
__HELP__ = """<blockquote><b>⎆ <code>{0}base58</code></b></blockquote>"""


@PY.UBOT("base58")
@PY.TOP_CMD
async def base58enc(client, message):
    """ʙᴀꜱᴇ58"""
    try:
        text = message.text.split(None, 1)[1]
        alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
        num = int.from_bytes(text.encode(), "big")
        result = ""
        while num > 0:
            num, rem = divmod(num, 58)
            result = alphabet[rem] + result
        await message.edit(f"<b>🔐 Base58 Encoded</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.base58 text</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
