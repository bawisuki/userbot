from PyroUbot import *
import aiohttp

__MODULE__ = "ᴀᴘᴏᴅ"
__HELP__ = """<blockquote><b>⎆ <code>{0}apod</code></b></blockquote>"""


@PY.UBOT("apod")
@PY.TOP_CMD
async def apod(client, message):
    """ᴀᴘᴏᴅ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY") as r:
                d = await r.json()
        txt = (
            f"<b>🌌 NASA Astronomy Picture of the Day</b>\n\n"
            f"<b>📛 Title:</b> {d['title']}\n"
            f"<b>📅 Date:</b> {d['date']}\n"
            f"<b>📝 Explanation:</b> {d['explanation'][:400]}\n"
            f"<b>🔗 URL:</b> {d.get('hdurl', d.get('url', 'N/A'))}"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
