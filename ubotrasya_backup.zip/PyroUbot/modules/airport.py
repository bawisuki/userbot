from PyroUbot import *
import aiohttp

__MODULE__ = "ᴀɪʀᴘᴏʀᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}airport</code></b></blockquote>"""


@PY.UBOT("airport")
@PY.TOP_CMD
async def airport(client, message):
    """ᴀɪʀᴘᴏʀᴛ"""
    try:
        code = message.text.split(None, 1)[1].upper()
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://aviationweather.gov/api/data/airport?ids={code}&format=json") as r:
                d = await r.json()
        if not d:
            return await message.edit("<b>❌ Airport not found.</b>", parse_mode=ParseMode.HTML)
        a = d[0]
        txt = f"<b>✈️ Airport: {code}</b>\n\n<b>Name:</b> {a.get('name','N/A')}\n<b>City:</b> {a.get('city','N/A')}\n<b>Country:</b> {a.get('country','N/A')}\n<b>Elevation:</b> {a.get('elev','N/A')}ft\n<b>Coords:</b> {a.get('lat','')}, {a.get('lon','')}"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.airport ICAO</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
