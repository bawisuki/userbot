from PyroUbot import *

__MODULE__ = "ʙᴏx"
__HELP__ = """<blockquote><b>⎆ <code>{0}box</code></b></blockquote>"""


@PY.UBOT("box")
@PY.TOP_CMD
async def boxtext(client, message):
    """ʙᴏx"""
    try:
        text = message.text.split(None, 1)[1]
        border = "┌" + "─" * (len(text) + 2) + "┐"
        middle = "│ " + text + " │"
        bottom = "└" + "─" * (len(text) + 2) + "┘"
        await message.edit(f"<code>{border}\n{middle}\n{bottom}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.box text</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
