from PyroUbot import *
import aiohttp

__MODULE__ = "📚 Learn"
__HELP__ = """<blockquote><b>⎆ <code>{0}boredlearn</code></b></blockquote>"""


@PY.UBOT("boredlearn")
@PY.TOP_CMD
async def boredlearn(client, message):
    """📚 Learn"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://bored-api.appbrewery.com/random?type=education") as r:
                d = await r.json(content_type=None)
        result = d["activity"]
        await message.edit(f"<b>📚 Learn</b>\n\n{result}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
