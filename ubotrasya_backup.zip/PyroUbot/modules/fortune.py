from PyroUbot import *
import random

__MODULE__ = "ꜰᴏʀᴛᴜɴᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}fortune</code></b></blockquote>"""


@PY.UBOT("fortune")
@PY.TOP_CMD
async def fortune(client, message):
    """ꜰᴏʀᴛᴜɴᴇ"""
    try:
        fortunes = [
            "A beautiful, smart, and loving person will come into your life.",
            "A dubious friend may be an enemy in camouflage.",
            "A faithful friend is a strong defense.",
            "Your hard work will pay off soon.",
            "Something wonderful is about to happen.",
            "You will travel to many exotic places in your lifetime.",
            "A pleasant surprise is waiting for you.",
            "Big journeys begin with a single step.",
            "Believe in yourself and others will too.",
            "Change is happening in your life, so go with the flow!"
        ]
        await message.edit(f"<b>🥠 Fortune Cookie</b>\n\n<i>{random.choice(fortunes)}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
