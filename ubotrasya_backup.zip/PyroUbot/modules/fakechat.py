from PyroUbot import *
import asyncio
from pyrogram.enums import ChatAction

__MODULE__ = "ꜰᴀᴋᴇ ᴄʜᴀᴛ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ꜰᴀᴋᴇ ᴄʜᴀᴛ

⎆ <code>{0}fakechat</code> [text]
   ꜰᴀᴋᴇ ᴛʏᴘɪɴɢ ʟᴀʟᴜ ᴋɪʀɪᴍ ᴛᴇxᴛ</b></blockquote>
"""


@PY.UBOT("fakechat")
@PY.TOP_CMD
async def fakechat_cmd(client, message):
    args = message.text.split(None, 1)
    if len(args) < 2:
        return await message.edit("<b><emoji id=5210952531676504517>❌</emoji> ɢᴜɴᴀᴋᴀɴ: <code>.fakechat [text]</code></b>")
    text = args[1].strip()
    try:
        await message.delete()
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)
        await asyncio.sleep(3)
        await client.send_message(message.chat.id, text)
    except Exception as e:
        await message.edit(f"<b><emoji id=5210952531676504517>❌</emoji> ᴇʀʀᴏʀ:</b> <code>{e}</code>")
