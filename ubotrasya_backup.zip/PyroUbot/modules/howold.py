from PyroUbot import *
import random

__MODULE__ = "ʜᴏᴡ ᴏʟᴅ"
__HELP__ = """<blockquote><b>⎆ <code>{0}howold</code></b></blockquote>"""


@PY.UBOT("howold")
@PY.TOP_CMD
async def howold(client, message):
    """ʜᴏᴡ ᴏʟᴅ"""
    try:
        target = message.reply_to_message.from_user.first_name if message.reply_to_message else "You"
        age = random.randint(5, 80)
        await message.edit(f"<b>👶 How Old?</b>\n\n{target} looks <b>{age} years old</b>!", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
