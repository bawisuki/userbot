from PyroUbot import *
import aiohttp

__MODULE__ = "ᴀɴɪᴍᴇ ǫᴜᴏᴛᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}animequote</code></b></blockquote>"""


@PY.UBOT("animequote")
@PY.TOP_CMD
async def animequote(client, message):
    """ᴀɴɪᴍᴇ ǫᴜᴏᴛᴇ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://animechan.io/api/v1/quotes/random") as r:
                d = await r.json()
        q = d["data"]
        await message.edit(f"<b>🎌 Anime Quote</b>\n\n<i>\"{q['content']}\"</i>\n\n— <b>{q['character']['name']}</b> ({q['anime']['name']})", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
