from PyroUbot import *
import aiohttp

__MODULE__ = "ᴀɪ ᴛᴏᴏʟꜱ"
__HELP__ = """
<blockquote><b>⎆ <code>{0}deepseek</code> [text] ᴅᴇᴇᴘꜱᴇᴇᴋ ᴠ4
⎆ <code>{0}blackbox</code> [text] ʙʟᴀᴄᴋʙᴏx ᴀɪ
⎆ <code>{0}copilot2</code> [text] ᴍꜱ ᴄᴏᴘɪʟᴏᴛ
⎆ <code>{0}gpt4o2</code> [text] ɢᴘᴛ-4ᴏ ᴍɪɴɪ
⎆ <code>{0}perplexity2</code> [text] ᴘᴇʀᴘʟᴇxɪᴛʏ
⎆ <code>{0}unlimitedai</code> [text] ᴜɴʟɪᴍɪᴛᴇᴅ ᴀɪ
⎆ <code>{0}wormgpt</code> [text] ᴡᴏʀᴍɢᴘᴛ
⎆ <code>{0}sunoai</code> [prompt] ɢᴇɴ ᴍᴜꜱɪᴄ
⎆ <code>{0}tts2</code> [text] ᴛᴇxᴛ ᴛᴏ ꜱᴘᴇᴇᴄʜ
⎆ <code>{0}videogen</code> [prompt] ɢᴇɴ ᴠɪᴅᴇᴏ</b></blockquote>
"""


from urllib.parse import quote

@PY.UBOT("deepseek")
@PY.TOP_CMD
async def deepseek(client, message):
    """ᴅᴇᴇᴘꜱᴇᴇᴋ"""
    try:
        args = message.text.split(None, 1)
        text = args[1] if len(args) > 1 else (message.reply_to_message.text if message.reply_to_message else None)
        if not text:
            return await message.edit("<b>⚠️ Usage:</b> <code>.deepseek [text/reply]</code>", parse_mode=ParseMode.HTML)
        await message.edit("<b>⏳ DeepSeek V4 Flash thinking...</b>", parse_mode=ParseMode.HTML)
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api-nanzz.my.id/docs/api/ai/deepseek-4-flash.php?text={quote(text)}") as r:
                d = await r.json()
        if d.get("status"):
            res = d["result"]
            answer = res.get("response", res.get("text", str(res)))
            if isinstance(answer, str) and len(answer) > 0:
                await message.edit(f"<b>🧠 DeepSeek V4 Flash</b>\n\n{answer[:4000]}", parse_mode=ParseMode.HTML)
            else:
                await message.edit(f"<b>🧠 DeepSeek V4 Flash</b>\n\n{str(res)[:4000]}", parse_mode=ParseMode.HTML)
        else:
            await message.edit("<b>❌ Gagal mendapat respons.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
