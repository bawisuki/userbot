from PyroUbot import *

__MODULE__ = "ᴛᴏᴏʟ charcode"
__HELP__ = """<blockquote><b>⎆ <code>{0}charcode</code></b></blockquote>"""


@PY.UBOT("charcode")
@PY.TOP_CMD
async def charcode(client, message):
    """ᴛᴏᴏʟ"""
    try:
        text = message.text.split(None, 1)[1]
        codes = " ".join([str(ord(c)) for c in text[:50]])
        await message.edit(f"<b>🔢 Char Codes</b>\n\n<code>{codes}</code>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, TypeError):
        await message.edit("<b>⚠️ Provide text or reply to a message.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
