from PyroUbot import *

__MODULE__ = "ꜰʟɪᴘ ᴛᴇxᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}fliptext</code></b></blockquote>"""


@PY.UBOT("fliptext")
@PY.TOP_CMD
async def fliptext(client, message):
    """ꜰʟɪᴘ ᴛᴇxᴛ"""
    try:
        text = message.text.split(None, 1)[1]
        flip_map = {"a":"ɐ","b":"q","c":"ɔ","d":"p","e":"ǝ","f":"ɟ","g":"ƃ","h":"ɥ","i":"ᴉ","j":"ɾ","k":"ʞ","l":"l","m":"ɯ","n":"u","o":"o","p":"d","q":"b","r":"ɹ","s":"s","t":"ʇ","u":"n","v":"ʌ","w":"ʍ","x":"x","y":"ʎ","z":"z"}
        result = "".join(flip_map.get(c.lower(), c) for c in reversed(text))
        await message.edit(f"<code>{result}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.fliptext text</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
