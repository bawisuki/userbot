from PyroUbot import *
import random

__MODULE__ = "🍕 How Fa"
__HELP__ = """<blockquote><b>⎆ <code>{0}howfanum</code></b></blockquote>"""


@PY.UBOT("howfanum")
@PY.TOP_CMD
async def howfanum(client, message):
    """🍕 How Fa"""
    try:
        target = message.reply_to_message.from_user.first_name if message.reply_to_message else "You"
        pct = random.randint(0, 100)
        await message.edit(f"<b>🍕 How Fanum?</b>\n\n{target} is <b>{pct}%</b> fanum tax!", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
