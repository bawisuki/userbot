from PyroUbot import *
import aiohttp

__MODULE__ = "ᴅᴇᴠ.ᴛᴏ"
__HELP__ = """<blockquote><b>⎆ <code>{0}devto</code></b></blockquote>"""


@PY.UBOT("devto")
@PY.TOP_CMD
async def devto(client, message):
    """ᴅᴇᴠ.ᴛᴏ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://dev.to/api/articles?per_page=5") as r:
                d = await r.json()
        txt = "<b>📝 Dev.to Latest</b>\n\n"
        for a in d[:5]:
            txt += f"• <a href='{a['url']}'>{a['title']}</a>\n  ❤️ {a['positive_reactions_count']} | 💬 {a['comments_count']}\n\n"
        await message.edit(txt, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
