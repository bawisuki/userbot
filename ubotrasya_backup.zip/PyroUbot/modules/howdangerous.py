from PyroUbot import *
import random

__MODULE__ = "ʜᴏᴡ ᴅᴀɴɢᴇʀ"
__HELP__ = """<blockquote><b>⎆ <code>{0}howdanger</code></b></blockquote>"""


@PY.UBOT("howdanger")
@PY.TOP_CMD
async def howdangerous(client, message):
    """ʜᴏᴡ ᴅᴀɴɢᴇʀ"""
    try:
        target = message.reply_to_message.from_user.first_name if message.reply_to_message else "You"
        pct = random.randint(0, 100)
        await message.edit(f"<b>⚠️ How Dangerous?</b>\n\n{target} is <b>{pct}%</b> dangerous!", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
