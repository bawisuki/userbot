from PyroUbot import *

__MODULE__ = "ᴄʟᴀᴘ"
__HELP__ = """<blockquote><b>⎆ <code>{0}clap</code></b></blockquote>"""


@PY.UBOT("clap")
@PY.TOP_CMD
async def clap(client, message):
    """ᴄʟᴀᴘ"""
    try:
        text = message.text.split(None, 1)[1]
        result = " 👏 ".join(text.split())
        await message.edit(f"<code>{result}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.clap text</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
