from PyroUbot import *
import aiohttp
from datetime import datetime

__MODULE__ = "ʟɪʙᴜʀ"
__HELP__ = """<blockquote><b>⎆ <code>{0}libur</code></b></blockquote>"""


@PY.UBOT("libur")
@PY.TOP_CMD
async def hari_libur(client, message):
    """ʟɪʙᴜʀ"""
    try:
        year = message.text.split(None, 1)[1] if len(message.text.split()) > 1 else str(datetime.now().year)
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://date.nager.at/api/v3/PublicHolidays/{year}/ID") as r:
                d = await r.json()
        if not d:
            return await message.edit("<b>❌ Data tidak tersedia.</b>", parse_mode=ParseMode.HTML)
        txt = f"<b>📅 Hari Libur Indonesia {year}</b>\n\n"
        for h in d[:15]:
            txt += f"• <b>{h['date']}</b> - {h['localName']}\n"
        if len(d) > 15:
            txt += f"\n<i>...dan {len(d)-15} lainnya</i>"
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
