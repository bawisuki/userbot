from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄᴀᴛ ᴘɪᴄ"
__HELP__ = """<blockquote><b>⎆ <code>{0}catpic</code></b></blockquote>"""


@PY.UBOT("catpic")
@PY.TOP_CMD
async def catpic(client, message):
    """ᴄᴀᴛ ᴘɪᴄ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api.thecatapi.com/v1/images/search") as r:
                d = await r.json()
        await message.edit(f"<b>🐱 Random Cat</b>\n\n<a href='{d[0]['url']}'>🖼 View Image</a>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
