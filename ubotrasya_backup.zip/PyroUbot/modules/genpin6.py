from PyroUbot import *
import random

__MODULE__ = "🔢 6-Digit"
__HELP__ = """<blockquote><b>⎆ <code>{0}genpin6</code></b></blockquote>"""


@PY.UBOT("genpin6")
@PY.TOP_CMD
async def genpin6(client, message):
    """🔢 6-Digit """
    try:
        result = str(random.randint(0,999999)).zfill(6)
        await message.edit(f"<b>🔢 6-Digit PIN</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
