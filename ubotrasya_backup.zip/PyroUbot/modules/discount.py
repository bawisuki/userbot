from PyroUbot import *

__MODULE__ = "ᴅɪꜱᴄᴏᴜɴᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}discount</code></b></blockquote>"""


@PY.UBOT("discount")
@PY.TOP_CMD
async def discount(client, message):
    """ᴅɪꜱᴄᴏᴜɴᴛ"""
    try:
        args = message.text.split()
        price = float(args[1])
        pct = float(args[2])
        saved = price * pct / 100
        final = price - saved
        await message.edit(f"<b>🏷 Discount Calculator</b>\n\n<b>Original:</b> ${price:.2f}\n<b>Discount:</b> {pct}%\n<b>You save:</b> ${saved:.2f}\n<b>Final price:</b> ${final:.2f}", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.discount price percent</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
