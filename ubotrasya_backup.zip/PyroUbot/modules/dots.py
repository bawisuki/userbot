from PyroUbot import *

__MODULE__ = "dotted text"
__HELP__ = """<blockquote><b>⎆ <code>{0}dots</code></b></blockquote>"""


@PY.UBOT("dots")
@PY.TOP_CMD
async def dots(client, message):
    """dotted text"""
    try:
        text = message.text.split(None, 1)[1]
        result = '.'.join(text)
        await message.edit(f"<code>{result}</code>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Provide text.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
