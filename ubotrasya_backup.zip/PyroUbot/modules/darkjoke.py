from PyroUbot import *
import random

__MODULE__ = "dark joke"
__HELP__ = """<blockquote><b>⎆ <code>{0}darkjoke</code></b></blockquote>"""


@PY.UBOT("darkjoke")
@PY.TOP_CMD
async def darkjoke(client, message):
    """dark joke"""
    try:
        items = ['I told my wife she was drawing her eyebrows too high. She looked surprised.', 'I have a fish that can breakdance! Only for 20 seconds though, and only once.', 'My grandfather has the heart of a lion and a lifetime ban from the zoo.', 'I threw a boomerang a few years ago. I now live in constant fear.', "I used to think I was indecisive. But now I'm not so sure."]
        await message.edit(f"<b>🎲 Dark Joke</b>\n\n<i>{random.choice(items)}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
