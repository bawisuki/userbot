from PyroUbot import *
import random

__MODULE__ = "📜 Histor"
__HELP__ = """<blockquote><b>⎆ <code>{0}histfact</code></b></blockquote>"""


@PY.UBOT("histfact")
@PY.TOP_CMD
async def history(client, message):
    """📜 Histor"""
    try:
        items = ['The Great Wall of China is not visible from space with the naked eye.', 'Cleopatra lived closer in time to the Moon landing than to the construction of the Great Pyramid.', 'Oxford University is older than the Aztec Empire.', 'The shortest war in history lasted 38 minutes.', 'Ancient Romans used urine as mouthwash.']
        await message.edit(f"<b>📜 History</b>\n\n<i>{random.choice(items)}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
