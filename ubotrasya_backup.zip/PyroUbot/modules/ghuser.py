from PyroUbot import *
import aiohttp

__MODULE__ = "ɢʜ ᴜꜱᴇʀ"
__HELP__ = """<blockquote><b>⎆ <code>{0}ghuser</code></b></blockquote>"""


@PY.UBOT("ghuser")
@PY.TOP_CMD
async def ghuser(client, message):
    """ɢʜ ᴜꜱᴇʀ"""
    try:
        user = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://api.github.com/users/{user}") as r:
                d = await r.json()
        if "message" in d and d["message"] == "Not Found":
            return await message.edit("<b>❌ User not found.</b>", parse_mode=ParseMode.HTML)
        txt = (
            f"<b>👤 {d['login']}</b>\n"
            f"<b>📛 Name:</b> {d.get('name', 'N/A')}\n"
            f"<b>📝 Bio:</b> {d.get('bio', 'N/A')}\n"
            f"<b>📦 Repos:</b> {d['public_repos']}\n"
            f"<b>👥 Followers:</b> {d['followers']}\n"
            f"<b>👤 Following:</b> {d['following']}\n"
            f"<b>🔗 URL:</b> {d['html_url']}"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.ghuser username</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
