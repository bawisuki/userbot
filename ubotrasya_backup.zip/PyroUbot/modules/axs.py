from PyroUbot import *
import aiohttp

__MODULE__ = "🎮 AXS"
__HELP__ = """<blockquote><b>⎆ <code>{0}axs</code></b></blockquote>"""


@PY.UBOT("axs")
@PY.TOP_CMD
async def axs(client, message):
    """🎮 AXS"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api.coingecko.com/api/v3/simple/price?ids=axie-infinity&vs_currencies=usd&include_24hr_change=true") as r:
                d = await r.json()
        price = d["axie-infinity"]["usd"]
        change = d["axie-infinity"].get("usd_24h_change", 0)
        emoji_c = "📈" if change >= 0 else "📉"
        await message.edit(f"<b>🎮 AXS</b>\n\n<b>💰 Price:</b> ${price}\n<b>{emoji_c} 24h:</b> {change:.2f}%", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
