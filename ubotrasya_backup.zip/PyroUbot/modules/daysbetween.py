from PyroUbot import *
from datetime import datetime

__MODULE__ = "ᴅᴀʏꜱ"
__HELP__ = """<blockquote><b>⎆ <code>{0}daysbetween</code></b></blockquote>"""


@PY.UBOT("daysbetween")
@PY.TOP_CMD
async def daysbetween(client, message):
    """ᴅᴀʏꜱ"""
    try:
        args = message.text.split(None, 2)
        d1 = datetime.strptime(args[1], "%Y-%m-%d")
        d2 = datetime.strptime(args[2], "%Y-%m-%d")
        diff = abs((d2 - d1).days)
        await message.edit(f"<b>📅 Days Between</b>\n\n<b>{diff}</b> days", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.daysbetween 2024-01-01 2024-12-31</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
