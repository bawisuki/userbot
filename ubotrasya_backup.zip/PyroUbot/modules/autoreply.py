from PyroUbot import *

__MODULE__ = "ᴀᴜᴛᴏ ʀᴇᴘʟʏ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴀᴜᴛᴏ ʀᴇᴘʟʏ

⎆ <code>{0}autoreply</code> [text] ꜱᴇᴛ ᴀᴜᴛᴏ ʀᴇᴘʟʏ ᴅɪ ᴘᴍ
⎆ <code>{0}autoreply off</code> ᴍᴀᴛɪᴋᴀɴ ᴀᴜᴛᴏ ʀᴇᴘʟʏ</b></blockquote>
"""


@PY.UBOT("autoreply")
@PY.TOP_CMD
async def autoreply_cmd(client, message):
    try:
        args = message.text.split(None, 1)
        if len(args) < 2:
            return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.autoreply [text/off]</code>", parse_mode=ParseMode.HTML)
        text = args[1]
        if text.lower() == "off":
            await remove_vars(client.me.id, "AUTOREPLY_TEXT")
            return await message.edit("<emoji id=5206607081334906820>✅</emoji> <b>ᴀᴜᴛᴏ ʀᴇᴘʟʏ ᴅɪᴍᴀᴛɪᴋᴀɴ!</b>", parse_mode=ParseMode.HTML)
        await set_vars(client.me.id, "AUTOREPLY_TEXT", text)
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ᴀᴜᴛᴏ ʀᴇᴘʟʏ ᴅɪꜱᴇᴛ:</b>\n<code>{text}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
