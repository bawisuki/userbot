from PyroUbot import *
import aiohttp

__MODULE__ = "ᴏɴɢᴋɪʀ"
__HELP__ = """<blockquote><b>⎆ <code>{0}cekongkir2</code></b></blockquote>"""


@PY.UBOT("cekongkir2")
@PY.TOP_CMD
async def cekongkir(client, message):
    """ᴏɴɢᴋɪʀ"""
    try:
        args = message.text.split(None, 3)
        if len(args) < 4:
            return await message.edit("<b>⚠️ Usage:</b> <code>.cekongkir2 asal tujuan berat(gram)</code>\n<b>Contoh:</b> <code>.cekongkir2 jakarta bandung 1000</code>", parse_mode=ParseMode.HTML)
        origin, dest, weight = args[1], args[2], args[3]
        await message.edit(f"<b>📦 Estimasi Ongkir</b>\n\n<b>Dari:</b> {origin}\n<b>Ke:</b> {dest}\n<b>Berat:</b> {weight}g\n\n<i>⚠️ Gunakan .ongkir untuk data real-time dari API RajaOngkir</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
