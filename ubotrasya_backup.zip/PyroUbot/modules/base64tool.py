from PyroUbot import *
import base64

__MODULE__ = "ʙᴀꜱᴇ64"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ʙᴀꜱᴇ64

⎆ <code>{0}b64e</code> [text] ᴇɴᴄᴏᴅᴇ ʙᴀꜱᴇ64
⎆ <code>{0}b64d</code> [text] ᴅᴇᴄᴏᴅᴇ ʙᴀꜱᴇ64</b></blockquote>
"""


@PY.UBOT("b64e")
@PY.TOP_CMD
async def b64e_cmd(client, message):
    args = message.text.split(None, 1)
    if len(args) < 2:
        return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.b64e [text]</code>", parse_mode=ParseMode.HTML)
    try:
        result = base64.b64encode(args[1].encode()).decode()
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ᴇɴᴄᴏᴅᴇᴅ:</b>\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("b64d")
@PY.TOP_CMD
async def b64d_cmd(client, message):
    args = message.text.split(None, 1)
    if len(args) < 2:
        return await message.edit("<emoji id=5210952531676504517>❌</emoji> <b>ɢᴜɴᴀᴋᴀɴ:</b> <code>.b64d [text]</code>", parse_mode=ParseMode.HTML)
    try:
        result = base64.b64decode(args[1].encode()).decode()
        await message.edit(f"<emoji id=5206607081334906820>✅</emoji> <b>ᴅᴇᴄᴏᴅᴇᴅ:</b>\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
