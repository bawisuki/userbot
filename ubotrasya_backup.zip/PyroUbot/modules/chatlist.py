from PyroUbot import *
from pyrogram.enums import ChatType

__MODULE__ = "ᴄʜᴀᴛ ʟɪꜱᴛ"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴄʜᴀᴛ ʟɪꜱᴛ

⎆ <code>{0}groups</code> ʟɪꜱᴛ ꜱᴇᴍᴜᴀ ɢʀᴜᴘ
⎆ <code>{0}channels</code> ʟɪꜱᴛ ꜱᴇᴍᴜᴀ ᴄʜᴀɴɴᴇʟ
⎆ <code>{0}pms</code> ʟɪꜱᴛ ꜱᴇᴍᴜᴀ ᴘᴍ</b></blockquote>
"""


@PY.UBOT("groups")
@PY.TOP_CMD
async def list_groups(client, message):
    try:
        await message.edit("<emoji id=5789858554890425372>🔄</emoji> <b>ᴍᴇᴍᴜᴀᴛ ᴅᴀꜰᴛᴀʀ ɢʀᴜᴘ...</b>", parse_mode=ParseMode.HTML)
        text = "<emoji id=5206607081334906820>✅</emoji> <b>ᴅᴀꜰᴛᴀʀ ɢʀᴜᴘ:</b>\n\n"
        count = 0
        async for dialog in client.get_dialogs():
            if dialog.chat.type in (ChatType.GROUP, ChatType.SUPERGROUP):
                count += 1
                text += f"  {count}. <b>{dialog.chat.title}</b> (<code>{dialog.chat.id}</code>)\n"
        text += f"\n<b>ᴛᴏᴛᴀʟ:</b> <code>{count}</code> ɢʀᴜᴘ"
        await message.edit(text[:4096], parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("channels")
@PY.TOP_CMD
async def list_channels(client, message):
    try:
        await message.edit("<emoji id=5789858554890425372>🔄</emoji> <b>ᴍᴇᴍᴜᴀᴛ ᴅᴀꜰᴛᴀʀ ᴄʜᴀɴɴᴇʟ...</b>", parse_mode=ParseMode.HTML)
        text = "<emoji id=5206607081334906820>✅</emoji> <b>ᴅᴀꜰᴛᴀʀ ᴄʜᴀɴɴᴇʟ:</b>\n\n"
        count = 0
        async for dialog in client.get_dialogs():
            if dialog.chat.type == ChatType.CHANNEL:
                count += 1
                text += f"  {count}. <b>{dialog.chat.title}</b> (<code>{dialog.chat.id}</code>)\n"
        text += f"\n<b>ᴛᴏᴛᴀʟ:</b> <code>{count}</code> ᴄʜᴀɴɴᴇʟ"
        await message.edit(text[:4096], parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)


@PY.UBOT("pms")
@PY.TOP_CMD
async def list_pms(client, message):
    try:
        await message.edit("<emoji id=5789858554890425372>🔄</emoji> <b>ᴍᴇᴍᴜᴀᴛ ᴅᴀꜰᴛᴀʀ ᴘᴍ...</b>", parse_mode=ParseMode.HTML)
        text = "<emoji id=5206607081334906820>✅</emoji> <b>ᴅᴀꜰᴛᴀʀ ᴘᴍ:</b>\n\n"
        count = 0
        async for dialog in client.get_dialogs():
            if dialog.chat.type == ChatType.PRIVATE:
                count += 1
                name = dialog.chat.first_name or "Unknown"
                text += f"  {count}. <b>{name}</b> (<code>{dialog.chat.id}</code>)\n"
        text += f"\n<b>ᴛᴏᴛᴀʟ:</b> <code>{count}</code> ᴘᴍ"
        await message.edit(text[:4096], parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
