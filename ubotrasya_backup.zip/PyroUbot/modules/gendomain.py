from PyroUbot import *
import random

__MODULE__ = "🌐 Domain"
__HELP__ = """<blockquote><b>⎆ <code>{0}gendomain</code></b></blockquote>"""


@PY.UBOT("gendomain")
@PY.TOP_CMD
async def gendomain(client, message):
    """🌐 Domain"""
    try:
        result = f"{random.choice(['get','try','use','my','the','go','app','web'])}{random.choice(['flow','hub','lab','box','kit','pro','dev','io'])}.{random.choice(['com','io','dev','app','co','net'])}"
        await message.edit(f"<b>🌐 Domain</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
