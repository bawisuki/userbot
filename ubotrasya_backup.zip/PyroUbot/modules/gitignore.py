from PyroUbot import *
import aiohttp
from urllib.parse import quote

__MODULE__ = "ɢɪᴛɪɢɴᴏʀᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}gitignore</code></b></blockquote>"""


@PY.UBOT("gitignore")
@PY.TOP_CMD
async def gitignore(client, message):
    """ɢɪᴛɪɢɴᴏʀᴇ"""
    try:
        lang = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://www.toptal.com/developers/gitignore/api/{quote(lang)}") as r:
                text = await r.text()
        if "ERROR" in text:
            return await message.edit("<b>❌ Template not found.</b>", parse_mode=ParseMode.HTML)
        await message.edit(f"<b>📄 .gitignore for {lang}</b>\n\n<code>{text[:3500]}</code>", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.gitignore python</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
