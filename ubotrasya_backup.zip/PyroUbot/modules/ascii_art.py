from PyroUbot import *

__MODULE__ = "ᴛᴏᴏʟ ascii"
__HELP__ = """<blockquote><b>⎆ <code>{0}ascii</code></b></blockquote>"""


@PY.UBOT("ascii")
@PY.TOP_CMD
async def ascii_art(client, message):
    """ᴛᴏᴏʟ"""
    try:
        text = message.text.split(None, 1)[1][:20]
        result = ""
        for c in text:
            result += f"[{c}]"
        await message.edit(f"<b>🎨 ASCII</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, TypeError):
        await message.edit("<b>⚠️ Provide text or reply to a message.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
