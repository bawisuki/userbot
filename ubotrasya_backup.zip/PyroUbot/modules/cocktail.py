from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄᴏᴄᴋᴛᴀɪʟ"
__HELP__ = """<blockquote><b>⎆ <code>{0}cocktail</code></b></blockquote>"""


@PY.UBOT("cocktail")
@PY.TOP_CMD
async def cocktail(client, message):
    """ᴄᴏᴄᴋᴛᴀɪʟ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://www.thecocktaildb.com/api/json/v1/1/random.php") as r:
                d = await r.json()
        drink = d["drinks"][0]
        ingredients = []
        for i in range(1, 8):
            ing = drink.get(f"strIngredient{i}")
            if ing:
                ingredients.append(ing)
        txt = (
            f"<b>🍸 {drink['strDrink']}</b>\n\n"
            f"<b>🏷 Category:</b> {drink['strCategory']}\n"
            f"<b>🥃 Glass:</b> {drink['strGlass']}\n"
            f"<b>📝 Ingredients:</b> {', '.join(ingredients)}\n\n"
            f"<b>📋 Instructions:</b>\n{drink['strInstructions'][:400]}"
        )
        await message.edit(txt, parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
