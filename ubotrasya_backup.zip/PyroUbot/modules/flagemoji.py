from PyroUbot import *
import aiohttp
from urllib.parse import quote

__MODULE__ = "ꜰʟᴀɢ"
__HELP__ = """<blockquote><b>⎆ <code>{0}flag</code></b></blockquote>"""


@PY.UBOT("flag")
@PY.TOP_CMD
async def flagemoji(client, message):
    """ꜰʟᴀɢ"""
    try:
        name = message.text.split(None, 1)[1]
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://restcountries.com/v3.1/name/{quote(name)}?fields=name,flag,cca2") as r:
                d = await r.json()
        c = d[0]
        await message.edit(f"<b>{c['flag']} {c['name']['common']}</b> ({c['cca2']})", parse_mode=ParseMode.HTML)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.flag country</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
