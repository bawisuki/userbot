from PyroUbot import *
import random

__MODULE__ = "🔢 PIN"
__HELP__ = """<blockquote><b>⎆ <code>{0}genpin</code></b></blockquote>"""


@PY.UBOT("genpin")
@PY.TOP_CMD
async def genpin(client, message):
    """🔢 PIN"""
    try:
        result = str(random.randint(0,9999)).zfill(4)
        await message.edit(f"<b>🔢 PIN</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
