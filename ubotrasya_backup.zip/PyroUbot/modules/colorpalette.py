from PyroUbot import *
import random

__MODULE__ = "ᴘᴀʟᴇᴛᴛᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}palette</code></b></blockquote>"""


@PY.UBOT("palette")
@PY.TOP_CMD
async def colorpalette(client, message):
    """ᴘᴀʟᴇᴛᴛᴇ"""
    try:
        colors = [f"#{random.randint(0,0xFFFFFF):06x}" for _ in range(5)]
        txt = "<b>🎨 Color Palette</b>\n\n"
        for c in colors:
            txt += f"<code>{c}</code> "
        txt += f"\n\n<b>Preview:</b> https://coolors.co/{'-'.join(c[1:] for c in colors)}"
        await message.edit(txt, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
