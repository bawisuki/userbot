from PyroUbot import *
import json as json_lib

__MODULE__ = "ᴊꜱᴏɴ json"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴊꜱᴏɴ

⎆ <code>{0}json</code>
   ʀᴇᴘʟʏ ᴍꜱɢ ᴜɴᴛᴜᴋ ʟɪʜᴀᴛ ʀᴀᴡ ᴊꜱᴏɴ ᴍᴇꜱꜱᴀɢᴇ</b></blockquote>
"""


@PY.UBOT("json")
@PY.TOP_CMD
async def jsonmsg(client, message):
    try:
        reply = message.reply_to_message or message
        raw = json_lib.dumps(json_lib.loads(str(reply)), indent=2, ensure_ascii=False)
        if len(raw) > 4000:
            raw = raw[:4000] + "\n..."
        await message.edit(f"<pre>{raw}</pre>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<emoji id=5210952531676504517>❌</emoji> <b>ᴇʀʀᴏʀ:</b> <code>{e}</code>", parse_mode=ParseMode.HTML)
