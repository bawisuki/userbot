from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ byte2kb"
__HELP__ = """<blockquote><b>⎆ <code>{0}byte2kb</code></b></blockquote>"""


@PY.UBOT("byte2kb")
@PY.TOP_CMD
async def byte2kb(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val * 0.001
        await message.edit(f"<b>📐 {val} bytes = {result:.4f} KB</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.byte2kb value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
