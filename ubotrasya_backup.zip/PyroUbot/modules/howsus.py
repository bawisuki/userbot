from PyroUbot import *
import random

__MODULE__ = "📮 How Su"
__HELP__ = """<blockquote><b>⎆ <code>{0}howsus</code></b></blockquote>"""


@PY.UBOT("howsus")
@PY.TOP_CMD
async def howsus(client, message):
    """📮 How Su"""
    try:
        target = message.reply_to_message.from_user.first_name if message.reply_to_message else "You"
        pct = random.randint(0, 100)
        await message.edit(f"<b>📮 How Sus?</b>\n\n{target} is <b>{pct}%</b> sus!", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
