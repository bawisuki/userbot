from PyroUbot import *
import aiohttp

__MODULE__ = "🐦 Bird F"
__HELP__ = """<blockquote><b>⎆ <code>{0}birdfact2</code></b></blockquote>"""


@PY.UBOT("birdfact2")
@PY.TOP_CMD
async def birdfact2(client, message):
    """🐦 Bird F"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://some-random-api.com/animal/bird") as r:
                d = await r.json(content_type=None)
        result = d["fact"]
        await message.edit(f"<b>🐦 Bird Fact</b>\n\n{result}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
