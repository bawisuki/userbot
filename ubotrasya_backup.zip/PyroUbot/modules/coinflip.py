from PyroUbot import *
import aiohttp

__MODULE__ = "ᴄᴏɪɴ ꜰʟɪᴘ"
__HELP__ = """<blockquote><b>⎆ <code>{0}coinflip</code></b></blockquote>"""


@PY.UBOT("coinflip")
@PY.TOP_CMD
async def coinflip(client, message):
    """ᴄᴏɪɴ ꜰʟɪᴘ"""
    try:
        import random
        result = random.choice(["🪙 Heads!", "🪙 Tails!"])
        await message.edit(f"<b>🎲 Coin Flip</b>\n\n<b>Result:</b> {result}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
