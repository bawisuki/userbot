from PyroUbot import *
import aiohttp

__MODULE__ = "🐱 Cat Fa"
__HELP__ = """<blockquote><b>⎆ <code>{0}catfact2</code></b></blockquote>"""


@PY.UBOT("catfact2")
@PY.TOP_CMD
async def catfact2(client, message):
    """🐱 Cat Fa"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://catfact.ninja/fact") as r:
                d = await r.json(content_type=None)
        result = d["fact"]
        await message.edit(f"<b>🐱 Cat Fact</b>\n\n{result}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
