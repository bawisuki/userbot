from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ cup2ml"
__HELP__ = """<blockquote><b>⎆ <code>{0}cup2ml</code></b></blockquote>"""


@PY.UBOT("cup2ml")
@PY.TOP_CMD
async def cup2ml(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val * 236.588
        await message.edit(f"<b>📐 {val} cups = {result:.4f} ml</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.cup2ml value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
