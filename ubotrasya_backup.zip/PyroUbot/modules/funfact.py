from PyroUbot import *
import random

__MODULE__ = "fun fact"
__HELP__ = """<blockquote><b>⎆ <code>{0}funfact</code></b></blockquote>"""


@PY.UBOT("funfact")
@PY.TOP_CMD
async def funfact(client, message):
    """fun fact"""
    try:
        items = ['Honey never spoils. Archaeologists found 3000-year-old honey in Egyptian tombs that was still edible.', 'Octopuses have three hearts and blue blood.', "A group of flamingos is called a 'flamboyance'.", "Bananas are berries, but strawberries aren't.", 'The shortest war in history lasted 38 minutes.', 'A day on Venus is longer than a year on Venus.', 'There are more possible iterations of a game of chess than atoms in the known universe.']
        await message.edit(f"<b>🎲 Fun Fact</b>\n\n<i>{random.choice(items)}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
