from PyroUbot import *

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛ atm2pa"
__HELP__ = """<blockquote><b>⎆ <code>{0}atm2pa</code></b></blockquote>"""


@PY.UBOT("atm2pa")
@PY.TOP_CMD
async def atm2pa(client, message):
    """ᴄᴏɴᴠᴇʀᴛ"""
    try:
        val = float(message.text.split(None, 1)[1])
        result = val*101325
        await message.edit(f"<b>📐 {val} atm = {result:.6g} pascal</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.atm2pa value</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
