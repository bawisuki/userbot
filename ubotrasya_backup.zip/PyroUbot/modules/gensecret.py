from PyroUbot import *

__MODULE__ = "🔒 Secret"
__HELP__ = """<blockquote><b>⎆ <code>{0}gensecret</code></b></blockquote>"""


@PY.UBOT("gensecret")
@PY.TOP_CMD
async def gensecret(client, message):
    """🔒 Secret"""
    try:
        import random, string, uuid, hashlib, os, secrets, base64
        r = __import__('secrets').token_hex(32)
        await message.edit(f"<b>🔒 Secret Key</b>\n\n<code>{str(r)}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
