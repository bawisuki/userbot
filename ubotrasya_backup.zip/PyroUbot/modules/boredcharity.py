from PyroUbot import *
import aiohttp

__MODULE__ = "❤️ Chari"
__HELP__ = """<blockquote><b>⎆ <code>{0}boredcharity</code></b></blockquote>"""


@PY.UBOT("boredcharity")
@PY.TOP_CMD
async def boredcharity(client, message):
    """❤️ Chari"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://bored-api.appbrewery.com/random?type=charity") as r:
                d = await r.json(content_type=None)
        result = d["activity"]
        await message.edit(f"<b>❤️ Charity</b>\n\n{result}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
