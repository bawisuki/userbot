from PyroUbot import *
import base64

__MODULE__ = "ʙᴀꜱᴇ64 b64enc"
__HELP__ = """
<blockquote><b><emoji id=5206607081334906820>✅</emoji> ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ʙᴀꜱᴇ64

⎆ <code>{0}b64enc</code> [text] ᴇɴᴄᴏᴅᴇ ᴛᴇᴋꜱ
⎆ <code>{0}b64dec</code> [text] ᴅᴇᴄᴏᴅᴇ ᴛᴇᴋꜱ</b></blockquote>
"""


@PY.UBOT("b64enc")
@PY.TOP_CMD
async def b64enc_cmd(client, message):
    args = message.text.split(None, 1)
    if len(args) < 2:
        return await message.edit("<b><emoji id=5210952531676504517>❌</emoji> ɢᴜɴᴀᴋᴀɴ: <code>.b64enc [text]</code></b>")
    try:
        result = base64.b64encode(args[1].encode()).decode()
        await message.edit(f"<b><emoji id=5206607081334906820>✅</emoji> ᴇɴᴄᴏᴅᴇᴅ:</b>\n<code>{result}</code>")
    except Exception as e:
        await message.edit(f"<b><emoji id=5210952531676504517>❌</emoji> ᴇʀʀᴏʀ:</b> <code>{e}</code>")


@PY.UBOT("b64dec")
@PY.TOP_CMD
async def b64dec_cmd(client, message):
    args = message.text.split(None, 1)
    if len(args) < 2:
        return await message.edit("<b><emoji id=5210952531676504517>❌</emoji> ɢᴜɴᴀᴋᴀɴ: <code>.b64dec [text]</code></b>")
    try:
        result = base64.b64decode(args[1].encode()).decode()
        await message.edit(f"<b><emoji id=5206607081334906820>✅</emoji> ᴅᴇᴄᴏᴅᴇᴅ:</b>\n<code>{result}</code>")
    except Exception as e:
        await message.edit(f"<b><emoji id=5210952531676504517>❌</emoji> ᴇʀʀᴏʀ:</b> <code>{e}</code>")
