from PyroUbot import *
import aiohttp

__MODULE__ = "ʟᴏʀᴇᴍ 2"
__HELP__ = """<blockquote><b>⎆ <code>{0}lorem2</code></b></blockquote>"""


@PY.UBOT("lorem2")
@PY.TOP_CMD
async def lorem2(client, message):
    """ʟᴏʀᴇᴍ 2"""
    try:
        paras = message.text.split(None, 1)[1] if len(message.text.split()) > 1 else "1"
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://baconipsum.com/api/?type=all-meat&paras={paras}") as r:
                d = await r.json()
        txt = "\n\n".join(d[:3])[:3500]
        await message.edit(f"<b>📝 Bacon Ipsum</b>\n\n{txt}", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
