from PyroUbot import *

__MODULE__ = "cosine"
__HELP__ = """<blockquote><b>⎆ <code>{0}cos</code></b></blockquote>"""


@PY.UBOT("cos")
@PY.TOP_CMD
async def cos_calc(client, message):
    """cosine"""
    try:
        import math
        val = float(message.text.split(None, 1)[1])
        await message.edit(f"<b>cos({val}°) = {math.cos(math.radians(val)):.6f}</b>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Provide valid numbers.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
