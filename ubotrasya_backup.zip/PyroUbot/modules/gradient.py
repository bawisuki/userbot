from PyroUbot import *
import random

__MODULE__ = "ɢʀᴀᴅɪᴇɴᴛ"
__HELP__ = """<blockquote><b>⎆ <code>{0}gradient</code></b></blockquote>"""


@PY.UBOT("gradient")
@PY.TOP_CMD
async def gradient(client, message):
    """ɢʀᴀᴅɪᴇɴᴛ"""
    try:
        c1 = f"#{random.randint(0,0xFFFFFF):06x}"
        c2 = f"#{random.randint(0,0xFFFFFF):06x}"
        css = f"background: linear-gradient(135deg, {c1}, {c2});"
        await message.edit(f"<b>🌈 Random Gradient</b>\n\n<b>From:</b> <code>{c1}</code>\n<b>To:</b> <code>{c2}</code>\n\n<b>CSS:</b>\n<code>{css}</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
