from PyroUbot import *

__MODULE__ = "ᴛᴏᴏʟ freqwords"
__HELP__ = """<blockquote><b>⎆ <code>{0}freqwords</code></b></blockquote>"""


@PY.UBOT("freqwords")
@PY.TOP_CMD
async def freq_words(client, message):
    """ᴛᴏᴏʟ"""
    try:
        from collections import Counter
        text = message.reply_to_message.text if message.reply_to_message else message.text.split(None, 1)[1]
        words = text.lower().split()
        freq = Counter(words).most_common(10)
        result = "\n".join([f"  {w}: {c}" for w, c in freq])
        await message.edit(f"<b>📊 Word Frequency</b>\n\n<code>{result}</code>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, TypeError):
        await message.edit("<b>⚠️ Provide text or reply to a message.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
