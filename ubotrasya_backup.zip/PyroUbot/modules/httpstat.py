from PyroUbot import *
import aiohttp

__MODULE__ = "ʜᴛᴛᴘ"
__HELP__ = """<blockquote><b>⎆ <code>{0}httpstat</code></b></blockquote>"""


@PY.UBOT("httpstat")
@PY.TOP_CMD
async def httpstat(client, message):
    """ʜᴛᴛᴘ"""
    try:
        url = message.text.split(None, 1)[1]
        if not url.startswith("http"):
            url = "https://" + url
        async with aiohttp.ClientSession() as s:
            async with s.get(url, allow_redirects=True, timeout=aiohttp.ClientTimeout(total=10)) as r:
                txt = (
                    f"<b>🌐 URL:</b> <code>{url}</code>\n"
                    f"<b>📊 Status:</b> {r.status} {r.reason}\n"
                    f"<b>🔀 Redirected:</b> {r.url}"
                )
        await message.edit(txt, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except IndexError:
        await message.edit("<b>⚠️ Usage:</b> <code>.httpstat url</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
