from PyroUbot import *

__MODULE__ = "ᴘx ʀᴇᴍ"
__HELP__ = """<blockquote><b>⎆ <code>{0}pxrem</code></b></blockquote>"""


@PY.UBOT("pxrem")
@PY.TOP_CMD
async def fontsize(client, message):
    """ᴘx ʀᴇᴍ"""
    try:
        val = float(message.text.split(None, 1)[1])
        rem = val / 16
        em = val / 16
        pt = val * 0.75
        await message.edit(f"<b>📐 Font Size Converter</b>\n\n<b>{val}px</b> =\n• <code>{rem:.4f}rem</code>\n• <code>{em:.4f}em</code>\n• <code>{pt:.2f}pt</code>", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError):
        await message.edit("<b>⚠️ Usage:</b> <code>.pxrem 16</code>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
