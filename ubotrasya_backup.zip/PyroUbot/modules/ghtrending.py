from PyroUbot import *
import aiohttp

__MODULE__ = "ɢʜ ᴛʀᴇɴᴅ"
__HELP__ = """<blockquote><b>⎆ <code>{0}github_trending</code></b></blockquote>"""


@PY.UBOT("github_trending")
@PY.TOP_CMD
async def github_trending(client, message):
    """ɢʜ ᴛʀᴇɴᴅ"""
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://api.github.com/search/repositories?q=stars:>1000&sort=stars&order=desc&per_page=5") as r:
                d = await r.json()
        txt = "<b>🔥 GitHub Top Repos</b>\n\n"
        for repo in d["items"][:5]:
            txt += f"⭐ <b>{repo['full_name']}</b> ({repo['stargazers_count']:,}★)\n  {repo.get('description', '')[:60]}\n\n"
        await message.edit(txt, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
