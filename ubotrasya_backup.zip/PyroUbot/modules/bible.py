from PyroUbot import *
import aiohttp

__MODULE__ = "ʙɪʙʟᴇ"
__HELP__ = """<blockquote><b>⎆ <code>{0}bible</code></b></blockquote>"""


@PY.UBOT("bible")
@PY.TOP_CMD
async def bible(client, message):
    """ʙɪʙʟᴇ"""
    try:
        ref = message.text.split(None, 1)[1] if len(message.text.split()) > 1 else "john 3:16"
        async with aiohttp.ClientSession() as s:
            async with s.get(f"https://bible-api.com/{ref}") as r:
                d = await r.json()
        if "error" in d:
            return await message.edit(f"<b>❌ {d['error']}</b>", parse_mode=ParseMode.HTML)
        await message.edit(f"<b>📖 {d['reference']}</b>\n\n<i>{d['text'][:3000]}</i>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
