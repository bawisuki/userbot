from PyroUbot import *

__MODULE__ = "all temps celcius"
__HELP__ = """<blockquote><b>⎆ <code>{0}celcius</code></b></blockquote>"""


@PY.UBOT("celcius")
@PY.TOP_CMD
async def celcius(client, message):
    """all temps"""
    try:
        val = float(message.text.split(None, 1)[1])
        await message.edit(f"<b>🌡 {val}°C</b>\n= {val*9/5+32:.1f}°F\n= {val+273.15:.2f}K", parse_mode=ParseMode.HTML)
    except (IndexError, ValueError, ZeroDivisionError):
        await message.edit("<b>⚠️ Provide valid numbers.</b>", parse_mode=ParseMode.HTML)
    except Exception as e:
        await message.edit(f"<b>❌ Error:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
