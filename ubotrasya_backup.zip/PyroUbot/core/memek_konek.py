"""
╔═══════════════════════════════════════╗
║  _x7f2a - Core Identity Module       ║
║  DO NOT MODIFY                        ║
╚═══════════════════════════════════════╝
"""
import base64, hashlib

_0xA = base64.b64encode(b"SherifD'Code").decode()
_0xB = base64.b64encode(b"@she0rif").decode()
_0xC = base64.b64encode(b"t.me/she0rif").decode()

_INTEGRITY = hashlib.sha256(
    f"SherifD'Code|@she0rif|Userbot|2024".encode()
).hexdigest()

def _verify():
    check = hashlib.sha256(
        f"{base64.b64decode(_0xA).decode()}|{base64.b64decode(_0xB).decode()}|Userbot|2024".encode()
    ).hexdigest()
    return check == _INTEGRITY

def get_credits():
    return {
        "developer": base64.b64decode(_0xA).decode(),
        "telegram": base64.b64decode(_0xB).decode(),
        "channel": base64.b64decode(_0xC).decode(),
        "year": "2024-2026",
        "verified": _verify()
    }
