"""
╔══════════════════════════════════════════════════════════╗
║  SherifD'Code Userbot - Protected Module                ║
║  © 2024-2026 SherifD'Code (@she0rif)                   ║
║  Unauthorized modification is prohibited               ║
║  This file contains integrity verification             ║
╚══════════════════════════════════════════════════════════╝
"""
import base64, hashlib, os, sys

# Obfuscated developer identity - DO NOT MODIFY
_0xDEV = base64.b64encode(b"SherifD'Code").decode()  # U2hlcmlmRCdDb2Rl
_0xUSN = base64.b64encode(b"@she0rif").decode()       # QHNoZTByaWY=
_0xCHN = base64.b64encode(b"t.me/she0rif").decode()   # dC5tZS9zaGUwcmlm
_0xYEAR = "2024-2026"

# Verification constants
_SALT = "x7k9m2p4q8r1s5t3u6v0w"
_HASH = hashlib.sha512(
    f"{base64.b64decode(_0xDEV).decode()}|{base64.b64decode(_0xUSN).decode()}|{_SALT}".encode()
).hexdigest()[:64]

def verify_integrity():
    """Verify that developer credits have not been tampered with"""
    dev = base64.b64decode(_0xDEV).decode()
    usn = base64.b64decode(_0xUSN).decode()
    check = hashlib.sha512(f"{dev}|{usn}|{_SALT}".encode()).hexdigest()[:64]
    return check == _HASH

def get_developer():
    """Get developer info (cannot be modified without breaking verification)"""
    if not verify_integrity():
        return None
    return {
        "name": base64.b64decode(_0xDEV).decode(),
        "username": base64.b64decode(_0xUSN).decode(),
        "channel": base64.b64decode(_0xCHN).decode(),
        "year": _0xYEAR,
    }

def enforce_credits():
    """Called on startup - terminates if credits are modified"""
    if not verify_integrity():
        print("\n[FATAL] ═══════════════════════════════════════")
        print("[FATAL] Bot integrity check FAILED!")
        print("[FATAL] Developer credits have been tampered.")
        print("[FATAL] Bot will not start.")
        print("[FATAL] ═══════════════════════════════════════\n")
        sys.exit(1)
    return True

# Auto-verify on import
enforce_credits()
