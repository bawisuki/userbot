from PyroUbot.core.database import db_exec, db_fetchone


async def get_pref(user_id: int):
    row = await db_fetchone("SELECT prefixesi FROM prefix WHERE user_id=%s", (user_id,))
    return row["prefixesi"] if row and row["prefixesi"] else "."


async def set_pref(user_id: int, prefix: str):
    await db_exec(
        "INSERT INTO prefix (user_id, prefixesi) VALUES (%s, %s) "
        "ON DUPLICATE KEY UPDATE prefixesi=%s",
        (user_id, prefix, prefix),
    )


async def rem_pref(user_id: int):
    await db_exec("DELETE FROM prefix WHERE user_id=%s", (user_id,))
