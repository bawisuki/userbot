import json
from PyroUbot.core.database import db_exec, db_fetchone


async def get_user_ids(client_id: int):
    row = await db_fetchone("SELECT user_dia FROM antigcast WHERE client_id=%s", (client_id,))
    if row and row["user_dia"]:
        return json.loads(row["user_dia"])
    return []


async def set_user_ids(client_id: int, user_list: list):
    data = json.dumps(user_list)
    await db_exec(
        "INSERT INTO antigcast (client_id, user_dia) VALUES (%s, %s) "
        "ON DUPLICATE KEY UPDATE user_dia=%s",
        (client_id, data, data),
    )
