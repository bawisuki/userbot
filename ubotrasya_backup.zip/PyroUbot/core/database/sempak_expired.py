from datetime import datetime, timedelta
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from PyroUbot.core.database import db_exec, db_fetchone
from PyroUbot import bot, OWNER_ID
from PyroUbot.core.database.ngocok_variabel import get_list_from_vars, remove_from_vars, get_vars, remove_vars


async def get_expired_date(user_id: int):
    row = await db_fetchone("SELECT expire_date FROM expired WHERE user_id=%s", (user_id,))
    return row["expire_date"] if row and row["expire_date"] else None


async def set_expired_date(user_id: int, expire_date):
    await db_exec(
        "INSERT INTO expired (user_id, expire_date) VALUES (%s, %s) "
        "ON DUPLICATE KEY UPDATE expire_date=%s",
        (user_id, expire_date, expire_date),
    )


async def rem_expired_date(user_id: int):
    await db_exec("DELETE FROM expired WHERE user_id=%s", (user_id,))


async def check_if_already_tried(user_id):
    free_trial_users = await get_list_from_vars(bot.me.id, "FREE_TRIAL_USERS") or []
    return user_id in free_trial_users


async def check_expired_trials():
    premium_users = await get_list_from_vars(bot.me.id, "PREM_USERS") or []
    for user_id in premium_users:
        free_trial_users = await get_list_from_vars(bot.me.id, "FREE_TRIAL_USERS") or []
        if user_id in free_trial_users:
            expired_date = await get_expired_date(user_id)
            if expired_date and expired_date < datetime.now():
                await remove_from_vars(bot.me.id, "PREM_USERS", user_id)
                await rem_expired_date(user_id)
                try:
                    await bot.send_message(
                        user_id,
                        f"<blockquote><b>⏰ ᴍᴀsᴀ ᴄᴏʙᴀ ɢʀᴀᴛɪs ᴛᴇʟᴀʜ ʙᴇʀᴀᴋʜɪʀ\n\nᴜɴᴛᴜᴋ ᴍᴇᴍʙᴇʟɪ, sɪʟᴀʜᴋᴀɴ ʜᴜʙᴜɴɢɪ: <a href=tg://openmessage?user_id={OWNER_ID}>SherifD'Code</a></b></blockquote>",
                        disable_web_page_preview=True,
                        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("💰 ʙᴇʟɪ ᴜꜱᴇʀʙᴏᴛ", callback_data="bahan")]]),
                    )
                except Exception:
                    pass


async def get_seles_expired_date(user_id: int):
    exp_date_str = await get_vars(bot.me.id, f"SELES_EXP_{user_id}")
    if exp_date_str:
        try:
            return datetime.strptime(exp_date_str, "%Y-%m-%d %H:%M:%S")
        except Exception:
            pass
    return None


async def is_permanent_seller(user_id: int):
    perm_flag = await get_vars(bot.me.id, f"SELES_PERM_{user_id}")
    return perm_flag == "1"


async def check_expired_sellers():
    seles_users = await get_list_from_vars(bot.me.id, "SELER_USERS") or []
    for user_id in seles_users:
        if user_id == OWNER_ID:
            continue
        if await is_permanent_seller(user_id):
            continue
        expired_date = await get_seles_expired_date(user_id)
        if expired_date and expired_date < datetime.now():
            await remove_from_vars(bot.me.id, "SELER_USERS", user_id)
            await remove_vars(bot.me.id, f"SELES_EXP_{user_id}")
            try:
                await bot.send_message(
                    user_id,
                    f"<blockquote><b>⏰ MASA AKTIF RESELLER TELAH BERAKHIR\n\nHubungi: <a href=tg://openmessage?user_id={OWNER_ID}>SherifD'Code</a></b></blockquote>",
                    disable_web_page_preview=True,
                )
            except Exception:
                pass


async def check_all_expirations():
    await check_expired_trials()
    await check_expired_sellers()
