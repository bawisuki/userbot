from PyroUbot.core.database import db_exec, db_fetchone, db_fetchall


async def add_ubot(user_id: int, api_id: int, api_hash: str, session_string: str):
    await db_exec(
        "INSERT INTO ubot (user_id, api_id, api_hash, session_string) VALUES (%s, %s, %s, %s) "
        "ON DUPLICATE KEY UPDATE api_id=%s, api_hash=%s, session_string=%s",
        (user_id, api_id, api_hash, session_string, api_id, api_hash, session_string),
    )


async def remove_ubot(user_id: int):
    await db_exec("DELETE FROM ubot WHERE user_id=%s", (user_id,))


async def get_userbots():
    rows = await db_fetchall("SELECT user_id, api_id, api_hash, session_string FROM ubot")
    return [
        dict(
            name=str(r["user_id"]),
            api_id=r["api_id"],
            api_hash=r["api_hash"],
            session_string=r["session_string"],
        )
        for r in rows
    ]
