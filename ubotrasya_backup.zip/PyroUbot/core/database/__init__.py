import aiomysql
import asyncio

_pool = None

async def get_pool():
    global _pool
    if _pool is None:
        _pool = await aiomysql.create_pool(
            host="127.0.0.1",
            port=3306,
            user="root",
            password="",
            db="sherifdubot",
            autocommit=True,
            minsize=1,
            maxsize=10,
        )
    return _pool

async def db_exec(query, args=None):
    pool = await get_pool()
    async with pool.acquire() as conn:
        async with conn.cursor() as cur:
            await cur.execute(query, args)

async def db_fetchone(query, args=None):
    pool = await get_pool()
    async with pool.acquire() as conn:
        async with conn.cursor(aiomysql.DictCursor) as cur:
            await cur.execute(query, args)
            return await cur.fetchone()

async def db_fetchall(query, args=None):
    pool = await get_pool()
    async with pool.acquire() as conn:
        async with conn.cursor(aiomysql.DictCursor) as cur:
            await cur.execute(query, args)
            return await cur.fetchall()

from PyroUbot.core.database.sempak_expired import *
from PyroUbot.core.database.bacol_userbot import *
from PyroUbot.core.database.colmek_pref import *
from PyroUbot.core.database.ngocok_variabel import *
from PyroUbot.core.database.peju_antigcast import *
