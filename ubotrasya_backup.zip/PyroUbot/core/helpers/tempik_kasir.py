import aiohttp
import qrcode
import io
import random
import time
from PyroUbot.config import PAKASIR_PROJECT, PAKASIR_API_KEY

PAKASIR_BASE = "https://app.pakasir.com/api"

def crc16ccitt(data: str) -> str:
    crc = 0xFFFF
    for char in data:
        crc ^= ord(char) << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = (crc << 1) ^ 0x1021
            else:
                crc = crc << 1
            crc &= 0xFFFF
    return f"{crc:04X}"

def ensure_emv_crc(emv: str) -> str:
    if not emv:
        return None
    s = str(emv).strip()
    idx = s.find('6304')
    if idx != -1 and len(s) >= idx + 8:
        base = s[:idx + 4]
        calc = crc16ccitt(base)
        current = s[idx + 4:idx + 8].upper()
        if current != calc:
            s = base + calc
        return s
    else:
        base = s + '6304'
        calc = crc16ccitt(base)
        return base + calc

def sanitize_qr_string(s):
    if not s or not isinstance(s, str):
        return None
    idx = s.find('000201')
    if idx != -1:
        return s[idx:].strip()
    return s.strip()

def generate_reff_id():
    rand = ''.join(random.choices('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ', k=8))
    return f"TRX-{int(time.time() * 1000)}-{rand}"

async def create_pakasir_qris(amount, project=None, api_key=None):
    # Use config if not provided
    project = project or PAKASIR_PROJECT
    api_key = api_key or PAKASIR_API_KEY
    
    if not project or not api_key:
        return {"error": "Missing Pakasir credentials (Project/API Key). Use .integpay to set them."}

    order_id = generate_reff_id()
    payload = {
        "project": project,
        "order_id": order_id,
        "amount": int(amount),
        "api_key": api_key
    }
    
    headers = {"Content-Type": "application/json"}
    
    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(f"{PAKASIR_BASE}/transactioncreate/qris", json=payload, headers=headers) as resp:
                # Check for non-200 status
                if resp.status != 200:
                     text = await resp.text()
                     return {"error": f"API Error {resp.status}: {text}"}

                data = await resp.json()
                
                if not data or 'payment' not in data:
                    return {"error": "Invalid response from Pakasir", "data": data}
                
                payment = data['payment']
                candidates = [
                    payment.get('qr_string'), 
                    payment.get('qr'), 
                    data.get('qr_string'), 
                    data.get('qr'), 
                    payment.get('payment_number')
                ]
                
                qr_string = None
                for c in candidates:
                    if c and isinstance(c, str) and len(c.strip()) > 0:
                        emv = sanitize_qr_string(c)
                        if emv and emv.startswith('000201'):
                            qr_string = ensure_emv_crc(emv)
                            break
                
                if not qr_string:
                    return {"error": "No valid QR string returned from API"}
                
                # Generate QR Image
                qr = qrcode.QRCode(
                    version=1,
                    error_correction=qrcode.constants.ERROR_CORRECT_M,
                    box_size=10,
                    border=1,
                )
                qr.add_data(qr_string)
                qr.make(fit=True)
                img = qr.make_image(fill_color="black", back_color="white")
                
                img_byte_arr = io.BytesIO()
                img.save(img_byte_arr, format='PNG')
                img_byte_arr.seek(0)
                
                return {
                    "idtransaksi": payment.get('order_id'),
                    "jumlah": payment.get('total_payment'),
                    "nominal": payment.get('amount'),
                    "qr_string": qr_string,
                    "qr_image": img_byte_arr,
                    "expired_at": payment.get('expired_at')
                }
                
        except Exception as e:
            return {"error": str(e)}

async def check_pakasir_status(order_id, amount, project=None, api_key=None):
    project = project or PAKASIR_PROJECT
    api_key = api_key or PAKASIR_API_KEY
    
    url = f"{PAKASIR_BASE}/transactiondetail"
    params = {
        "project": project,
        "amount": int(amount),
        "order_id": order_id,
        "api_key": api_key
    }
    
    async with aiohttp.ClientSession() as session:
        try:
            # Try POST first as it's more common for sensitive data, but fallback to GET if needed
            # User snippet implied query params, so let's try POST with json first?
            # Actually, `axios.post` was used for create.
            # Let's try POST.
            async with session.post(url, json=params) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    # Check data structure. Usually 'transaction' key?
                    # Assuming success if status is 'paid' or similar
                    if data.get('transaction') and data['transaction'].get('status') == 'paid':
                        return True
                    if data.get('status') == 'success' and data.get('data', {}).get('status') == 'paid': # Another common format
                        return True
                    # Let's print data to debug if we were running interactively, but here we assume standard fields
                    # Pakasir usually returns { "transaction": { "status": "paid", ... } }
                    if 'transaction' in data:
                         return data['transaction'].get('status') == 'paid'
                    return False
                else:
                    return False
        except:
            return False
