import aiohttp
import random
import time
import json
from io import BytesIO

ATL_BASE = "https://atlantich2h.com"

def generate_reff_id():
    rand = ''.join(random.choices('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ', k=8))
    return f"TRX-{int(time.time() * 1000)}-{rand}"

async def jembud_instant_check(trx_id, api_key):
    """Trigger instant check for Atlantic transaction"""
    url = f"{ATL_BASE}/deposit/instant"
    data = {
        "api_key": api_key,
        "id": str(trx_id),
        "action": "true"
    }
    
    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(url, data=data) as resp:
                # We don't really care about the response here as per JS code
                pass
        except Exception:
            pass

async def create_atlantic_qris(amount, api_key):
    """Create QRIS using Atlantic H2H"""
    url = f"{ATL_BASE}/deposit/create"
    reff_id = generate_reff_id()
    
    data = {
        "api_key": api_key,
        "reff_id": reff_id,
        "nominal": str(amount),
        "type": "ewallet",
        "metode": "QRIS"
    }
    
    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(url, data=data) as resp:
                if resp.status != 200:
                    return {"error": f"HTTP {resp.status}"}
                
                res_json = await resp.json()
                
                if not res_json.get("status"):
                    return {"error": res_json.get("message", "Unknown error")}
                
                d = res_json.get("data", {})
                if not d:
                    return {"error": "No data returned"}
                
                # Get QR Image
                qr_url = d.get("qr_image")
                qr_image_bytes = None
                
                if qr_url:
                    async with session.get(qr_url) as qr_resp:
                        if qr_resp.status == 200:
                            qr_image_bytes = BytesIO(await qr_resp.read())
                            qr_image_bytes.name = "qris.png"
                
                return {
                    "idtransaksi": d.get("id"),
                    "jumlah": amount, # Atlantic usually exact amount
                    "nominal": amount,
                    "qr_string": d.get("qr_string"),
                    "qr_image": qr_image_bytes, # BytesIO object
                    "expired_at": d.get("expired_at", "N/A"),
                    "provider": "atlantic"
                }
                
        except Exception as e:
            return {"error": str(e)}

async def check_atlantic_status(trx_id, api_key):
    """Check status of Atlantic transaction"""
    url = f"{ATL_BASE}/deposit/status"
    data = {
        "api_key": api_key,
        "id": str(trx_id)
    }
    
    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(url, data=data) as resp:
                if resp.status != 200:
                    return False
                
                res_json = await resp.json()
                status = res_json.get("data", {}).get("status", "").lower()
                
                if status == "success":
                    return True
                elif status == "processing":
                    await jembud_instant_check(trx_id, api_key)
                    return False
                else:
                    return False
        except Exception:
            return False
